local _, ns = ...
local houseOpen = false
local function now()
    return (GetServerTime and GetServerTime()) or time()
end

local function faction()
    return (UnitFactionGroup and UnitFactionGroup("player")) or (ns.state and ns.state.faction)
end

local function venueName(venue)
    if venue == "Horde" or venue == "Alliance" then return venue end
    if venue == "Blackwater" or venue == "Neutral" then return "Neutral" end
end

function ns.MarketKey(explicit)
    local realm = GetRealmName and GetRealmName() or (ns.state and ns.state.realm)
    if not realm or realm == "" then return end
    local record = ns.CurrentRecord and ns.CurrentRecord()
    local market = venueName(explicit)
    if not market then
        local choice = record and record.saleMarket
        if choice == "neutral" then market = "Neutral"
        elseif choice == "faction" then market = venueName(faction())
        elseif houseOpen and ns.GetNativeMarketVenue then market = venueName(ns.GetNativeMarketVenue()) end
        market = market or venueName(faction())
    end
    if not market then return end
    local mode = (ns.state and ns.state.mode) or "normal"
    local region = (GetCurrentRegion and GetCurrentRegion()) or ""
    return table.concat({tostring(region),realm,mode,market},"/"), market .. " AH (" .. realm .. ")", market == "Neutral" and 0.15 or 0.05
end

function ns.MarketLabel()
    local _, label = ns.MarketKey()
    return label or "Unknown market"
end

-- Normalise display level, player-specific loot seed, link colour, and visible name
-- away. Preserve enchants, gems, random suffix and bonus IDs when actually present.
function ns.MarketVariantKey(id, link)
    if type(link) ~= "string" or link == "" then return end
    if link:match("^v:[%d,:%-]+$") then return link end
    local raw = link:match("item:([%d:%-]+)")
    if not raw then return end
    local fields = {}
    for field in (raw..":"):gmatch("([^:]*):") do fields[#fields+1]=tonumber(field) or 0 end
    if fields[1] ~= tonumber(id) then return end
    local traits, distinct = {}, false
    for i = 2,7 do
        local v = fields[i] or 0
        traits[#traits+1] = tostring(v)
        if v ~= 0 then distinct = true end
    end
    local bonus = {}
    for i = 1,math.min(math.max(fields[13] or 0,0),64) do
        if (fields[13+i] or 0) ~= 0 then bonus[#bonus+1]=fields[13+i]; distinct=true end
    end
    if distinct then
        table.sort(bonus)
        for _, value in ipairs(bonus) do traits[#traits+1]=tostring(value) end
        return "v:"..table.concat(traits,",")
    end
end

local function numberOK(n)
    return type(n) == "number" and n > 0 and n == math.floor(n) and n <= 9007199254740991
end

local function database()
    local db = ns.DB()
    db.marketQuotes = db.marketQuotes or {}
    return db.marketQuotes
end

function ns.StoreMarketQuote(id, copper, source, variant, observedAt, venue, units)
    id = tonumber(id)
    if not numberOK(id) or not numberOK(copper) or type(source) ~= "string" then return false end
    local kind = (source == "manual" and "manual") or ((source == "native" or source:match("^AH ")) and "native")
    if not kind or (venue and not venueName(venue)) then return false end
    local key = ns.MarketKey(venue)
    if not key then return false end
    local t = observedAt or now()
    if type(t) ~= "number" or t < 0 or t > now()+5 then return false end
    local markets = database()
    markets[key] = markets[key] or {}
    local item = tostring(id) .. "|" .. (ns.MarketVariantKey(id,variant) or "")
    local current = markets[key][item]
    if current and (current.at > t or (current.at == t and current.source == "native" and kind == "manual")) then return false end
    markets[key][item] = {copper=copper,at=t,source=kind,detail=source,units=units}
    if ns.RequestRefresh then ns.RequestRefresh() end
    return true
end

local function provider(api, key, id)
    if not api or type(api[key])~="function" then return end
    local ok, v = pcall(api[key], "RosethornAdvisor", id)
    if ok and type(v)=="number" and v >= 0 and v < math.huge then return v end
end

function ns.MarketQuote(id, variant)
    id = tonumber(id)
    if not numberOK(id) then return end
    local key, _, cut = ns.MarketKey()
    if not key then return end
    local v = ns.MarketVariantKey(id,variant)
    local book = database()[key]
    local row = book and book[tostring(id).."|"..(v or "")]
    local localAge = row and math.max(0,(now()-row.at)/86400)
    -- Auctionator's public item-ID API does not identify the auctioneer or
    -- a gear variant. Use its cache only as an explicitly indicative quote.
    if row and localAge <= 7 then return row.copper,localAge,row.source end
    if not v and cut == 0.05 and ns.MarketKey(faction()) == key then
        local api = Auctionator and Auctionator.API and Auctionator.API.v1
        local price = provider(api,"GetAuctionPriceByItemID",id)
        if price and price > 0 then
            local age = provider(api,"GetAuctionAgeByItemID",id)
            -- Providers report age in whole days. Prefer a timestamped observation
            -- from the same age bucket, whose precise collection time is known.
            if not row or (age and math.floor(age) < math.floor(localAge)) then
                return price,age,"Auctionator"
            end
        end
    end
    if row then return row.copper,localAge,row.source end
end

local function money(text)
    if type(text) ~= "string" then return end
    text = text:lower():gsub("^%s+",""):gsub("%s+$","")
    if text:match("^%d+$") then local value=tonumber(text); if numberOK(value) then return value end; return end
    local units = {g=10000,s=100,c=1}
    local total, previous = 0,10001
    while text ~= "" do
        local n, unit, tail = text:match("^(%d+)%s*([gsc])%s*(.*)$")
        if not n or units[unit] >= previous then return end
        total,previous = total+tonumber(n)*units[unit], units[unit]
        text=tail
    end
    if numberOK(total) then return total end
end

local function say(message)
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then DEFAULT_CHAT_FRAME:AddMessage(message)
    elseif print then print(message) end
end

local function command(message)
    local input = (message or ""):match("^%s*(.-)%s*$")
    local choice=input:lower():match("^market%s+(%a+)$")
    if choice=="faction" or choice=="neutral" or choice=="auto" then
        local record=ns.CurrentRecord()
        if not record then return end
        record.saleMarket = choice~="auto" and choice or nil
        say("Advisor sale market: "..ns.MarketLabel())
        if ns.RequestRefresh then ns.RequestRefresh() end
        return
    elseif input:lower()=="market" then say("Advisor sale market: "..ns.MarketLabel()..". Use /rtaprice market faction, neutral or auto."); return end
    local link, price = input:match("^(.-|h%[[^%]]+%]|h|r)%s+(.+)$")
    if not link then link,price=input:match("^(.-|h%[[^%]]+%]|h)%s+(.+)$") end
    local id = link and tonumber(link:match("item:(%d+)"))
    if not id then id,price=input:match("^(%d+)%s+(.+)$"); id=tonumber(id) end
    local unit=money(price)
    if id and unit and ns.StoreMarketQuote(id,unit,"manual",link) then
        say(("Saved %d copper per item for #%d, %s."):format(unit,id,ns.MarketLabel()))
    else
        say("Use /rtaprice <item ID or Shift-click link> <unit price>, e.g. /rtaprice 6362 40s or /rtaprice 6362 1g 2s 3c. /rtaprice market selects your sale market.")
    end
end
SLASH_ROSETHORNPRICE1="/rtaprice"
SlashCmdList.ROSETHORNPRICE=command
local events=CreateFrame("Frame")
events:RegisterEvent("AUCTION_HOUSE_SHOW")
events:RegisterEvent("AUCTION_HOUSE_CLOSED")
events:RegisterEvent("PLAYER_LEAVING_WORLD")
events:SetScript("OnEvent",function(_,event)
    houseOpen=event=="AUCTION_HOUSE_SHOW"
    if ns.RequestRefresh then ns.RequestRefresh() end
end)
