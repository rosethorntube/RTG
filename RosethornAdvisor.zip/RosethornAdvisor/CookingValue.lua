local _, ns = ...

-- Undiscounted, repeatable vendor purchases. Water and Mild Spices are sold
-- in packs of five. The other two prices are for single items.
-- https://www.wow-professions.com/forever/npc/kelsey-yance
local supplies = {
    [159]  = {name = "Refreshing Spring Water", packPrice = 25, packSize = 5},
    [2678] = {name = "Mild Spices", packPrice = 10, packSize = 5},
    [2692] = {name = "Hot Spices", packPrice = 40, packSize = 1},
    [3713] = {name = "Soothing Spices", packPrice = 160, packSize = 1},
}

function ns.CookingVendorUnitCost(id)
    local supply = supplies[id]
    return supply and supply.packPrice / supply.packSize
end

local function marketPrice(id)
    if not ns.MarketQuote then return end
    local price, age, source = ns.MarketQuote(id)
    if type(price) == "number" and price > 0 and price < math.huge then
        return price, age, source
    end
end

local function isLearned(state, spell)
    if state.missing and state.missing[spell] then return false end
    if state.known and state.known[spell] then return true end
    if type(IsSpellKnown) == "function" then
        local ok, known = pcall(IsSpellKnown, spell)
        return ok and known == true
    end
    return false
end

-- Each returned currency amount is per raw fish, before AH fees, deposits
-- or travel. Bagged ingredients still have a replacement cost.
function ns.CookingMarketOptions(itemID, state)
    local f = ns.fish[itemID]
    if not f or not f.outputItem then return end
    state = state or ns.state or {}
    local rawNeeded = f.fishPerCraft
    local unitYield = f.outputPerCraft / rawNeeded
    local result = {
        recipe = f.recipe, outputItem = f.outputItem, unitYield = unitYield,
        extraCopper = 0, executable = false, station = f.station or "Cooking Fire",
        ingredientCosts = {},
    }
    local missing, suppliesNeeded = {}, {}
    local cooking = state.skills and state.skills.Cooking
    local rank = cooking and cooking.rank or 0
    local known = isLearned(state, f.spell)
    if rank < f.skill then
        missing[#missing + 1] = "Requires Cooking " .. f.skill
    end
    if not known then
        missing[#missing + 1] = state.missing and state.missing[f.spell] and "Recipe not learned" or "Open Cooking to confirm the recipe"
    end
    -- This flag describes the character's profession eligibility. Station
    -- and materials are separate requirements and can be acquired later.
    result.executable = known and rank >= f.skill
    result.rawCopper, result.rawAgeDays, result.rawSource = marketPrice(itemID)
    if not result.rawCopper then missing[#missing + 1] = "Raw fish market quote missing" end
    local cookedUnit, cookedAge, cookedSource = marketPrice(f.outputItem)
    result.cookedAgeDays, result.cookedSource = cookedAge, cookedSource
    if cookedUnit then result.cookedCopper = cookedUnit * unitYield
    else missing[#missing + 1] = "Cooked food market quote missing" end

    for id, quantity in pairs(f.ingredients or {}) do
        local supply = supplies[id]
        local label = supply and supply.name or ("Item " .. id)
        local copper, age, source = marketPrice(id)
        local vendorCost = ns.CookingVendorUnitCost(id)
        if vendorCost and (not copper or vendorCost <= copper) then
            copper, age, source = vendorCost, nil, "vendor"
        end
        if copper then
            result.ingredientCosts[id] = {quantity = quantity, unitCopper = copper, ageDays = age, source = source}
            if result.extraCopper then result.extraCopper = result.extraCopper + copper * quantity / rawNeeded end
        else
            result.extraCopper = nil
            missing[#missing + 1] = label .. " replacement price missing"
        end
        if state.bags and (state.bags[id] or 0) < quantity then
            suppliesNeeded[#suppliesNeeded + 1] = label
        end
    end
    if #suppliesNeeded > 0 then
        table.sort(suppliesNeeded)
        result.ingredientsNeeded = table.concat(suppliesNeeded, ", ")
    end
    if result.rawCopper and result.cookedCopper and result.extraCopper then
        result.netGain = result.cookedCopper - result.rawCopper - result.extraCopper
    end
    if #missing > 0 then result.missing = table.concat(missing, ". ") end
    return result
end
