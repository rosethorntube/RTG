local _, ns = ...

ns.ProfessionDefinitions = {
    Alchemy={id=171,spell=2259,kind="Crafting"}, Blacksmithing={id=164,spell=2018,kind="Crafting"},
    Enchanting={id=333,spell=7411,kind="Crafting"}, Engineering={id=202,spell=4036,kind="Crafting"},
    Herbalism={id=182,spell=2366,kind="Gathering"}, Leatherworking={id=165,spell=2108,kind="Crafting"},
    Mining={id=186,spell=2575,kind="Gathering"}, Skinning={id=393,spell=8613,kind="Gathering"},
    Tailoring={id=197,spell=3908,kind="Crafting"}, Cooking={id=185,spell=2550,kind="Secondary"},
    Fishing={id=356,spell=7620,kind="Secondary"}, ["First Aid"]={id=129,spell=3273,kind="Secondary"},
}
local professionOrder={"Alchemy","Blacksmithing","Enchanting","Engineering","Herbalism","Leatherworking","Mining","Skinning","Tailoring","Cooking","First Aid","Fishing"}
local rosterOrder={PRIEST=1,WARRIOR=2,DRUID=3,HUNTER=4,MAGE=5,SHAMAN=6,WARLOCK=7,PALADIN=8,ROGUE=9}
local groups={
    {"Leather","Druid (Leatherworking)",{2934,2318,2319,4234,4304,8170,783,4232,4235,8169,8171,4231,4233,4236,8172,15407}},
    {"Ore","Warrior or Hunter (Engineering) and Paladin (Blacksmithing)",{2770,2771,2772,2775,2776,3858,7911,10620,2840,2841,2842,3575,3576,3577,3859,3860,6037,12359,2835,2836,2838,7912,12365}},
    {"Cloth","Mage (Tailoring) or an alt levelling First Aid",{2589,2592,4306,4338,14047,14256,14342,2996,2997,4305,4339,14048}},
    {"Herbs","Warlock (Alchemy)",{2447,765,2449,785,2450,2452,2453,3355,3356,3357,3358,3369,3818,3819,3820,3821,4625,8153,8831,8836,8838,8839,8845,8846,13463,13464,13465,13466,13467,13468}},
    {"Enchanting materials","Mage (Enchanting)",{10940,10938,10939,10978,10998,11082,11083,11084,11134,11135,11137,11138,11139,11174,11175,11176,11177,11178,16202,16203,16204,14343,14344}},
    {"BoE greens","Mage (disenchanting)",{}},
}
ns.materialKind,ns.materialGroups={},{}
for _,g in ipairs(groups) do
    ns.materialGroups[g[1]]=g[3]
    for _,id in ipairs(g[3]) do ns.materialKind[id]=g[1] end
end
local function safe(func,...)
    if type(func)~="function" then return end
    local ok,a,b,c,d,e,f,g,h,i,j,k,l,m,n=pcall(func,...)
    if ok then return a,b,c,d,e,f,g,h,i,j,k,l,m,n end
end
local tradeSubclasses={[5]="Cloth",[6]="Leather",[7]="Ore",[9]="Herbs",[12]="Enchanting materials"}
function ns.GetMaterialKind(id)
    if ns.materialKind[id] then return ns.materialKind[id] end
    local lookup=(C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
    local _,_,_,_,_,class,sub=safe(lookup,id)
    if class==7 and tradeSubclasses[sub] then
        ns.materialKind[id]=tradeSubclasses[sub]
        return ns.materialKind[id]
    end
end
local function observed()return safe(GetServerTime) or safe(time) or 0 end
local function dated(stamp)
    if not stamp or stamp<=0 then return "date unknown" end
    return safe(date,"%d %b %Y %H:%M",stamp) or tostring(stamp)
end
local book={Cooking="Wulan, Shadowprey",Fishing="Old Man Heming, Booty Bay",["First Aid"]="Balai Lok'Wein, Brackenwall"}
local quest={Cooking="Dirge, Gadgetzan",Fishing="Nat Pagle, Dustwallow",["First Aid"]="Doctor Gregory Victor, Hammerfall"}
local gatherTrainers={Mining="Makaru, Orgrimmar",Herbalism="Jandi, Orgrimmar",Skinning="Thuwd, Orgrimmar"}
local expert={Alchemy="Doctor Herbert Halsey, Undercity",Blacksmithing="Saru Steelfury, Orgrimmar",Enchanting="Hgarth, Sun Rock Retreat",Engineering="Roxxik, Orgrimmar",Leatherworking="Una, Thunder Bluff",Tailoring="Josef Gregorian, Undercity"}
local artisan={Alchemy="Rogvar, Stonard",Blacksmithing="Brikk Keencraft, Booty Bay",Enchanting="Annora, Uldaman",Engineering="Buzzek Bracketswing, Gadgetzan",Leatherworking="Hahrana Ironhide, Camp Mojache",Tailoring="Daryl Stack, Tarren Mill"}
function ns.nextProfessionRank(prof,rank,cap,level,faction)
    if cap>=300 then return rank>=300 and "300 cap reached" or "Artisan cap 300" end
    local function withTrainer(text,trainer)
        return (faction~="Alliance" and trainer) and text..". "..trainer or text
    end
    if cap>=225 and quest[prof] then return withTrainer("Artisan quest (300 cap), level 35 / skill 225",quest[prof]) end
    if cap>=150 and cap<225 and book[prof] then return withTrainer("Expert book (225 cap), skill 125",book[prof]) end
    if cap>=225 then return withTrainer("Artisan trainer (300 cap), "..(gatherTrainers[prof] and "" or "level 35 / ").."skill 200",gatherTrainers[prof] or artisan[prof]) end
    if cap>=150 then return withTrainer("Expert trainer (225 cap), "..(gatherTrainers[prof] and "" or "level 20 / ").."skill 125",gatherTrainers[prof] or expert[prof]) end
    return withTrainer("Journeyman trainer (150 cap), skill 50",gatherTrainers[prof])
end

-- IDs alone cannot tell whether a particular piece of equipment has already been bound.
local function isGreenBoE(info,bag,slot)
    if not info or not info.itemID or info.isBound==true or (info.quality and info.quality~=2) then return false end
    local getInfo=(C_Item and C_Item.GetItemInfo) or GetItemInfo
    local _,_,quality,_,_,_,_,_,equip,_,_,class,_,bind=safe(getInfo,info.hyperlink or info.itemID)
    if quality~=2 or bind~=2 or (class~=2 and class~=4) or equip=="" then return false end
    if info.isBound~=nil then return info.isBound==false end
    if C_Item and C_Item.IsBound and ItemLocation and ItemLocation.CreateFromBagAndSlot then
        local location=safe(ItemLocation.CreateFromBagAndSlot,ItemLocation,bag,slot)
        return location and safe(C_Item.IsBound,location)==false
    end
    return false
end
-- A nil tally means the container API could not provide a usable observation.
function ns.ScanRosterContainers(first,last,bank)
    local api=C_Container or {}
    local size=api.GetContainerNumSlots or GetContainerNumSlots
    if not size or not (api.GetContainerItemInfo or GetContainerItemInfo) then return end
    local tally,greens,capacity={},{},0
    local function scan(bag,required)
        local total=safe(size,bag)
        if type(total)~="number" or (required and total<1) then return false end
        capacity=capacity+total
        for i=1,total do
            local info
            if api.GetContainerItemInfo then info=safe(api.GetContainerItemInfo,bag,i)
            else
                local _,count,_,quality,_,_,link,_,_,id,bound=safe(GetContainerItemInfo,bag,i)
                if id or link then info={itemID=id or tonumber(link:match("item:(%d+)")),stackCount=count,quality=quality,hyperlink=link,isBound=bound} end
            end
            if info and info.itemID then
                local id,n=info.itemID,info.stackCount or 1
                tally[id]=(tally[id] or 0)+n
                if not ns.GetMaterialKind(id) and isGreenBoE(info,bag,i) then greens[id]=(greens[id] or 0)+n end
            end
        end
        return true
    end
    if bank and not scan((Enum and Enum.BagIndex and Enum.BagIndex.Bank) or BANK_CONTAINER or -1,true) then return end
    for bag=first,last do if not scan(bag,false) then return end end
    return tally,greens,capacity
end
local bankOpen=false
function ns.SnapshotRoster(rec,s,counts,greens)
    if counts then rec.bagMaterials,rec.bagGreens,rec.bagSeen=counts,greens,observed() end
    if not bankOpen then return end
    local enums=Enum and Enum.BagIndex or {}
    if enums.CharacterBankTab_1 then
        local tabs=rec.personalBankTabs or {}
        local changed=false
        for bag=enums.CharacterBankTab_1,(enums.CharacterBankTab_9 or enums.CharacterBankTab_1+8) do
            local items,boe,size=ns.ScanRosterContainers(bag,bag,false)
            -- An unlocked and loaded tab has a positive capacity even when empty.
            if items and size>0 then tabs[bag]={items=items,greens=boe,seen=observed()};changed=true end
        end
        if changed then
            rec.personalBankTabs=tabs
            local inventory,boe,oldest={},{},nil
            for _,tab in pairs(tabs) do
                for id,n in pairs(tab.items) do inventory[id]=(inventory[id] or 0)+n end
                for id,n in pairs(tab.greens or {}) do boe[id]=(boe[id] or 0)+n end
                oldest=math.min(oldest or tab.seen,tab.seen)
            end
            rec.bankMaterials,rec.bankGreens,rec.bankSeen=inventory,boe,oldest
        end
        return
    end
    local first=(NUM_BAG_SLOTS or 4)+1
    local last=first+(NUM_BANKBAGSLOTS or 7)-1
    local inventory,boe=ns.ScanRosterContainers(first,last,true)
    if inventory then rec.bankMaterials,rec.bankGreens,rec.bankSeen=inventory,boe,observed() end
end
if CreateFrame then
    local bankEvents=CreateFrame("Frame")
    for _,event in ipairs({"BANKFRAME_OPENED","BANKFRAME_CLOSED","PLAYERBANKSLOTS_CHANGED","PLAYERBANKBAGSLOTS_CHANGED","BAG_UPDATE_DELAYED"}) do
        pcall(bankEvents.RegisterEvent,bankEvents,event)
    end
    bankEvents:SetScript("OnEvent",function(_,event)
        if event=="BANKFRAME_CLOSED" then bankOpen=false;return end
        if event=="BANKFRAME_OPENED" then bankOpen=true end
        if bankOpen and ns.Collect then ns.Collect() end
    end)
end
function ns.GetRosterRows()
    local rows={}
    for key,r in pairs(ns.DB().characters) do
        if r.name and r.realm then
            rows[#rows+1]={key=key,name=r.name,realm=r.realm,faction=r.faction,class=r.class,level=r.level,
                mode=r.mode,seen=r.seenAt,seenAt=r.seenAt,skills=r.skills or {},skillsSeen=r.skillsSeen,skillSeen=r.skillSeen,
                bagMaterials=r.bagMaterials,bagGreens=r.bagGreens,bagSeen=r.bagSeen,bankMaterials=r.bankMaterials,bankGreens=r.bankGreens,bankSeen=r.bankSeen}
        end
    end
    table.sort(rows,function(a,b)
        local ai,bi=rosterOrder[a.class] or 99,rosterOrder[b.class] or 99
        return ai<bi or (ai==bi and a.key<b.key)
    end)
    return rows
end
function ns.AddRosterAdvice(s,add)
    local rows=ns.GetRosterRows()
    local owners={}
    for i,r in ipairs(rows) do
        local parts={}
        for _,name in ipairs(professionOrder) do
            local skill=r.skills[name]
            if skill and type(skill.rank)=="number" and type(skill.cap)=="number" then
                parts[#parts+1]=name.." "..skill.rank.."/"..skill.cap.." ("..ns.ProfessionDefinitions[name].kind.."). "..ns.nextProfessionRank(name,skill.rank,skill.cap,r.level,r.faction).."."
            end
        end
        local inventory="Bags "..dated(r.bagSeen)..". Bank "..(r.bankSeen and dated(r.bankSeen) or "not observed").."."
        local realm=r.realm.." / "..(r.faction or "faction unobserved")
        if r.mode=="hardcore" then realm=realm.." / Hardcore" end
        local header=(r.class and r.class:sub(1,1)..r.class:sub(2):lower().." " or "").."level "..(r.level or "?")
        local body=header..", "..realm..". Last seen "..dated(r.seen)..".\n"..(#parts>0 and "Skills observed "..dated(r.skillsSeen)..":\n"..table.concat(parts,"\n") or "No profession ranks observed.").."\n"..inventory
        add(r.name.." — professions",body,20+i/100,"roster:"..r.key)
        if s.faction and s.realm~="?" and r.realm==s.realm and r.faction==s.faction and r.mode==s.mode then
            local amounts={}
            local function count(items,greens,storage)
                local function addAmount(kind,n)
                    local amount=amounts[kind] or {bags=0,bank=0}
                    amount[storage]=amount[storage]+n;amounts[kind]=amount
                end
                for id,n in pairs(items or {}) do
                    local kind=ns.GetMaterialKind(id)
                    if kind and n>0 then addAmount(kind,n) end
                end
                for _,n in pairs(greens or {}) do addAmount("BoE greens",n) end
            end
            count(r.bagMaterials,r.bagGreens,"bags");count(r.bankMaterials,r.bankGreens,"bank")
            for group,amount in pairs(amounts) do
                owners[group]=owners[group] or {total=0,list={}}
                local g=owners[group];g.total=g.total+amount.bags+amount.bank
                local locations={}
                if amount.bags>0 then locations[#locations+1]=amount.bags.." in bags" end
                if amount.bank>0 then locations[#locations+1]=amount.bank.." in bank" end
                g.list[#g.list+1]=r.name.." ("..table.concat(locations,", ")..")"
            end
        end
    end
    for i,g in ipairs(groups) do
        local held=owners[g[1]]
        if held and held.total>0 then
            local label=g[1]=="Ore" and "Ore, bars and stone" or g[1]
            add(label.." — "..held.total.." observed",table.concat(held.list,", ")..". Planned recipient: "..g[2]..". Includes last observed bags and opened banks on this realm, faction and ruleset.",40+i/100,"materials:"..g[1])
        end
    end
end
