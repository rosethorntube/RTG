local _,ns=...
local instances={
    ["Ragefire Chasm"]=62031,["Hall of Thanes"]=62031,["Ruins of Lordaeron"]=62031,["Wailing Caverns"]=62031,
    ["The Deadmines"]=62031,["Shadowfang Keep"]=62031,["Excavation Site: Wetlands"]=62031,
    ["Blackfathom Deeps"]=62032,["Razorfen Kraul"]=62032,["City of Dalaran"]=62032,["Gnomeregan"]=62032,
    ["Scarlet Monastery"]=62032,["The Drowned City"]=62032,["Krol'dok Stronghold"]=62032,
    ["Razorfen Downs"]=62033,["Uldaman"]=62033,["Zul'Farrak"]=62033,["Maraudon"]=62033,
    ["Alcaz Prison"]=62033,["The Temple of Atal'Hakkar"]=62033,["Sunken Temple"]=62033,
    ["Blackrock Depths"]=62033,["Blackrock Spire"]=62033,["Blackmaw Hold"]=62033,
    ["Dire Maul"]=62033,["Stratholme"]=62033,["Scholomance"]=62033,["The Shaper's Terrace"]=62033
}
local groups={[62031]="Novice",[62032]="Experienced",[62033]="Master"}
function ns.AddNearbyTips(s,add)
    local cook=s.skills.Cooking
    if cook and s.x and s.y then
        for id,f in pairs(ns.fish) do
            local vendor=ns.localFishVendors[s.mapID] or f
            if vendor~=f and not vendor.items[id] then vendor=f end
            if vendor.mapID==s.mapID and (s.x-vendor.x)^2+(s.y-vendor.y)^2<0.025^2
                and (s.bags[id] or 0)==0 and (s.bags[f.recipeItem] or 0)==0
                and not s.known[f.spell] and not (IsSpellKnown and IsSpellKnown(f.spell))
                and cook.rank>=f.skill and cook.rank<f.grey then
                local prefix=s.missing[f.spell] and "Buy " or "Check "
                local body=vendor.vendor.." sells this recipe at "..vendor.zone..(" (%.1f, %.1f). "):format(vendor.x*100,vendor.y*100)
                    .."It can still raise your Cooking at "..cook.rank.."."
                if not s.missing[f.spell] then body=body.." Check your recipe book before buying." end
                add(prefix..f.recipe.." at "..vendor.vendor,body,15,"vendor:"..vendor.vendor..":"..f.recipeItem,nil,true)
            end
        end
    end
    if not GetInstanceInfo then return end
    local name,kind=GetInstanceInfo()
    local id=kind=="party" and instances[name]
    if not id then return end
    local done=false
    if GetAchievementInfo then local ok,_,_,_,value=pcall(GetAchievementInfo,id);done=ok and value==true end
    if not done then
        add("Check "..groups[id].." Spelunker",name.." is on this achievement route. Check the wing in Legacy (Y) and defeat its final boss if you still need credit.",22,"dungeon:"..name,nil,true)
    end
end
