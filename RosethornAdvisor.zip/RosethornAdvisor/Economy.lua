local _, ns = ...

-- Open-water skill targets. Zones with exceptional waters use named subzones.
-- Wowhead Forever, Fishing Profession Overview, "Fishing Requirements by Zone".
local plainWater = {
    [1411]=25, [1412]=25, [1420]=25, [1438]=25, [1426]=25, [1429]=25,
    [1413]=75, [1421]=75, [1439]=75, [1432]=75, [1436]=75,
    [1454]=75, [1456]=75, [1458]=75, [1453]=75, [1455]=75, [1457]=75,
    [1440]=150, [1424]=150, [1442]=150, [1431]=150, [1433]=150, [1437]=150,
    [1416]=225, [1417]=225, [1443]=225, [1445]=225, [1435]=225, [1441]=225,
    [1448]=300, [1425]=300, [1450]=300, [1446]=300, [1449]=300, [1422]=300,
    [1428]=425, [1430]=425, [1423]=425, [1451]=425, [1452]=425,
}
local namedWater = {
    [1434]={["Booty Bay"]=225, ["Grom'gol Base Camp"]=225, ["The Savage Coast"]=225, ["Jaguero Isle"]=300},
    [1444]={["Camp Mojache"]=300, ["Wildwind Lake"]=300, ["Verdantis River"]=300,
        ["Feathermoon Stronghold"]=300, ["The Forgotten Coast"]=300, ["Jademir Lake"]=425},
    [1447]={["Bay of Storms"]=425, ["Hetaera's Clutch"]=425, ["Scalebeard's Cave"]=425},
}
function ns.WaterThreshold(state)
    if not state then return end
    if IsInInstance and IsInInstance() then return end
    local names = namedWater[state.mapID]
    return names and names[state.subzone] or plainWater[state.mapID]
end

local function waterNow()
    local sub = GetSubZoneText and GetSubZoneText() or ""
    local zone = GetRealZoneText and GetRealZoneText() or ""
    local map = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
    return {mapID=map, subzone=sub, zone=zone}, sub ~= "" and sub or zone
end

local session, pendingLoot, fishingChannel, castForLoot, toast
local previousCastGUIDs={}
local function characterKey()
    if ns.state and ns.state.key then return ns.state.key end
    local name=UnitName and UnitName("player")
    return name and ((GetRealmName and GetRealmName() or "")..":"..name) or nil
end
local function archive()
    if not session then return end
    local key=characterKey()
    local seconds=session.last-session.start
    if key and (seconds>0 or session.casts>0) then
        RosethornAdvisorDB=RosethornAdvisorDB or {}
        local db=RosethornAdvisorDB
        db.fishingTrips=db.fishingTrips or {}
        local history=db.fishingTrips[key] or {}
        history[#history+1]={key=session.key,water=session.water,seconds=seconds,items=session.items,
            casts=session.casts,castCoverage=session.castCoverage and session.casts>0}
        if #history>160 then table.remove(history,1) end
        db.fishingTrips[key]=history
    end
    previousCastGUIDs=session.seenCastGUIDs
    session,castForLoot,fishingChannel=nil,nil,nil
end
local function touch()
    local now = GetTime()
    local state, label = waterNow()
    local key = tostring(state.mapID) .. "/" .. label
    if not session or session.key ~= key or now-session.last >= 120 then
        archive()
        session = {key=key, water=label, start=now, last=now, items={}, casts=0,
            castCoverage=true, seenCastGUIDs={}}
    end
    session.last = now
    return state
end

local function refresh()
    if ns.RequestRefresh then ns.RequestRefresh() end
end

local function quote(id,link,key,cache)
    if not cache[key] then
        local unit, age, source
        if ns.MarketQuote then unit,age,source=ns.MarketQuote(id,link) end
        cache[key]={unit=unit,age=age,source=source}
    end
    return cache[key]
end
local function estimate(trip,seconds,cache)
    local result = {seconds=seconds, water=trip.water, quantity=0, priced=0,
        unpriced=0, copper=0, unknownAge=false, unverifiedVenue=0, items={}}
    for key, stack in pairs(trip.items) do
        local id=stack.id or key
        local q=quote(id,stack.link,key,cache)
        local unit,age=q.unit,q.age
        local row = {id=id,link=stack.link,name=stack.name,quantity=stack.count}
        result.quantity = result.quantity + stack.count
        if type(unit)=="number" and unit>0 then
            local amount = unit * stack.count
            result.priced = result.priced + stack.count
            result.copper = result.copper + amount
            if q.source=="Auctionator" then result.unverifiedVenue=result.unverifiedVenue+stack.count end
            if age then result.oldestDays = math.max(result.oldestDays or 0,age)
            else result.unknownAge = true end
            row.copper,row.age,row.source=amount,age,q.source
        else
            result.unpriced = result.unpriced + stack.count
        end
        table.insert(result.items,row)
    end
    table.sort(result.items,function(a,b)
        if (a.copper or -1)==(b.copper or -1) then return a.id<b.id end
        return (a.copper or -1)>(b.copper or -1)
    end)
    if result.seconds>=300 then
        if result.priced>0 then result.perHour=result.copper*3600/result.seconds end
        result.catchesPerHour=result.quantity*3600/result.seconds
    end
    return result
end
local function perCast(result,casts)
    if casts>0 and result.unpriced==0 then return result.copper/casts end
end
function ns.GetFishingEstimate()
    if not session then return end
    local r=estimate(session,session.last-session.start,{})
    r.casts=session.casts
    r.castCoverage=session.castCoverage and session.casts>0
    if r.castCoverage then r.perCast=perCast(r,r.casts) end
    return r
end

-- Compare waters at today's same market quotes. Sum elapsed time and quantities
-- before dividing, so a short lucky visit never gets an equal vote with a long one.
function ns.GetFishingSpots()
    local spots,rows,cache={},{},{}
    local function sumItems(total,items)
        for tag,item in pairs(items) do
            local summed=total[tag] or {name=item.name,id=item.id,link=item.link,count=0}
            summed.count=summed.count+item.count
            total[tag]=summed
        end
    end
    local function include(trip,seconds)
        local spot=spots[trip.key] or {water=trip.water,seconds=0,visits=0,items={},
            casts=0,castSeconds=0,castVisits=0,castItems={}}
        spots[trip.key]=spot
        spot.seconds=spot.seconds+seconds
        spot.visits=spot.visits+1
        sumItems(spot.items,trip.items)
        -- Older histories and partially observed visits have no reliable cast denominator.
        if trip.castCoverage and trip.casts and trip.casts>0 then
            spot.casts=spot.casts+trip.casts
            spot.castSeconds=spot.castSeconds+seconds
            spot.castVisits=spot.castVisits+1
            sumItems(spot.castItems,trip.items)
        end
    end
    local history=RosethornAdvisorDB and RosethornAdvisorDB.fishingTrips
    local key=characterKey()
    for _,trip in ipairs((history and key and history[key]) or {}) do include(trip,trip.seconds) end
    if session then include(session,session.last-session.start) end
    for _,spot in pairs(spots) do
        local r=estimate(spot,spot.seconds,cache)
        r.visits=spot.visits
        r.comparable=r.seconds>=900 and r.quantity>=10 and r.unpriced==0 and r.unverifiedVenue==0 and
            not r.unknownAge and r.oldestDays~=nil and r.oldestDays<=7
        local castSample=estimate({water=spot.water,items=spot.castItems},spot.castSeconds,cache)
        r.casts,r.castSeconds,r.castQuantity,r.castVisits=spot.casts,spot.castSeconds,castSample.quantity,spot.castVisits
        r.castItems=castSample.items
        r.perCast=perCast(castSample,r.casts)
        r.castComparable=r.casts>=20 and r.castSeconds>=900 and r.castQuantity>=10 and r.perCast~=nil
            and castSample.unverifiedVenue==0 and not castSample.unknownAge and castSample.oldestDays~=nil and castSample.oldestDays<=7
        rows[#rows+1]=r
    end
    table.sort(rows,function(a,b)
        if a.comparable~=b.comparable then return a.comparable end
        if a.comparable and a.perHour~=b.perHour then return a.perHour>b.perHour end
        if a.seconds~=b.seconds then return a.seconds>b.seconds end
        return a.water<b.water
    end)
    return rows
end

local function coin(copper)
    local n = math.floor(copper+0.5)
    if n >= 10000 then return string.format("%dg %02ds",math.floor(n/10000),math.floor(n/100)%100) end
    return string.format("%ds %02dc",math.floor(n/100),n%100)
end
local function rateLine(r)
    if r.perHour then
        local label=r.unverifiedVenue>0 and "/hr indicative AH value" or "/hr estimated raw AH value"
        return coin(r.perHour)..label.." ("..r.priced.."/"..r.quantity.." items priced)."
    end
    if r.catchesPerHour then return string.format("%.0f catches/hr. AH value awaits prices.",r.catchesPerHour) end
    return "Hourly rates start after five minutes."
end
local sources={manual="your entry",native="AH search",Auctionator="Auctionator"}
local function ageLabel(days)
    if days==nil then return "date unknown" end
    if days<1 then return "today" end
    return string.format("%dd ago",math.floor(days))
end
local function details(r)
    local lines={string.format("%d:%02d fished. %d items caught.",math.floor(r.seconds/60),
        math.floor(r.seconds%60),r.quantity), rateLine(r)}
    if r.castCoverage then
        local value=r.perCast and (coin(r.perCast).." per cast at quoted prices") or "per-cast value awaits complete prices"
        lines[#lines+1]=r.casts.." observed casts, including empty casts. "..value.."."
    else
        lines[#lines+1]="Incomplete cast tracking for this visit. Per-cast value unavailable."
    end
    if r.priced>0 then
        lines[#lines+1]="Raw catch: "..coin(r.copper).." at quoted prices, before fees and lure costs."
        if r.oldestDays then lines[#lines+1]="Oldest dated quote: "..ageLabel(r.oldestDays).."." end
        if r.unknownAge then lines[#lines+1]="Some price dates are unknown." end
        if r.unverifiedVenue>0 then lines[#lines+1]="Auctionator supplied "..r.unverifiedVenue.." item prices; their auction house is unverified." end
    end
    if r.unpriced>0 then lines[#lines+1]="Missing "..r.unpriced.." item prices. Search for them at the AH, or use /wyh price [item link] 20s with your own unit price." end
    local top=r.items[1]
    if top and top.copper and top.quantity==1 and #r.items>1 and top.copper>r.copper*0.5 then
        lines[#lines+1]="One "..top.name.." accounts for "..math.floor(100*top.copper/r.copper).."% of the priced catch."
    end
    for _,item in ipairs(r.items) do
        local value="No AH quote"
        if item.copper then
            value=coin(item.copper).." ("..(sources[item.source] or item.source or "quote")..", "..ageLabel(item.age)..")"
        end
        lines[#lines+1]=string.format("%d x %s  -  %s",item.quantity,item.name,value)
    end
    return table.concat(lines,"\n")
end

local function currentCut()
    if not ns.MarketKey then return end
    local _,_,cut=ns.MarketKey()
    if type(cut)=="number" and cut>=0 and cut<1 then return cut end
end
local function fresh(age) return type(age)=="number" and age>=0 and age<=7 end
local function compareBaggedFish(state,add)
    if not state or not state.bags or not ns.CookingMarketOptions then return end
    local best, rawBest, watch
    local watchCount=0
    local cut=currentCut()
    for id,count in pairs(state.bags) do
        local fish=ns.fish and ns.fish[id]
        if fish and count>0 then
            local opt=ns.CookingMarketOptions(id,state)
            if opt then
                local verifyRaw=not opt.rawCopper or opt.rawSource=="Auctionator" or not fresh(opt.rawAgeDays)
                local verifyCooked=opt.executable and (not opt.cookedCopper or opt.cookedSource=="Auctionator" or not fresh(opt.cookedAgeDays))
                if verifyRaw or verifyCooked then
                    watchCount=watchCount+1
                    if not watch or count>watch.count then
                        watch={count=count,name=verifyRaw and fish.name or opt.recipe}
                    end
                end
                local good=opt.executable and opt.netGain and not verifyRaw and not verifyCooked
                for _,ing in pairs(opt.ingredientCosts or {}) do
                    if ing.source=="Auctionator" or (ing.source~="vendor" and not fresh(ing.ageDays)) then good=false end
                end
                if good then
                    local gain=opt.netGain
                    if cut then gain=(opt.cookedCopper-opt.rawCopper)*(1-cut)-opt.extraCopper end
                    local entry={recipe=opt.recipe,rawName=fish.name,count=count,gain=gain,stackGain=gain*count,
                        station=opt.station,needs=opt.ingredientsNeeded}
                    if gain>0 and (not best or entry.stackGain>best.stackGain) then best=entry end
                    if gain<=0 and (not rawBest or entry.stackGain<rawBest.stackGain) then rawBest=entry end
                end
            end
        end
    end
    if watch then
        local text="Search for "..watch.name.." at your sale AH to confirm its current price."
        if watchCount>1 then text=text.." "..watchCount.." fish types need a fresh local price." end
        add("What to price next",text,42,"fishing-price-next",nil,false)
    end
    local suffix=cut and (" after ingredients and the "..math.floor(cut*100+.5).."% AH cut if both sell.")
        or " after ingredients, before auction fees, if both sell."
    if best then
        local text=best.recipe.." adds an estimated "..coin(best.gain).." per raw fish, "..coin(best.stackGain)..
            " for the "..best.count.." in your bags"..suffix
        if best.needs then text=text.." Pick up "..best.needs.."." end
        if best.station=="Iron Oven" then text=text.." Use an Iron Oven." end
        add("Cook "..best.rawName.." for sale",text,27,"fishing-cook-sale",nil,false)
    end
    if rawBest then
        local text=rawBest.rawName.." keeps "..coin(-rawBest.gain).." more per fish than "..rawBest.recipe..
            suffix.." Cooking skill-ups or keeping the food can still be worth it."
        add("Keep "..rawBest.rawName.." raw for sale",text,31,"fishing-raw-sale",nil,false)
    end
end

function ns.AddEconomyAdvice(state,fishAdd,tab,priceAdd)
    if not ns.FeatureEnabled("fishing") or (tab ~= "now" and tab ~= "fishing") then return end
    local prices=ns.FeatureEnabled("prices")
    local add=priceAdd or fishAdd
    if tab=="fishing" and prices then
        compareBaggedFish(state,add)
        local spots=ns.GetFishingSpots()
        if ns.AddCookingSpotAdvice then ns.AddCookingSpotAdvice(state,add,spots) end
        if #spots>0 then
            local summary={}
            local bestCast
            for _,spot in ipairs(spots) do
                if spot.castComparable and (not bestCast or spot.perCast>bestCast.perCast) then bestCast=spot end
            end
            if spots[1].comparable then
                summary[#summary+1]="Highest value per hour is "..spots[1].water.." at "..coin(spots[1].perHour).."/hr."
            end
            if bestCast then
                summary[#summary+1]="Highest value per cast is "..bestCast.water.." at "..coin(bestCast.perCast).."/cast over "..bestCast.casts.." casts."
            end
            for index,spot in ipairs(spots) do
                if index>5 then break end
                local value=spot.comparable and (coin(spot.perHour).."/hr estimated")
                    or (spot.quantity.." items; building sample or missing recent quotes")
                if spot.castComparable then value=value..", "..coin(spot.perCast).."/cast" end
                summary[#summary+1]=string.format("%s: %s (%dm, %d visits).",spot.water,value,math.floor(spot.seconds/60),spot.visits)
            end
            local market=ns.MarketLabel and ns.MarketLabel()
            if market then table.insert(summary,1,market) end
            summary[#summary+1]="Rankings use 15 minutes, 10 items and complete local prices from the last seven days. Per-cast ranking also needs 20 casts from fully tracked visits."
            add("Compare your fishing spots",table.concat(summary,"\n"),72,"fishing-waters",nil,false)
        end
    end
    if not session or (tab=="now" and GetTime()-session.last>=120) then return end
    local target = ns.WaterThreshold(state)
    local _, here = waterNow()
    if target and session.water==here and GetTime()-session.last<120 then
        fishAdd("Open-water Fishing target",here..": at "..target..
            " effective Fishing, fish stop getting away. Your pole, lure and other Fishing bonuses count.",62,
            "water-target-"..tostring(state.mapID).."-"..target,nil,true)
    end
    if not prices then return end
    local r=ns.GetFishingEstimate()
    local market=ns.MarketLabel and ns.MarketLabel()
    if not market and ns.MarketKey then local _,label=ns.MarketKey(); market=label end
    add("Fishing session: "..r.water,(market and (market.."\n") or "")..details(r),28,"fishing-economy:"..r.water,nil,r.perHour~=nil)
end

local fishingIDs={[7620]=true,[7731]=true,[7732]=true,[18248]=true,[131474]=true}
local function spellName(id)
    if not id then return end
    if C_Spell and C_Spell.GetSpellName then return C_Spell.GetSpellName(id) end
    if GetSpellInfo then return GetSpellInfo(id) end
end
local function isFishing(id)
    if fishingIDs[id] then return true end
    local name=spellName(id)
    return name and name==spellName(7620)
end

local function snapshotLoot()
    if not IsFishingLoot or not IsFishingLoot() then pendingLoot=nil; return end
    if not pendingLoot then
        pendingLoot={}
        if castForLoot and GetTime()-castForLoot.started<60 then pendingLoot.observedTrip=castForLoot.trip end
        castForLoot=nil
    end
    for slot=1,GetNumLootItems() do
        if pendingLoot[slot]==nil then
            local link=GetLootSlotLink(slot)
            local id=link and tonumber(link:match("item:(%d+)"))
            if id then
                local _,name,count=GetLootSlotInfo(slot)
                pendingLoot[slot]={id=id,link=link,name=name or ("Item "..id),count=tonumber(count) or 1}
            end
        end
    end
end
local tracker=CreateFrame("Frame")
for _,event in ipairs({"UNIT_SPELLCAST_CHANNEL_START","UNIT_SPELLCAST_CHANNEL_STOP","LOOT_READY","LOOT_OPENED",
        "LOOT_SLOT_CLEARED","LOOT_CLOSED","PLAYER_ENTERING_WORLD","PLAYER_LOGOUT","PLAYER_REGEN_DISABLED"}) do
    tracker:RegisterEvent(event)
end
tracker:SetScript("OnEvent",function(frame,event,arg,castGUID,id)
    if not ns.FeatureEnabled("fishing") then return end
    if event=="UNIT_SPELLCAST_CHANNEL_START" and arg=="player" then
        if isFishing(id) then
            local identified=type(castGUID)=="string" and castGUID~=""
            if identified and (previousCastGUIDs[castGUID] or (session and session.seenCastGUIDs[castGUID])) then return end
            local state=touch()
            if identified then
                session.seenCastGUIDs[castGUID]=true
                session.casts=session.casts+1
                castForLoot={trip=session,started=GetTime()}
            else
                session.castCoverage=false
                castForLoot=nil
            end
            pendingLoot=nil
            fishingChannel=castGUID or true
            refresh()


        else
            fishingChannel,castForLoot=nil,nil
        end
    elseif event=="UNIT_SPELLCAST_CHANNEL_STOP" and arg=="player" and fishingChannel and
        (not castGUID or fishingChannel==true or castGUID==fishingChannel) then
        fishingChannel=false
        touch()
        refresh()
    elseif event=="LOOT_READY" or event=="LOOT_OPENED" then snapshotLoot()
    elseif event=="LOOT_SLOT_CLEARED" then
        local item=pendingLoot and pendingLoot[arg]
        if item then
            pendingLoot[arg]=false
            local state=touch()
            if pendingLoot.observedTrip~=session then session.castCoverage=false end
            local variant=ns.MarketVariantKey and ns.MarketVariantKey(item.id,item.link)
            local key=variant and (tostring(item.id).."/"..tostring(variant)) or item.id
            local stack=session.items[key] or {id=item.id,link=item.link,name=item.name,count=0}
            stack.count=stack.count+item.count
            session.items[key]=stack

            refresh()
        end
    elseif event=="LOOT_CLOSED" then pendingLoot=nil
    elseif event=="PLAYER_ENTERING_WORLD" or event=="PLAYER_LOGOUT" then
        pendingLoot=nil; fishingChannel=false; archive()

    end
end)

function ns.PauseFishingTracking()
    archive()
    pendingLoot, fishingChannel, castForLoot=nil,nil,nil
end
function ns.ResetFishingSession()
    ns.PauseFishingTracking()
    refresh()
end
SLASH_ROSETHORNFISH1="/rtafish"
function ns.FishingCommand(input)
    local cmd=(input or ""):lower():match("^%s*(.-)%s*$")
    if cmd=="off" or cmd=="on" then
        ns.SetFeatureEnabled("fishing",cmd=="on")
        print(ns.title.." - Fishing advice "..cmd..".")
    elseif cmd=="reset" then
        ns.ResetFishingSession()
    elseif not ns.FeatureEnabled("fishing") then
        print(ns.title.." - Fishing advice is off. Type /wyh fish on to enable it.")
    elseif not ns.FeatureEnabled("prices") then
        print(session and (session.water.." - "..session.casts.." observed casts.") or (ns.title.." - Cast to start a fishing session."))
    else
        local r=ns.GetFishingEstimate()
        print(r and (r.water.."\n"..details(r)) or (ns.title.." - Cast to start a fishing session."))
        print("/wyh fish on, off or reset")
    end
end
SlashCmdList.ROSETHORNFISH=ns.FishingCommand
