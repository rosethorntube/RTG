local _, ns = ...
local Map = {}
ns.AdvisorMap = Map

local dirty = true
local ownedPoint
local pins = {}
local lastCanvas, lastMap, lastW, lastH, lastRecord
local hud, label, detail, strokes
local mapAPI

local function call(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, a, b, c, d = pcall(fn, ...)
    if ok then return a, b, c, d end
end

local function now()
    return call(GetServerTime) or call(time) or 0
end

local function data(create)
    local record = ns.CurrentRecord and ns.CurrentRecord()
    if not record then return nil end
    if not record.advisorMap and create then record.advisorMap = {marks = {}} end
    return record.advisorMap
end

local function valid(x)
    return type(x) == "number" and x >= 0 and x <= 1
end

function Map.waypointAvailable(g)
    return type(g) == "table" and type(g.mapID) == "number" and g.mapID > 0
        and valid(g.x) and valid(g.y)
end

function Map.key(g)
    if not Map.waypointAvailable(g) then return nil end
    return ("%d:%.4f:%.4f:%s"):format(g.mapID, g.x, g.y, tostring(g.npcID or g.name or ""))
end

local function stored(g)
    return {mapID = g.mapID, x = g.x, y = g.y, npcID = g.npcID, name = g.name,
        quests = {}, updated = now()}
end

local function addIDs(entry, g, ids)
    local function add(id)
        id = tonumber(id)
        if id and id > 0 then entry.quests[id] = true end
    end
    add(g.questID)
    if type(ids) == "table" then
        for k, v in pairs(ids) do add(v == true and k or v) end
    else
        add(ids)
    end
    entry.updated = now()
end

local function changed()
    dirty = true
    if ns.RequestRefresh then ns.RequestRefresh() end
end

function Map.getIsMarked(g)
    local s, key = data(), Map.key(g)
    return not not (s and key and s.marks[key])
end

function Map.setMarked(g, enable, ids)
    local key = Map.key(g)
    if not key then return false end
    local s = data(enable)
    if not s then return false end
    if enable then
        local slot = s.marks[key] or stored(g)
        s.marks[key] = slot
        addIDs(slot, g, ids)
    else
        s.marks[key] = nil
    end
    changed()
    return true
end

local function xy(vec)
    if not vec then return nil end
    if vec.GetXY then return call(vec.GetXY, vec) end
    return vec.x, vec.y
end

local function readPoint()
    mapAPI = C_Map or {}
    local point = call(mapAPI.GetUserWaypoint)
    if not point then return nil end
    local x, y = xy(point.position)
    if valid(x) and valid(y) then return {mapID = point.uiMapID, x = x, y = y} end
end

local function equalPoint(a, b)
    return a and b and a.mapID == b.mapID and math.abs(a.x - b.x) < 0.0001
        and math.abs(a.y - b.y) < 0.0001
end

local function release(point)
    if point and equalPoint(point, readPoint()) then
        call(mapAPI.ClearUserWaypoint)
    end
    ownedPoint = nil
end

local function native(g)
    mapAPI = C_Map or {}
    if not mapAPI.GetUserWaypoint or not mapAPI.SetUserWaypoint then return end
    if readPoint() then return end
    if call(mapAPI.CanSetUserWaypointOnMap, g.mapID) == false then return end
    local point = call(UiMapPoint and UiMapPoint.CreateFromCoordinates, g.mapID, g.x, g.y)
    if not point then return end
    call(mapAPI.SetUserWaypoint, point)
    if equalPoint(readPoint(),g) then
        ownedPoint = g
        g.nativeOwned = true
        call(C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint, true)
    end
end

function Map.isTarget(g)
    local s, key = data(), Map.key(g)
    return not not (s and key and s.active and key == Map.key(s.active))
end

function Map.navigate(g, ids)
    if not Map.waypointAvailable(g) then return false, "No known location." end
    local s = data(true)
    if not s then return false, "Character data is loading." end
    local same = Map.isTarget(g)
    if not same then
        if s.active and s.active.nativeOwned then release(s.active) end
        s.active = stored(g)
    end
    local marker = s.marks[Map.key(g)]
    if marker then addIDs(s.active, g, marker.quests) end
    addIDs(s.active, g, ids)
    if not same then native(s.active) end
    changed()
    return true
end

function Map.stop()
    local s = data()
    if s and s.active then
        if s.active.nativeOwned then release(s.active) end
        s.active = nil
        if hud then hud:Hide() end
        changed()
    end
end

local function finished(id)
    local q = C_QuestLog or {}
    if call(q.IsQuestFlaggedCompleted, id) or call(q.IsOnQuest, id) then return true end
    local index = call(q.GetLogIndexForQuestID, id) or call(GetQuestLogIndexByID, id)
    return type(index) == "number" and index > 0
end

local function prune(eventID)
    local s = data()
    if not s then return end
    local modified
    local function empty(entry)
        local removed
        for id in pairs(entry.quests) do
            if (eventID and tonumber(id) == eventID) or (not eventID and finished(tonumber(id))) then
                entry.quests[id] = nil
                removed, modified = true, true
            end
        end
        return removed and not next(entry.quests)
    end
    for key, entry in pairs(s.marks) do
        if empty(entry) then s.marks[key] = nil end
    end
    if s.active and empty(s.active) then Map.stop() end
    if modified then changed() end
end

local function makeVec(x, y)
    return call(CreateVector2D, x, y)
end

local function onMap(g, viewID)
    if g.mapID == viewID then return g.x, g.y end
    local ancestor = g.mapID
    for _ = 1, 16 do
        local info = call(mapAPI.GetMapInfo, ancestor)
        ancestor = info and info.parentMapID
        if not ancestor or ancestor == 0 then return end
        if ancestor == viewID then
            local l,r,t,b = call(mapAPI.GetMapRectOnMap, g.mapID, viewID)
            if valid(l) and valid(r) and valid(t) and valid(b) and r > l and b > t then
                return l + g.x * (r-l), t + g.y * (b-t)
            end
            return
        end
    end
end

local function newPin(canvas)
    local pin = CreateFrame("Button", nil, canvas)
    pin:SetSize(18, 18)
    pin:SetFrameLevel(canvas:GetFrameLevel() + 80)
    local icon = pin:CreateTexture(nil, "ARTWORK")
    icon:SetAllPoints()
    icon:SetTexture("Interface\\GossipFrame\\AvailableQuestIcon")
    pin:RegisterForClicks("LeftButtonUp","RightButtonUp")
    pin:SetScript("OnClick", function(self, button)
        if not self.giver then return end
        if button == "RightButton" then
            Map.setMarked(self.giver, false)
            if GameTooltip then GameTooltip:Hide() end
        else
            Map.navigate(self.giver, self.giver.quests)
        end
    end)
    pin:SetScript("OnEnter", function(self)
        if not GameTooltip or not self.giver then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(self.giver.name or "Quest giver")
        GameTooltip:AddLine(("%.1f, %.1f  ·  Click to navigate"):format(self.giver.x*100,self.giver.y*100), 1,.83,.2)
        GameTooltip:AddLine("Right-click to remove this marker.", 1,1,1)
        GameTooltip:Show()
    end)
    pin:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
    return pin
end

local function drawPins(s)
    local map = WorldMapFrame
    if not map or not map.GetCanvas or not map:IsShown() then lastMap = nil return end
    local canvas, id = map:GetCanvas(), map:GetMapID()
    if not canvas or not id then lastMap = nil return end
    local w, h = canvas:GetWidth(), canvas:GetHeight()
    if w <= 0 or h <= 0 then lastMap = nil return end
    if not dirty and canvas == lastCanvas and id == lastMap and w == lastW and h == lastH then return end
    dirty, lastCanvas, lastMap, lastW, lastH = false, canvas, id, w, h
    local used = 0
    for _, g in pairs((s and s.marks) or {}) do
        local x,y = onMap(g, id)
        if x then
            used = used + 1
            local pin = pins[used] or newPin(canvas)
            pins[used] = pin
            if pin:GetParent() ~= canvas then
                pin:SetParent(canvas)
                pin:SetFrameLevel(canvas:GetFrameLevel()+80)
            end
            pin.giver = g
            pin:ClearAllPoints()
            pin:SetPoint("CENTER", canvas, "TOPLEFT", x*w, -y*h)
            pin:Show()
        end
    end
    for i = used+1, #pins do pins[i].giver = nil; pins[i]:Hide() end
end

local function makeHud()
    hud = CreateFrame("Button", nil, UIParent)
    hud:SetSize(220, 42)
    hud:SetPoint("TOP", UIParent, "TOP", 0, -110)
    hud:RegisterForClicks("RightButtonUp")
    hud:SetScript("OnClick", Map.stop)
    hud:SetScript("OnEnter", function(self)
        if GameTooltip then
            GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
            GameTooltip:SetText("Quest giver navigation")
            GameTooltip:AddLine("Right-click to stop.", 1,1,1)
            GameTooltip:Show()
        end
    end)
    hud:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
    local bg = hud:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(.04,.05,.07,.82)
    label = hud:CreateFontString(nil,"OVERLAY","GameFontNormal")
    label:SetPoint("TOPLEFT", hud, "TOPLEFT", 40, -5)
    label:SetPoint("TOPRIGHT", hud, "TOPRIGHT", -4, -5)
    label:SetJustifyH("LEFT")
    detail = hud:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    detail:SetPoint("BOTTOMLEFT", hud, "BOTTOMLEFT", 40, 6)
    detail:SetPoint("BOTTOMRIGHT", hud, "BOTTOMRIGHT", -4, 6)
    detail:SetJustifyH("LEFT")
    strokes = {}
    if hud.CreateLine then
        for i = 1,3 do
            local ln = hud:CreateLine(nil, "OVERLAY")
            ln:SetThickness(2.5)
            ln:SetColorTexture(1,.83,.2,1)
            strokes[i] = ln
        end
    end
end

local function drawArrow(right, forward)
    for _,line in ipairs(strokes) do line:Hide() end
    if not right or #strokes ~= 3 then return end
    local function segment(i,a,b,c,d)
        local ln = strokes[i]
        ln:SetStartPoint("LEFT", hud, 19+a,b)
        ln:SetEndPoint("LEFT", hud, 19+c,d)
        ln:Show()
    end
    local x,y = 11*right,11*forward
    segment(1,-x,-y,x,y)
    segment(2,x,y,.3*x+.6*y,.3*y-.6*x)
    segment(3,x,y,.3*x-.6*y,.3*y+.6*x)
end

local function delta(g)
    local here = call(mapAPI.GetBestMapForUnit, "player")
    if not here then return end
    local same = here == g.mapID
    -- Quarter/micro maps can share a city's coordinate space. Check that a real
    -- map rectangle nests one inside the other, excluding larger travel maps.
    if not same then
        local info = call(mapAPI.GetMapInfo, here)
        local dest = call(mapAPI.GetMapInfo, g.mapID)
        if not info or not dest or not info.mapType or not dest.mapType
            or info.mapType < 3 or dest.mapType < 3 then return end
        local current = {mapID = here, x = .5, y = .5}
        if not onMap(current, g.mapID) and not onMap(g, here) then return end
    end
    local pos = call(mapAPI.GetPlayerMapPosition, here, "player")
    local px,py = xy(pos)
    if not valid(px) or not valid(py) then return end
    local vec = makeVec(g.x, g.y)
    if vec then
        local a, p = call(mapAPI.GetWorldPosFromMapPos, here, pos)
        local b, t = call(mapAPI.GetWorldPosFromMapPos, g.mapID, vec)
        local pn,pw = xy(p)
        local tn,tw = xy(t)
        if a and a == b and pn and pw and tn and tw then return tn-pn, tw-pw end
    end
    if not same then return end
    local width,height = call(mapAPI.GetMapWorldSize, here)
    if type(width) == "number" and type(height) == "number" and width > 0 and height > 0 then
        return (py-g.y)*height, (px-g.x)*width
    end
end

local function direction(right, forward)
    if math.abs(right) > math.abs(forward) then return right > 0 and "Right" or "Left" end
    return forward > 0 and "Ahead" or "Behind"
end

local function drawNavigation(s)
    local g = s and s.active
    if not g then if hud then hud:Hide() end return end
    if not hud then makeHud() end
    hud:Show()
    label:SetText(g.name or "Quest giver")
    local north,west = delta(g)
    if north then
        local distance = math.sqrt(north*north+west*west)
        if distance <= 7 then drawArrow(); detail:SetText("At the quest giver"); return end
        local face = call(GetPlayerFacing)
        if type(face) == "number" then
            local right = (north*math.sin(face)-west*math.cos(face))/distance
            local forward = (north*math.cos(face)+west*math.sin(face))/distance
            drawArrow(right,forward)
            detail:SetText(("%s  ·  %d yd direct"):format(direction(right,forward),math.floor(distance+.5)))
            return
        end
    end
    drawArrow()
    local info = call(mapAPI.GetMapInfo, g.mapID)
    local name = info and info.name or "Map "..g.mapID
    local here = call(mapAPI.GetBestMapForUnit, "player")
    if here ~= g.mapID then
        detail:SetText("Travel to "..name)
    else
        detail:SetText(("%s  %.1f, %.1f"):format(name,g.x*100,g.y*100))
    end
end

function Map.refresh()
    dirty = true
end

local ticker = CreateFrame("Frame")
local elapsed = 1
ticker:SetScript("OnUpdate", function(_, dt)
    elapsed = elapsed + dt
    if elapsed < .25 then return end
    elapsed = 0
    mapAPI = C_Map or {}
    local s = data()
    if s ~= lastRecord then
        dirty = true
        ownedPoint = s and s.active and s.active.nativeOwned and s.active or nil
        lastRecord = s
    end
    drawPins(s)
    drawNavigation(s)
end)
for _, e in ipairs({"PLAYER_ENTERING_WORLD", "QUEST_LOG_UPDATE", "QUEST_ACCEPTED", "QUEST_TURNED_IN",
    "USER_WAYPOINT_UPDATED"}) do call(ticker.RegisterEvent, ticker, e) end
ticker:SetScript("OnEvent", function(_, e, a, b)
    if e == "USER_WAYPOINT_UPDATED" then
        -- A player's replacement or removal supersedes our native waypoint.
        local s = data()
        if ownedPoint and s and s.active == ownedPoint and not equalPoint(ownedPoint, readPoint()) then
            s.active.nativeOwned, ownedPoint = nil, nil
        end
    elseif e == "QUEST_ACCEPTED" then prune(tonumber(b) or tonumber(a))
    elseif e == "QUEST_TURNED_IN" then prune(tonumber(a))
    else prune() end
    dirty = true
end)
