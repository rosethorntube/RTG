local _,ns=...

local sample={title="Fish while waiting in Ratchet",body="Cast from the pier. Kilxx sells the Rainbow Fin Albacore recipe beside the waterfront."}
local empty={title="All caught up",body="New suggestions appear here as you travel, level up and collect materials."}

local function questID(item)
    return tonumber((item.key or ""):match("^dungeon:pickup:(%d+)$"))
end

local function makeText(parent,font)
    local t=parent:CreateFontString(nil,"OVERLAY",font)
    t:SetJustifyH("LEFT")
    t:SetJustifyV("TOP")
    t:SetWordWrap(true)
    return t
end

local function textStyle(label,cfg,size)
    local hex=cfg.fg
    label:SetFont(STANDARD_TEXT_FONT,size,"")
    label:SetTextColor(tonumber(hex:sub(1,2),16)/255,tonumber(hex:sub(3,4),16)/255,
        tonumber(hex:sub(5,6),16)/255,cfg.fgAlpha/100)
end

-- Both suggestion views use the same per-giver marker and active route.
function ns.PickupGroups(items)
    local groups,byRow={},{}
    local map=ns.AdvisorMap
    if not map then return groups,byRow end
    for _,item in ipairs(items) do
        local id=questID(item)
        local key=id and item.target and map.key(item.target)
        if key then
            groups[key]=groups[key] or {}
            groups[key][#groups[key]+1]=id
            byRow[item]=key
        end
    end
    return groups,byRow
end

function ns.CreatePickupControls(c,changed)
    c.mark=CreateFrame("CheckButton",nil,c,"UICheckButtonTemplate")
    c.mark:SetSize(24,24)
    c.markLabel=makeText(c.mark,"GameFontHighlightSmall")
    c.markLabel:SetText("Mark on map")
    c.markLabel:SetPoint("LEFT",c.mark,"RIGHT",1,0)
    if c.mark.SetHitRectInsets then c.mark:SetHitRectInsets(0,-80,0,0) end
    c.mark:SetScript("OnClick",function(self)
        if not c.mapKey then return end
        ns.AdvisorMap.setMarked(c.mapTarget,self:GetChecked() and true or false,c.questIDs)
        changed()
    end)
    c.go=ns.AdvisorButton(c,"Navigate",87,21,function()
        if not c.mapKey then return end
        local map=ns.AdvisorMap
        if map.isTarget(c.mapTarget) then map.stop() else map.navigate(c.mapTarget,c.questIDs) end
        changed()
    end)
    c.go:SetPoint("LEFT",c.mark,"RIGHT",85,0)
end

function ns.UpdatePickupControls(c,target,key,ids)
    c.mapTarget,c.mapKey,c.questIDs=target,key,ids
    c.mark:SetShown(key~=nil)
    c.go:SetShown(key~=nil)
    if key then
        local map=ns.AdvisorMap
        c.mark:SetChecked(map.getIsMarked(target))
        local navigating=map.isTarget(target)
        c.go:SetText(navigating and "Stop route" or "Navigate")
        c.go:SetEnabled(navigating or map.waypointAvailable(target))
    end
end

function ns.CreateSuggestionsList(parent,discard,acknowledge,changed)
    local scroll=CreateFrame("ScrollFrame",nil,parent,"UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT",parent,"TOPLEFT",10,-32)
    scroll:SetPoint("BOTTOMRIGHT",parent,"BOTTOMRIGHT",-32,8)
    local child=CreateFrame("Frame",nil,scroll)
    child:SetSize(200,1)
    scroll:SetScrollChild(child)
    local cards={}
    local list={scroll=scroll}
    local rendering,displayOnly,focus,pendingFocus=false,false,nil,false
    local function isOpen()
        if parent.IsVisible then return parent:IsVisible() end
        return parent:IsShown()
    end

    local function readViewport()
        if not isOpen() or displayOnly then return end
        local top=scroll:GetVerticalScroll()
        local bottom=top+scroll:GetHeight()
        local newlyRead=false
        for _,card in ipairs(cards) do
            -- The heading must enter the viewport. Merely creating a widget
            -- below the fold must not clear the alert on an unread suggestion.
            if card.item and card.item.alert and card.top+card.headingHeight>top and card.top<bottom then
                if acknowledge(card.item) then newlyRead=true end
            end
        end
        return newlyRead
    end

    local function onScroll()
        if not rendering and readViewport() then changed() end
    end
    if scroll.HookScript then
        scroll:HookScript("OnVerticalScroll",onScroll)
    else
        local previous=scroll:GetScript("OnVerticalScroll")
        scroll:SetScript("OnVerticalScroll",function(self,value)
            if previous then previous(self,value) end
            onScroll()
        end)
    end

    local function createCard()
        local c=CreateFrame("Frame",nil,child)
        c.title=makeText(c,"GameFontNormal")
        c.title:SetPoint("TOPLEFT")
        c.body=makeText(c,"GameFontHighlightSmall")
        c.dismiss=ns.AdvisorButton(c,"Dismiss",62,21,function() if c.item then discard(c.item,false) end end)
        c.mute=ns.AdvisorButton(c,"Don't show again",118,21,function() if c.item then discard(c.item,true) end end)
        c.mute:SetPoint("LEFT",c.dismiss,"RIGHT",3,0)
        ns.CreatePickupControls(c,changed)
        c.rule=c:CreateTexture(nil,"ARTWORK")
        c.rule:SetColorTexture(0.65,0.55,0.34,0.35)
        c.rule:SetHeight(1)
        c.rule:SetPoint("BOTTOMLEFT")
        c.rule:SetPoint("BOTTOMRIGHT")
        return c
    end

    function list:FocusOn(key)
        focus,pendingFocus=key,true
    end

    function list:Render(items,cfg,preview)
        if rendering or not isOpen() then return end
        rendering=true
        displayOnly=preview or #items==0
        local shown=preview and {sample} or (#items==0 and {empty} or items)
        local width=math.max(110,parent:GetWidth()-44)
        local y,focusAt=0,0
        local matched,byRow=ns.PickupGroups(shown)
        for i,item in ipairs(shown) do
            local c=cards[i]
            if not c then c=createCard();cards[i]=c end
            c.item=item
            c.top=y
            if focus and item.key==focus then focusAt=y end
            c:ClearAllPoints()
            c:SetPoint("TOPLEFT",child,"TOPLEFT",1,-y)
            c:SetWidth(width)
            textStyle(c.title,cfg,cfg.font+2)
            textStyle(c.body,cfg,cfg.font)
            c.title:SetWidth(width)
            c.title:SetText(item.title or "")
            c.headingHeight=math.max(cfg.font+2,c.title:GetStringHeight())
            c.body:ClearAllPoints()
            c.body:SetPoint("TOPLEFT",0,-c.headingHeight-4)
            c.body:SetWidth(width)
            c.body:SetText(item.body or "")
            local offset=c.headingHeight+4+math.max(cfg.font,c.body:GetStringHeight())+5
            local key=byRow[item]
            ns.UpdatePickupControls(c,item.target,key,matched[key])
            if key then
                c.mark:ClearAllPoints()
                c.mark:SetPoint("TOPLEFT",-2,-offset)
                offset=offset+26
            end
            c.dismiss:SetShown(not displayOnly)
            c.mute:SetShown(not displayOnly)
            if not displayOnly then
                c.dismiss:ClearAllPoints()
                c.dismiss:SetPoint("TOPLEFT",0,-offset)
                offset=offset+22
            end
            c.rule:SetShown(i<#shown)
            c:SetHeight(offset+8)
            c:Show()
            y=y+offset+15
        end
        for i=#shown+1,#cards do
            local c=cards[i]
            c.item,c.mapKey=nil,nil
            c:Hide()
        end
        child:SetSize(width+2,math.max(1,y-7))
        scroll:UpdateScrollChildRect()
        local old=scroll:GetVerticalScroll()
        local to=math.min(pendingFocus and focusAt or old,scroll:GetVerticalScrollRange())
        if old~=to then scroll:SetVerticalScroll(to) end
        pendingFocus,focus=false,nil
        readViewport()
        rendering=false
    end
    return list
end
