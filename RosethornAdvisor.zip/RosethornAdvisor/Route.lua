local _, ns = ...

local BARRENS, STRANGLETHORN, FERALAS = 1413, 1434, 1444
local camp = {mapID=FERALAS, x=0.745, y=0.427, name="Sheendra Tallgrass, Camp Mojache"}
local heming = {mapID=STRANGLETHORN, x=0.274, y=0.770, name="Old Man Heming, Booty Bay"}
local nat = {mapID=1445, x=0.586, y=0.600, name="Nat Pagle, Tidefury Cove"}
local ports = {
    [STRANGLETHORN]={mapID=STRANGLETHORN, x=0.261, y=0.734, name="Booty Bay"},
    [BARRENS]={mapID=BARRENS, x=0.636, y=0.387, name="Ratchet"},
}
local zoneNames = {
    [BARRENS]="The Barrens", [STRANGLETHORN]="Stranglethorn Vale", [FERALAS]="Feralas",
    [1454]="Orgrimmar", [1456]="Thunder Bluff", [1458]="Undercity",
}
local function near(x,y,cx,cy,span)
    return type(x)=="number" and type(y)=="number"
        and math.abs(x-cx)<=span and math.abs(y-cy)<=span
end
local function nearCamp(mapID,x,y)
    return mapID==FERALAS and near(x,y,0.752,0.441,0.026)
end
local function playerAtCamp(s)
    return s.mapID==FERALAS and (s.subzone=="Camp Mojache" or s.zone=="Camp Mojache"
        or nearCamp(s.mapID,s.x,s.y))
end
local function portForPlayer(s)
    local port=ports[s.mapID]
    if port and (s.subzone==port.name or s.zone==port.name or near(s.x,s.y,port.x,port.y,0.018)) then
        return port
    end
end
local function activeElement()
    -- RXPGuides' map.lua retains the last element when it hides the arrow.
    -- Nothing in this adapter reads a guide's future steps or advances the guide.
    local frame=_G.RXPG_ARROW
    if not frame or (frame.IsShown and not frame:IsShown()) then return end
    local e=frame.element
    if type(e)~="table" or not e.step or not e.step.active or e.step.completed
        or e.skip or e.completed or e.hidden or (e.parent and (e.parent.skip or e.parent.completed)) then return end
    if type(e.zone)~="number" or type(e.x)~="number" or type(e.y)~="number" then return end
    if e.x<0 or e.x>100 or e.y<0 or e.y>100 then return end
    return e
end
local function boatInstruction(e)
    if not e then return false end
    if e.tag=="boat" or (e.source and e.source.tag=="boat") then return true end
    -- A .goto frequently sits on a different element to its human-readable instruction.
    -- Match a transport verb on the current step, not incidental quest or NPC names.
    local function transport(v)
        if type(v)~="table" then return false end
        if v.tag=="boat" then return true end
        local str=type(v.text)=="string" and v.text or v.rawtext
        if type(str)~="string" then return false end
        str=str:lower()
        return str:find("take the boat",1,true) or str:find("board the boat",1,true)
            or str:find("wait for the boat",1,true) or str:find("take the ship",1,true)
            or str:find("board the ship",1,true) or str:find("wait for the ship",1,true)
    end
    if transport(e) or transport(e.parent) or transport(e.source) then return true end
    for _,v in ipairs(e.step.elements or {}) do
        if not v.skip and not v.completed and transport(v) then return true end
    end
    return false
end
local manualNames={camp="Camp Mojache",boat="Boat crossing",leavebarrens="Leaving the Barrens"}

-- Returns actionable travel context. camp means present in or heading to the settlement.
-- awayFromBarrens only applies while in that zone. boat means a crossing is intended.
-- The compass and reason are safe to show even when the guide is absent or closed.
function ns.GetRouteContext(s)
    local result={camp=playerAtCamp(s), awayFromBarrens=false, boat=false,
        compass="Current location", reason="Location and profession ranks"}
    local manual=s.destination
    if manualNames[manual] then
        result.camp=result.camp or manual=="camp"
        result.boat=manual=="boat"
        result.awayFromBarrens=s.mapID==BARRENS and (manual=="leavebarrens" or manual=="camp"
            or (manual=="boat" and portForPlayer(s)~=nil))
        result.compass="Selected: "..manualNames[manual]
        result.reason="Selected destination"
        return result
    end
    local e=activeElement()
    if not e then return result end
    local mapInfo=C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(e.zone)
    local label=zoneNames[e.zone] or (mapInfo and mapInfo.name) or ("map "..e.zone)
    local campBound=nearCamp(e.zone,e.x/100,e.y/100)
    result.camp=result.camp or campBound
    result.boat=boatInstruction(e)
    result.awayFromBarrens=s.mapID==BARRENS and (e.zone~=BARRENS or
        (result.boat and portForPlayer(s)~=nil))
    result.compass=("RestedXP: %s %.1f, %.1f"):format(campBound and "Camp Mojache" or label,e.x,e.y)
    result.reason="Active RestedXP waypoint"
    return result
end

local function catchWindow(hour)
    if type(hour)~="number" then return "Nightfin peaks 00:00-06:00, Sunscale 12:00-18:00 realm time." end
    if hour<6 then return "Until 06:00 realm time, target Nightfin Snapper for caster food." end
    if hour>=12 and hour<18 then return "Until 18:00 realm time, target Sunscale Salmon for attack food." end
    return "Nightfin Snapper and Sunscale Salmon can both bite now. Nightfin peaks 00:00-06:00, Sunscale 12:00-18:00 realm time."
end
local function effectiveFishing(f)
    return f.rank + (f.modifier or 0) + (f.temp or 0)
end
local function fishCamp(s,context,add)
    local f=s.skills.Fishing
    if not f or not context.camp then return end
    local here=playerAtCamp(s)
    local effective=effectiveFishing(f)
    local text
    if effective<205 then
        text=("The inland lake south of camp needs 205 effective Fishing. You have %d with current bonuses."):format(effective)
        if f.rank>=100 then text=text.." Sheendra Tallgrass sells Bright Baubles (+75)." end
    else
        text="Fish the inland lake just south of Camp Mojache. "..catchWindow(s.hour)
        if effective<300 then text=text.." Sheendra Tallgrass sells Bright Baubles to cut down on escapes." end
    end
    if f.rank<225 and f.cap>=225 then
        text=text..(" Catch fish to raise base Fishing from %d to 225 for Nat Pagle."):format(f.rank)
    end
    local cook=s.skills.Cooking
    if cook and (effective>=205 or f.rank>=130) then
        if cook.rank<225 and cook.cap>=225 then
            text=text..(" Raise Cooking from %d to 225 for Filet of Redgill. Bank Nightfin and Sunscale for Cooking 250."):format(cook.rank)
        elseif cook.rank<250 then
            text=text.." Bank Nightfin and Sunscale until you can cook them at 250."
        else
            text=text.." Gikkix in Steamwheedle Port sells both recipes. Soup needs spring water. Salmon needs an Iron Oven."
        end
    end
    add(here and "Fish at Camp Mojache, Feralas" or "Upcoming: Camp Mojache, Feralas",
        text,here and 22 or 35,here and "camp-fishing" or "camp-upcoming",camp,true)
end
local function fishingRank(s,add)
    local f=s.skills.Fishing
    if not f then return end
    local book=(s.bags or {})[16083] or 0
    local port=portForPlayer(s)
    if f.cap==150 and (f.rank>=140 or (port==ports[STRANGLETHORN] and f.rank>=100)) then
        local ready=f.rank>=125 and s.level>=20
        local body
        if book>0 then
            body=ready and "Read Expert Fishing - The Bass and You from your bags to raise your cap to 225."
                or "Keep the book in your bags. Read it at level 20 and base Fishing 125 to raise your cap to 225."
            add("Expert Fishing book in your bags",body,23,"fishing-book-read",nil,ready)
        else
            body="Old Man Heming sells Expert Fishing - The Bass and You for 1g. From the lower boardwalk in Booty Bay, look for the fishing sign at 27.4, 77.0. Read at level 20 and base Fishing 125."
            add("Prepare for Fishing above 150",body,port==ports[STRANGLETHORN] and 20 or 45,"fishing-book",heming,
                port==ports[STRANGLETHORN] or (ready and f.rank>=145))
        end
    elseif f.cap==225 and f.rank>=215 then
        local ready=f.rank>=225 and s.level>=35
        local active=C_QuestLog and C_QuestLog.IsOnQuest and C_QuestLog.IsOnQuest(6607)
        if active then
            local body="With Nat's quest active, catch the four named fish. The Feralas Ahi comes from Verdantis River. Return to Nat at Tidefury Cove when you have all four."
            add("Finish Nat Pagle, Angler Extreme",body,30,"artisan-fishing",nat)
        else
            local body=("Fishing %d/225. At level 35 and base Fishing 225, speak to Nat Pagle on the small island in Tidefury Cove, Dustwallow Marsh (58.6, 60.0). Accept his quest before fishing for its four catches."):format(f.rank)
            add(ready and "Pick up Artisan Fishing" or "Prepare for Artisan Fishing",body,ready and 26 or 46,"artisan-fishing",nat,ready)
        end
    end
end
function ns.AddRouteAdvice(s,add)
    local c=ns.GetRouteContext(s)
    fishCamp(s,c,add)
    fishingRank(s,add)
    local m=s.skills.Mining
    if c.awayFromBarrens and m and m.cap>=125 and m.rank>=115 and m.rank<125 then
        local body=("Mining %d/125. Mine Tin and any Silver on the way out of the Barrens. %d more skill unlocks Iron Deposits."):format(m.rank,125-m.rank)
        add("Mine before leaving the Barrens",body,17,"barrens-mining",nil,true)
    end
    local port=portForPlayer(s)
    local f=s.skills.Fishing
    if port and f and (c.boat or near(s.x,s.y,port.x,port.y,0.008)) then
        local body
        if port==ports[STRANGLETHORN] then
            body="Cast into the harbour from the pier. Raw Rockscale Cod uses Cooking 175. Kelsey Yance sells the recipe inside the Old Port Authority, straight up the dock and left on the lower deck."
            if effectiveFishing(f)<130 then
                body="Bring effective Fishing to 130 with your pole and lure. "..body
            elseif effectiveFishing(f)<225 then
                body=body.." A lure helps until you reach 225 effective Fishing."
            end
        else
            body="Cast into the sea beside the Ratchet pier. Keep Raw Rainbow Fin Albacore for Cooking 50. Kilxx sells the recipe on the waterfront (62.8, 38.2)."
            if effectiveFishing(f)<75 then body=body.." A lure helps until you reach 75 effective Fishing." end
        end
        add(c.boat and ("Fish while waiting for the boat in "..port.name) or ("Fish from the "..port.name.." pier"),
            body,25,"boat-fishing-"..s.mapID,port,true)
    end
    if (s.mapID==1454 or s.mapID==1456 or s.mapID==1458) and f and f.cap==75 and f.rank>=65 then
        add("Train Journeyman Fishing in "..zoneNames[s.mapID],"Ask a city guard for the fishing trainer while you are here. Journeyman raises your cap from 75 to 150.",39,"city-fishing",nil,true)
    end
end
