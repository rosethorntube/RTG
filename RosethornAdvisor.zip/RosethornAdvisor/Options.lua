local _, ns = ...
local frame, pages, tabs, controls, mutedRows = nil, {}, {}, {}, {}
local current = "General"
local function label(parent,text,font)
    local l=parent:CreateFontString(nil,"OVERLAY",font or "GameFontHighlightSmall")
    l:SetText(text); l:SetJustifyH("LEFT"); return l
end
local function refresh()
    for _,f in ipairs(controls) do f() end
    ns.ApplyTipAppearance()
    if ns.RequestRefresh then ns.RequestRefresh() end
end
local function row(page,text)
    local r=CreateFrame("Frame",nil,page);r:SetHeight(30)
    r:SetPoint("TOPLEFT",4,-page.offset);r:SetPoint("TOPRIGHT",-4,-page.offset)
    local l=label(r,text); l:SetPoint("LEFT",2,0)
    page.offset=page.offset+32;page:SetHeight(page.offset+6)
    return r
end
local function toggle(p,text,read,write)
    local r=row(p,text);local b=CreateFrame("CheckButton",nil,r,"UICheckButtonTemplate")
    b:SetSize(25,25);b:SetPoint("RIGHT"); b:SetScript("OnClick",function(self)write(self:GetChecked() and true or false);refresh() end)
    controls[#controls+1]=function()b:SetChecked(read()) end
end
local function cycle(p,text,choices,read,write)
    local r=row(p,text)
    local b=ns.AdvisorButton(r,"",130,22,function()
        local picked=read()
        for i,v in ipairs(choices) do if picked==v then write(choices[i%#choices+1]);break end end
        refresh()
    end)
    b:SetPoint("RIGHT");controls[#controls+1]=function()b:SetText(read()) end
end
local function step(p,text,key,min,max,delta,suffix)
    local cfg=ns.TipSettings();local r=row(p,text)
    local function change(d) cfg[key]=math.min(max,math.max(min,cfg[key]+d*delta));refresh() end
    local more=ns.AdvisorButton(r,"+",24,22,function()change(1)end);more:SetPoint("RIGHT")
    local val=label(r,"");val:SetWidth(52);val:SetJustifyH("CENTER");val:SetPoint("RIGHT",more,"LEFT",-1,0)
    local less=ns.AdvisorButton(r,"-",24,22,function()change(-1)end);less:SetPoint("RIGHT",val,"LEFT",-1,0)
    controls[#controls+1]=function()val:SetText(cfg[key]..(suffix or ""));less:SetEnabled(cfg[key]>min);more:SetEnabled(cfg[key]<max)end
end
local function input(r,width)
    local e=CreateFrame("EditBox",nil,r,"InputBoxTemplate");e:SetSize(width,22);e:SetAutoFocus(false)
    e:SetScript("OnEscapePressed",function(self)self:ClearFocus();refresh()end)
    return e
end
local function colour(p,title,key)
    local cfg=ns.TipSettings();local r=row(p,title.."  #RRGGBB");local e=input(r,78);e:SetMaxLetters(7);e:SetPoint("RIGHT",-5,0)
    local sw=r:CreateTexture(nil,"ARTWORK");sw:SetSize(18,18);sw:SetPoint("RIGHT",e,"LEFT",-12,0)
    local function apply()
        local v=e:GetText():match("^#?(%x%x%x%x%x%x)$");if v then cfg[key]=v:upper() end
        e:SetText(cfg[key]);refresh()
    end
    e:SetScript("OnEditFocusLost",apply);e:SetScript("OnEnterPressed",function(self)self:ClearFocus()end)
    controls[#controls+1]=function()
        local v=cfg[key];if not e:HasFocus()then e:SetText(v)end
        sw:SetColorTexture(tonumber(v:sub(1,2),16)/255,tonumber(v:sub(3,4),16)/255,tonumber(v:sub(5,6),16)/255,1)
    end
end
local function buildGeneral(p,cfg)
    cycle(p,"New tip notification",{"Glow","Window","Both"},function()return cfg.mode end,function(v)cfg.mode=v end)
    toggle(p,"Pause notifications in combat",function()return cfg.quiet end,function(v)cfg.quiet=v end)
    toggle(p,"Lock icon and tip window",function()return cfg.locked end,function(v)cfg.locked=v end)
    local r=row(p,"Profession, alt and fishing reference")
    ns.AdvisorButton(r,"Full advisor",110,23,function()frame:Hide();ns.OpenFullAdvisor("now")end):SetPoint("RIGHT")
    local market=row(p,"Manual quote: item ID and unit price")
    local edit=input(market,100);edit:SetPoint("RIGHT",-58,0)
    local function quote() if edit:GetText()~="" then ns.MarketCommand(edit:GetText());edit:ClearFocus() end end
    ns.AdvisorButton(market,"Save",49,22,quote):SetPoint("RIGHT");edit:SetScript("OnEnterPressed",quote)
    row(p,"Example: 6362 40s")
    cycle(p,"Auction sale market",{"auto","faction","neutral"},function()local r=ns.CurrentRecord();return r and r.saleMarket or "auto"end,function(v)ns.MarketCommand("market "..v)end)
    local fish=row(p,"Fishing session")
    ns.AdvisorButton(fish,"Start fresh",110,22,function()ns.ResetFishingSession() end):SetPoint("RIGHT")
end
local function listMutes()
    local page=pages.Tips;if not page then return end
    local cfg=ns.TipSettings();local keys={}
    for k in pairs(cfg.muted) do keys[#keys+1]=k end
    table.sort(keys,function(a,b)return cfg.muted[a]<cfg.muted[b]end)
    for i,k in ipairs(keys)do
        local r=mutedRows[i]
        if not r then
            r=CreateFrame("Frame",nil,page);r:SetSize(345,30)
            r.caption=label(r,"");r.caption:SetPoint("LEFT",2,0);r.caption:SetWidth(252)
            ns.AdvisorButton(r,"Restore",67,22,function()ns.RestoreTip(r.key);listMutes()end):SetPoint("RIGHT")
            mutedRows[i]=r
        end
        r.key=k;r.caption:SetText(cfg.muted[k]);r:SetPoint("TOPLEFT",4,-page.offset-(i-1)*31);r:Show()
    end
    for i=#keys+1,#mutedRows do mutedRows[i]:Hide() end
    page.empty:SetShown(#keys==0);page:SetHeight(page.offset+math.max(30,#keys*31)+8)
end
local function buildTips(p,cfg)
    row(p,"Enable categories and choose which may open the window.")
    for _,name in ipairs(ns.TipCategories) do
        local cat=name
        toggle(p,cat,function()return cfg.enabled[cat]~=false end,function(v)cfg.enabled[cat]=v end)
        toggle(p,"     Allow "..cat:lower().." to open the window",function()return cfg.interrupt[cat]end,function(v)cfg.interrupt[cat]=v end)
    end
    row(p,"Muted tips · all characters")
    p.empty=label(p,"No muted tips.");p.empty:SetPoint("TOPLEFT",7,-p.offset)
end
local function buildAppearance(p,cfg)
    step(p,"Icon size","size",18,72,2," px");step(p,"Tip window width","width",300,700,8," px")
    step(p,"Tip window height","height",164,540,8," px");step(p,"Tip text size","font",10,24,1," px")
    cycle(p,"Background",{"Solid","Parchment","Clear"},function()return cfg.background end,function(v)cfg.background=v end)
    colour(p,"Background colour","bg");step(p,"Background opacity","bgAlpha",0,100,5,"%")
    colour(p,"Text colour","fg");step(p,"Text opacity","fgAlpha",5,100,5,"%")
    colour(p,"Border colour","border");step(p,"Border opacity","borderAlpha",0,100,5,"%")
    step(p,"Border thickness","edge",1,6,1," px")
end
local function selectTab(name)
    current=name
    for k,p in pairs(pages)do p.scroll:SetShown(k==name);tabs[k]:SetEnabled(k~=name)end
    ns.PreviewTip(name=="Appearance")
    if name=="Tips" then listMutes() end
    refresh()
end
function ns.OpenTipOptions()
    if not frame then
        frame=CreateFrame("Frame","RosethornAdvisorOptions",UIParent,BackdropTemplateMixin and "BackdropTemplate" or nil)
        frame:SetSize(414,445);frame:SetPoint("CENTER",UIParent,"CENTER",-145,40);frame:SetFrameStrata("DIALOG")
        frame:SetClampedToScreen(true);frame:EnableMouse(true);frame:SetMovable(true);frame:RegisterForDrag("LeftButton")
        frame:SetScript("OnDragStart",frame.StartMoving);frame:SetScript("OnDragStop",frame.StopMovingOrSizing)
        if frame.SetBackdrop then frame:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1});frame:SetBackdropColor(.06,.08,.07,.98);frame:SetBackdropBorderColor(.64,.52,.33)end
        label(frame,"Rosethorn Advisor · Options","GameFontNormalLarge"):SetPoint("TOPLEFT",13,-13)
        ns.AdvisorButton(frame,"×",23,22,function()frame:Hide()end):SetPoint("TOPRIGHT",-8,-7)
        local cfg=ns.TipSettings()
        for i,name in ipairs({"General","Tips","Appearance"}) do
            local key=name;local tab=ns.AdvisorButton(frame,name,99,24,function()selectTab(key)end)
            tab:SetPoint("TOPLEFT",12+(i-1)*104,-40);tabs[name]=tab
            local scroll=CreateFrame("ScrollFrame",nil,frame,"UIPanelScrollFrameTemplate")
            scroll:SetPoint("TOPLEFT",12,-73);scroll:SetPoint("BOTTOMRIGHT",-33,12)
            local p=CreateFrame("Frame",nil,scroll);p:SetSize(359,1);p.offset=0;p.scroll=scroll;scroll:SetScrollChild(p);pages[name]=p
        end
        buildGeneral(pages.General,cfg);buildTips(pages.Tips,cfg);buildAppearance(pages.Appearance,cfg)
        frame:SetScript("OnHide",function()ns.PreviewTip(false)end)
        if UISpecialFrames then table.insert(UISpecialFrames,"RosethornAdvisorOptions") end
    end
    frame:Show();selectTab(current)
end
