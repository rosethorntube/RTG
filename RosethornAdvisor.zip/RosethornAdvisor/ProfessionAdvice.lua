local _, ns = ...

-- The standard-mode crafting challenges award one account point per trade/tier.
-- worldofwarcraft.blizzard.com/en-us/news/24307383 and questing.wiki/wow-forever/legacy/
-- Leatherworking has a dedicated account tracker in Core.lua.
local crafts = {
    {name="Alchemy", first=62012, alternate=63996}, {name="Blacksmithing", first=62015, alternate=63999},
    {name="Enchanting", first=62018, alternate=64002}, {name="Engineering", first=62021, alternate=64005},
    {name="Tailoring", first=62028, alternate=64011},
}
local gates = {{rank=150,level=10},{rank=225,level=20},{rank=300,level=35}}
local cities = {[1454]=true, [1456]=true, [1458]=true, [1453]=true, [1455]=true, [1457]=true}
local mailStops = {["Booty Bay"]=true,["Ratchet"]=true,["The Crossroads"]=true,["Camp Mojache"]=true,["Gadgetzan"]=true}
local function hasCredit(id)
    if type(GetAchievementInfo) ~= "function" then return false end
    local ok, _, _, _, complete = pcall(GetAchievementInfo,id)
    return ok and complete == true
end

local function age(row, name, state)
    if row.key == state.key and state.skills[name] then return "Current skill." end
    local stamp = (row.skillSeen and row.skillSeen[name]) or row.skillsSeen or row.seen
    if type(stamp) == "number" and stamp > 0 and date then
        return "Last recorded "..date("%d %b %Y %H:%M",stamp).."."
    end
    return "The saved character record has no observation date."
end

local function skillFor(row,name,state)
    if row.key == state.key then return state.skills[name] end
    return row.skills and row.skills[name]
end
local function craftOpportunities(s,add,tab,rows)
    if s.mode ~= "normal" then return end
    local history=ns.DB().history.normal or {}
    for _,craft in ipairs(crafts) do
        local name = craft.name
        local high = history[name] or 0
        for _,r in ipairs(rows) do
            local observed=skillFor(r,name,s)
            if observed and r.mode==s.mode then high=math.max(high,observed.rank) end
        end
        local goal
        for i,g in ipairs(gates) do
            if g.rank>high and not hasCredit(craft.first+i-1) and not hasCredit(craft.alternate+i-1) then goal=g; break end
        end
        if goal then
            local best, skill, eligible
            for _,r in ipairs(rows) do
                local current=skillFor(r,name,s)
                if current and r.mode==s.mode and current.rank<goal.rank then
                    local permitted=(r.level or 0)>=goal.level
                    if not best or (permitted and not eligible)
                        or (permitted==eligible and (current.rank>skill.rank
                            or (current.rank==skill.rank and r.key==s.key))) then
                        best,skill,eligible=r,current,permitted
                    end
                end
            end
            if best then
                local left=goal.rank-skill.rank
                if tab=="alts" or (left<=10 and eligible) then
                    local who=best.name..(best.realm~=s.realm and (" ("..best.realm..")") or "")
                    local title=who.." - "..name.." "..goal.rank
                    local body=who.." was recorded at "..skill.rank.."/"..skill.cap..". "..left..
                        (left==1 and " skill-up" or " skill-ups").." to this account's next unobserved "..name.." milestone. "..age(best,name,s)
                    if not eligible then body=body.." Reach character level "..goal.level.." for this profession rank."
                    elseif skill.cap<goal.rank then body=body.." Train the next rank before pursuing this threshold."
                    elseif ns.ProfessionRouteStep then body=body.." "..ns.ProfessionRouteStep(name,skill)
                    else body=body.." Open Professions for the next recipe and shopping list." end
                    body=body.." Check Legacy (Y) before spending on materials."
                    local key="craft-goal:"..name..":"..goal.rank
                    add(title,body,(tab=="now" and 24 or 32)+math.min(left,200)/100,key,nil,left<=10 and eligible)
                end
            end
        end
    end
end

local function rankAdvice(s,add)
    -- Fishing and Cooking have dedicated, location-aware rank cards.
    for name,skill in pairs(s.skills) do
        local def=ns.ProfessionDefinitions[name]
        if def and name~="Fishing" and name~="Cooking" and skill.cap<300 and skill.rank>=skill.cap-5 then
            local levelNeeded = def.kind=="Crafting" and ({[75]=10,[150]=20,[225]=35})[skill.cap]
            local eligible = not levelNeeded or s.level>=levelNeeded
            if name=="First Aid" and skill.cap==225 then eligible=s.level>=35 and skill.rank>=225 end
            local body=ns.nextProfessionRank(name,skill.rank,skill.cap,s.level).."."
            if name=="First Aid" and skill.cap==150 and not ns.FeatureEnabled("vendors") then
                body="Unlock Expert First Aid to advance beyond 150."
            end
            if not eligible and levelNeeded then body=body.." Reach level "..levelNeeded.." before training."
            elseif def.kind~="Secondary" and cities[s.mapID] then
                body=body.." Ask a city guard for the "..name.." trainer. The highest rank may need a specialist."
            end
            add(name.." "..skill.rank.."/"..skill.cap,body,37+(skill.cap-skill.rank)/100,
                "train-near:"..name..":"..skill.cap,nil,eligible and (cities[s.mapID] or skill.rank==skill.cap))
        end
    end
end

local uses={
    {"Ore",{"Blacksmithing","Engineering"}}, {"Leather",{"Leatherworking"}},
    {"Cloth",{"Tailoring","First Aid"}}, {"Herbs",{"Alchemy"}},
    {"Enchanting materials",{"Enchanting"}}, {"BoE greens",{"Enchanting"}},
}
local oreIDs={[2770]=true,[2771]=true,[2772]=true,[2775]=true,[2776]=true,[3858]=true,
    [7911]=true,[10620]=true}
local itemNames={[2770]="Copper Ore",[2771]="Tin Ore",[2772]="Iron Ore",[2840]="Copper Bar",
    [2318]="Light Leather",[2319]="Medium Leather",[4234]="Heavy Leather",[4304]="Thick Leather",
    [8170]="Rugged Leather",[2589]="Linen Cloth",[2592]="Wool Cloth",[4306]="Silk Cloth",
    [4338]="Mageweave Cloth",[14047]="Runecloth",[2447]="Peacebloom",[765]="Silverleaf",[10940]="Strange Dust"}
local function itemLabel(id)
    local lookup=(C_Item and C_Item.GetItemNameByID) or GetItemInfo
    local name=lookup and lookup(id)
    return type(name)=="string" and name or itemNames[id] or ("item "..id)
end

local function handoffs(s,add,rows)
    if not s.realm or not s.faction or not (cities[s.mapID] or mailStops[s.subzone]) then return end
    local me=ns.CurrentRecord()
    if not me or me.bagMaterials~=s.bags then return end
    for _,group in ipairs(uses) do
        local kind,profs=group[1],group[2]
        local tally=s.bags
        if kind=="BoE greens" then tally=me.bagGreens end
        local count,id=0,nil
        for material,n in pairs(tally or {}) do
            if n>0 and (kind=="BoE greens" or ns.materialKind[material]==kind)
                and (n>count or (n==count and material<id)) then id,count=material,n end
        end
        if id then
            local options,own={},false
            for _,prof in ipairs(profs) do
                if kind=="Cloth" and prof=="First Aid" and #options>0 then break end
                if s.skills[prof] and s.skills[prof].rank<300 then own=true end
                for _,r in ipairs(rows) do
                    local skill=r.skills and r.skills[prof]
                    if r.key~=s.key and r.mode==s.mode and r.realm==s.realm and r.faction==s.faction
                        and skill and skill.rank<300 then
                        options[#options+1]=r.name.." ("..prof.." "..skill.rank.."). "..age(r,prof,s)
                    end
                end
            end
            if #options>0 and not own then
                local item=itemLabel(id)
                local body="You have "..count.." x "..item.." in your bags. "..table.concat(options," ")..
                    " Check the recipient's next recipe before sending."
                if oreIDs[id] then body=body.." Smelt ore into bars if the recipe calls for bars." end
                if kind=="BoE greens" then body=body.." Compare the gear's value with disenchanting it." end
                add("Mail option - "..item,body,47,"profession-mail:"..kind..":"..id,nil,false)
            end
        end
    end
end

function ns.AddProfessionAdvice(s,add,tab,materialAdd)
    if not s or not s.skills or (tab~="now" and tab~="alts") then return end
    local rows=ns.GetRosterRows()
    if ns.FeatureEnabled("professions") then
        craftOpportunities(s,add,tab,rows)
        if tab=="now" then rankAdvice(s,add) end
    end
    if tab=="now" and ns.FeatureEnabled("materials") then
        handoffs(s,materialAdd or add,rows)
    end
end
