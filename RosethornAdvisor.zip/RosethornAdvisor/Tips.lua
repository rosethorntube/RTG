local _, ns = ...
local template = BackdropTemplateMixin and "BackdropTemplate" or nil
local icon, glow, tip, title, body, counter, dismiss, mute, undo, previous, following, reader
local visible, selected, lastMute, preview = {}, nil, nil, false
local dismissed, lastVisit = {}, nil
local defaults = { width=364, height=212, font=14, size=32, edge=1, background="Solid", mode="Glow",
    bg="111811", fg="F1E8D4", border="BB965E", bgAlpha=93, fgAlpha=100, borderAlpha=95, quiet=true, locked=false }
ns.TipCategories = {"Vendors","Fishing","Professions","Dungeons"}
function ns.TipSettings()
    local db=ns.DB()
    if not db.settings.tips then
        db.settings.tips={enabled={}, interrupt={}, muted={}}
        if db.fishingPopup==false then db.settings.tips.enabled.Fishing=false end
    end
    local t=db.settings.tips
    for k,v in pairs(defaults) do if t[k]==nil then t[k]=v end end
    return t
end
local function colour(hex,alpha)
    return tonumber(hex:sub(1,2),16)/255,tonumber(hex:sub(3,4),16)/255,tonumber(hex:sub(5,6),16)/255,alpha/100
end
local function backdrop(f,cfg)
    if not f.SetBackdrop then return end
    local bg=cfg.background=="Parchment" and "Interface\\DialogFrame\\UI-DialogBox-Background" or "Interface\\Buttons\\WHITE8X8"
    f:SetBackdrop({bgFile=bg,edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=cfg.edge})
    f:SetBackdropColor(colour(cfg.bg,cfg.background=="Clear" and 0 or cfg.bgAlpha))
    f:SetBackdropBorderColor(colour(cfg.border,cfg.borderAlpha))
end
function ns.AdvisorButton(parent,text,w,h,action)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetSize(w,h); b:SetText(text); b:SetScript("OnClick",action); return b
end
local function position(f,handle,key,point,x,y)
    local cfg=ns.TipSettings()
    local p=cfg[key] or ns.DB().settings[key]
    if p and p.point then f:SetPoint(p.point,UIParent,p.relativePoint or p.point,p.x or 0,p.y or 0)
    else f:SetPoint(point,UIParent,point,x,y) end
    f:SetMovable(true); f:SetClampedToScreen(true)
    handle:EnableMouse(true); handle:RegisterForDrag("LeftButton")
    handle:SetScript("OnDragStart",function() if not cfg.locked then f:StartMoving() end end)
    handle:SetScript("OnDragStop",function()
        f:StopMovingOrSizing()
        local a,_,b,dx,dy=f:GetPoint()
        cfg[key]={point=a,relativePoint=b,x=dx,y=dy}
    end)
end
local function category(key)
    if key:match("^dungeon:") then return "Dungeons" end
    if key:match("^vendor:") or key:match("^fish:") or key=="fishing-book" then return "Vendors" end
    if key:find("fishing",1,true) or key:match("^camp%-") or key:match("^water%-target") then return "Fishing" end
    return "Professions"
end
local function indexOf(key)
    for i,item in ipairs(visible) do if item.key==key then return i end end
end
local function showText()
    if not tip then return end
    local cfg=ns.TipSettings()
    local i=indexOf(selected)
    local item=i and visible[i]
    title:SetText(preview and "Fish while waiting in Ratchet" or item and item.title or "All caught up")
    body:SetText(preview and "Cast from the pier. Kilxx sells the Rainbow Fin Albacore recipe beside the waterfront." or item and item.body or "The icon will light up when there is a new tip for you.")
    counter:SetText(preview and "Preview" or item and (i.." / "..#visible) or "")
    previous:SetEnabled(not preview and #visible>1); following:SetEnabled(not preview and #visible>1)
    dismiss:SetEnabled(not preview and item~=nil); mute:SetEnabled(not preview and item~=nil)
    undo:SetShown(lastMute~=nil and not preview)
    if tip:IsShown() and not preview and item then
        local r=ns.CurrentRecord(); if r then r.seenAlerts[item.key]=true end
    end
    if reader then
        local w=math.max(100,reader:GetWidth()-4)
        body:SetWidth(w); body:GetParent():SetSize(w,math.max(1,body:GetStringHeight()+4))
        reader:UpdateScrollChildRect()
    end
end
function ns.ApplyTipAppearance()
    if not tip then return end
    local cfg=ns.TipSettings()
    icon:SetSize(cfg.size,cfg.size); tip:SetSize(cfg.width,cfg.height); backdrop(tip,cfg)
    title:SetFont(STANDARD_TEXT_FONT,cfg.font+2,"");body:SetFont(STANDARD_TEXT_FONT,cfg.font,"")
    title:SetTextColor(colour(cfg.fg,cfg.fgAlpha));body:SetTextColor(colour(cfg.fg,cfg.fgAlpha))
    showText()
end
local function update()
    if ns.RefreshTips then ns.RefreshTips(ns.GetAdvice("now")) end
end
function ns.RestoreTip(key)
    ns.TipSettings().muted[key]=nil; dismissed[key]=nil
    local r=ns.CurrentRecord(); if r then r.seenAlerts[key]=nil end
    if lastMute==key then lastMute=nil end
    update()
end
local function navigate(delta)
    if #visible==0 then return end
    selected=visible[((indexOf(selected) or 1)-1+delta)%#visible+1].key
    reader:SetVerticalScroll(0);update()
end
local function discard(permanent)
    local i=indexOf(selected)
    if not i then return end
    local item=visible[i]
    if permanent then ns.TipSettings().muted[item.key]=item.title; lastMute=item.key
    else
        dismissed[item.key]=true
        local r=ns.CurrentRecord()
        if r then r.seenAlerts[item.key]=nil end
    end
    selected=visible[i+1] and visible[i+1].key or nil
    update()
end
function ns.RefreshTips(items)
    if not icon then return end
    local cfg,r=ns.TipSettings(),ns.CurrentRecord()
    if not r then return end
    local s=ns.state
    local visit=s.key.."/"..tostring(s.mapID).."/"..(s.subzone or "")
    if lastVisit~=visit then dismissed={};lastVisit=visit end
    visible={}
    local present,firstUnread,interrupt={},nil,nil
    for _,item in ipairs(items or {}) do
        local k=item.key
        if item.alert and k then
            present[k]=true
            local cat=category(k)
            if cfg.enabled[cat]~=false and not cfg.muted[k] and not dismissed[k] then
                visible[#visible+1]=item
                if not r.seenAlerts[k] then
                    firstUnread=firstUnread or item
                    if cfg.interrupt[cat] then interrupt=interrupt or item end
                end
            end
        end
    end
    for k in pairs(dismissed) do if not present[k] then dismissed[k]=nil end end
    local quiet=(cfg.quiet and InCombatLockdown and InCombatLockdown()) or (r.snoozeUntil or 0)>time()
    if not preview and not quiet and (cfg.mode=="Window" or cfg.mode=="Both") and interrupt and not tip:IsShown() then
        selected=interrupt.key;reader:SetVerticalScroll(0);tip:Show()
    end
    if not indexOf(selected) or not tip:IsShown() then
        local best=firstUnread or visible[1];selected=best and best.key;reader:SetVerticalScroll(0)
    end
    showText()
    local unread=false
    for _,v in ipairs(visible) do if not r.seenAlerts[v.key] then unread=true;break end end
    local light=not quiet and unread and cfg.mode~="Window"
    glow:SetShown(light);icon.image:SetDesaturated(not light);icon.image:SetAlpha(light and 1 or 0.72)
end
function ns.PreviewTip(on)
    if not tip then return end
    if on and not preview then tip.wasOpen=tip:IsShown() end
    if not on and not preview then return end
    preview=on
    if on then tip:Show() elseif not tip.wasOpen then tip:Hide() end
    ns.ApplyTipAppearance();update()
end
function ns.CreateTipUI()
    icon=CreateFrame("Button",nil,UIParent,template)
    icon:SetFrameStrata("MEDIUM");icon:RegisterForClicks("LeftButtonUp","RightButtonUp")
    position(icon,icon,"launcher","TOPRIGHT",-215,-96)
    icon.image=icon:CreateTexture(nil,"ARTWORK");icon.image:SetAllPoints();icon.image:SetTexture("Interface\\Icons\\INV_Misc_Book_09")
    glow=icon:CreateTexture(nil,"OVERLAY");glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border");glow:SetBlendMode("ADD")
    glow:SetPoint("TOPLEFT",-9,9);glow:SetPoint("BOTTOMRIGHT",9,-9);glow:SetVertexColor(1,.78,.25);glow:Hide()
    icon:SetScript("OnEnter",function(self) GameTooltip:SetOwner(self,"ANCHOR_LEFT");GameTooltip:AddLine("Rosethorn Advisor");GameTooltip:AddLine("Left-click: tips   Right-click: options");GameTooltip:Show() end)
    icon:SetScript("OnLeave",function() GameTooltip:Hide() end)
    icon:SetScript("OnClick",function(_,mouse)
        if mouse=="RightButton" then ns.OpenTipOptions();return end
        preview=false;tip:SetShown(not tip:IsShown());update()
    end)
    tip=CreateFrame("Frame",nil,UIParent,template);tip:SetFrameStrata("DIALOG");tip:EnableMouse(true);tip:Hide()
    tip:SetSize(ns.TipSettings().width,ns.TipSettings().height)
    local bar=CreateFrame("Frame",nil,tip);bar:SetPoint("TOPLEFT",4,-2);bar:SetPoint("TOPRIGHT",-30,-2);bar:SetHeight(27)
    position(tip,bar,"tipPosition","CENTER",180,70)
    counter=bar:CreateFontString(nil,"OVERLAY","GameFontNormalSmall");counter:SetPoint("LEFT",8,0)
    local close=ns.AdvisorButton(tip,"×",22,21,function() preview=false;tip:Hide();update() end)
    close:SetPoint("TOPRIGHT",-5,-4)
    title=tip:CreateFontString(nil,"OVERLAY","GameFontNormal");title:SetPoint("TOPLEFT",12,-30);title:SetPoint("TOPRIGHT",-12,-30);title:SetJustifyH("LEFT")
    reader=CreateFrame("ScrollFrame",nil,tip,"UIPanelScrollFrameTemplate")
    reader:SetPoint("TOPLEFT",title,"BOTTOMLEFT",0,-6);reader:SetPoint("BOTTOMRIGHT",-31,41)
    local child=CreateFrame("Frame",nil,reader);child:SetSize(230,40);reader:SetScrollChild(child)
    body=child:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");body:SetPoint("TOPLEFT");body:SetJustifyH("LEFT");body:SetJustifyV("TOP")
    dismiss=ns.AdvisorButton(tip,"Dismiss",59,22,function() discard(false) end);dismiss:SetPoint("BOTTOMLEFT",7,8)
    mute=ns.AdvisorButton(tip,"Don't show again",113,22,function() discard(true) end);mute:SetPoint("LEFT",dismiss,"RIGHT",3,0)
    undo=ns.AdvisorButton(tip,"Undo",45,22,function() if lastMute then ns.RestoreTip(lastMute) end end);undo:SetPoint("LEFT",mute,"RIGHT",2,0)
    following=ns.AdvisorButton(tip,">",23,22,function() navigate(1) end);following:SetPoint("BOTTOMRIGHT",-7,8)
    previous=ns.AdvisorButton(tip,"<",23,22,function() navigate(-1) end);previous:SetPoint("RIGHT",following,"LEFT",-2,0)
    ns.ApplyTipAppearance()
end
