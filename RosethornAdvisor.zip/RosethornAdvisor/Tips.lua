local _, ns = ...
local template = BackdropTemplateMixin and "BackdropTemplate" or nil
local icon, glow, tip, counter, undo, list
local visible, lastMute, preview = {}, nil, false
local dismissed, lastVisit = {}, nil
local lastPickupVisit, lastPickups=nil,{}
local function isPickup(key) return key:match("^dungeon:pickup:")~=nil end
local lastVendorCharacter, lastVendors=nil,{}
local function isVendor(key) return key:match("^vendor:")~=nil end
local defaults = { width=364, height=212, font=14, size=32, edge=1, background="Solid", mode="Glow",
    bg="111811", fg="F1E8D4", border="BB965E", glow="FFD957", bgAlpha=93, fgAlpha=100, borderAlpha=95, glowAlpha=100,
    quiet=true, locked=false }
ns.TipCategories = {"Vendors","Fishing","Professions","Dungeons"}
function ns.DefaultTipColour(key)
    return defaults[key]
end
function ns.TipSettings()
    local db=ns.DB()
    if not db.settings.tips then
        db.settings.tips={enabled={}, interrupt={}, muted={}}
        if db.fishingPopup==false then db.settings.tips.enabled.Fishing=false end
    end
    local t=db.settings.tips
    for k,v in pairs(defaults) do if t[k]==nil then t[k]=v end end
    return t
end
local function colour(hex,alpha)
    return tonumber(hex:sub(1,2),16)/255,tonumber(hex:sub(3,4),16)/255,tonumber(hex:sub(5,6),16)/255,alpha/100
end
local function backdrop(f,cfg)
    if not f.SetBackdrop then return end
    local bg=cfg.background=="Parchment" and "Interface\\DialogFrame\\UI-DialogBox-Background" or "Interface\\Buttons\\WHITE8X8"
    f:SetBackdrop({bgFile=bg,edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=cfg.edge})
    f:SetBackdropColor(colour(cfg.bg,cfg.background=="Clear" and 0 or cfg.bgAlpha))
    f:SetBackdropBorderColor(colour(cfg.border,cfg.borderAlpha))
end
function ns.AdvisorButton(parent,text,w,h,action)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetSize(w,h); b:SetText(text); b:SetScript("OnClick",action); return b
end
local function position(f,handle,key,point,x,y)
    local cfg=ns.TipSettings()
    local p=cfg[key] or ns.DB().settings[key]
    if p and p.point then f:SetPoint(p.point,UIParent,p.relativePoint or p.point,p.x or 0,p.y or 0)
    else f:SetPoint(point,UIParent,point,x,y) end
    f:SetMovable(true); f:SetClampedToScreen(true)
    handle:EnableMouse(true); handle:RegisterForDrag("LeftButton")
    handle:SetScript("OnDragStart",function() if not cfg.locked then f:StartMoving() end end)
    handle:SetScript("OnDragStop",function()
        f:StopMovingOrSizing()
        local a,_,b,dx,dy=f:GetPoint()
        cfg[key]={point=a,relativePoint=b,x=dx,y=dy}
    end)
end
local function category(key)
    if key:match("^dungeon:") then return "Dungeons" end
    if key:match("^vendor:") or key:match("^fish:") or key=="fishing-book" then return "Vendors" end
    if key:find("fishing",1,true) or key:match("^camp%-") or key:match("^water%-target") then return "Fishing" end
    return "Professions"
end
local function setTint(t,r,g,b,a)
    if t.SetColorTexture then t:SetColorTexture(r,g,b,a)
    else t:SetTexture("Interface\\Buttons\\WHITE8X8");t:SetVertexColor(r,g,b,a) end
end
local function fill(parent,layer,r,g,b,a)
    local t=parent:CreateTexture(nil,layer)
    setTint(t,r,g,b,a)
    return t
end
local function outline(parent,pad,width,r,g,b,a,tints)
    local edges={{"TOPLEFT","TOPRIGHT",-pad,pad,pad,pad},
                 {"BOTTOMLEFT","BOTTOMRIGHT",-pad,-pad,pad,-pad},
                 {"TOPLEFT","BOTTOMLEFT",-pad,pad,-pad,-pad},
                 {"TOPRIGHT","BOTTOMRIGHT",pad,pad,pad,-pad}}
    for i,p in ipairs(edges) do
        local t=fill(parent,"OVERLAY",r,g,b,a)
        t:SetPoint(p[1],parent,p[1],p[3],p[4]);t:SetPoint(p[2],parent,p[2],p[5],p[6])
        if i<=2 then t:SetHeight(width) else t:SetWidth(width) end
        if tints then tints[#tints+1]={texture=t,alpha=a} end
    end
end
local function createLauncherArt()
    fill(icon,"BACKGROUND",.07,.045,.025,1):SetAllPoints()
    icon.image=icon:CreateTexture(nil,"ARTWORK")
    icon.image:SetPoint("TOPLEFT",3,-3);icon.image:SetPoint("BOTTOMRIGHT",-3,3)
    icon.image:SetTexture("Interface\\AddOns\\RosethornAdvisor\\Icon")
    outline(icon,0,2,.63,.45,.23,1)
    glow=CreateFrame("Frame",nil,icon);glow:SetAllPoints(icon);glow:EnableMouse(false)
    glow.tints={}
    -- Keep a bright unbroken edge at the dimmest point of the animation.
    outline(glow,1,3,1,1,1,1,glow.tints)
    local halo=CreateFrame("Frame",nil,glow);halo:SetAllPoints(glow);halo:EnableMouse(false)
    outline(halo,4,3,1,1,1,.8,glow.tints)
    outline(halo,6,2,1,1,1,.32,glow.tints)
    if halo.CreateAnimationGroup then
        local pulse=halo:CreateAnimationGroup()
        for i=1,2 do
            local a=pulse:CreateAnimation("Alpha")
            a:SetOrder(i);a:SetDuration(1.1);a:SetSmoothing("IN_OUT")
            a:SetFromAlpha(i==1 and 1 or .45);a:SetToAlpha(i==1 and .45 or 1)
        end
        pulse:SetLooping("REPEAT");glow.pulse=pulse
    end
    local badge=CreateFrame("Frame",nil,glow);badge:SetSize(13,15);badge:EnableMouse(false)
    badge:SetPoint("TOPRIGHT",3,3)
    fill(badge,"BACKGROUND",.12,.075,.025,1):SetAllPoints()
    outline(badge,0,1,1,1,1,1,glow.tints)
    local mark=badge:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    mark:SetPoint("CENTER",0,0);mark:SetFont(STANDARD_TEXT_FONT,12,"OUTLINE")
    mark:SetText("!");glow.mark=mark
    glow:Hide();icon.image:SetVertexColor(.86,.81,.7)
end
local function applyGlow(cfg)
    if glow.colour~=cfg.glow then
        local r,g,b=colour(cfg.glow,100)
        for _,edge in ipairs(glow.tints) do setTint(edge.texture,r,g,b,edge.alpha) end
        glow.mark:SetTextColor(.35+.65*r,.35+.65*g,.35+.65*b,1)
        glow.colour=cfg.glow
    end
    -- Set the parent's opacity so the pulse modulates the halo inside that limit.
    glow:SetAlpha(cfg.glowAlpha/100)
end
local function updateLauncher(record,quiet,mode,snoozed)
    local count,first=0,nil
    for _,item in ipairs(visible) do
        if item.alert and not record.seenAlerts[item.key] then count=count+1;first=first or item.title end
    end
    icon.unreadCount=count;icon.firstUnreadTitle=first
    icon.quietReason=snoozed and "Snoozed" or quiet and "Quiet in combat" or nil
    local lit=preview or (count>0 and not quiet and mode~="Window")
    if glow:IsShown()==lit then return end
    glow:SetShown(lit)
    if lit then
        icon.image:SetVertexColor(1,1,1)
        if glow.pulse then glow.pulse:Play() end
    else
        if glow.pulse then glow.pulse:Stop() end
        icon.image:SetVertexColor(.86,.81,.7)
    end
end
local function launcherTooltip(self)
    GameTooltip:SetOwner(self,"ANCHOR_LEFT");GameTooltip:AddLine(ns.title)
    if self.quietReason then GameTooltip:AddLine(self.quietReason,.8,.8,.8) end
    local n=self.unreadCount or 0
    GameTooltip:AddLine(n==0 and "No unread suggestions" or (n.." unread suggestion"..(n==1 and "" or "s")),1,.84,.44)
    if self.firstUnreadTitle then GameTooltip:AddLine(self.firstUnreadTitle,1,1,1,true) end
    GameTooltip:AddLine("Left-click for suggestions. Right-click for options.",.78,.78,.78,true)
    GameTooltip:Show()
end
local function showText()
    if not tip or not list then return end
    counter:SetText(preview and "Preview" or (#visible==1 and "1 suggestion" or #visible.." suggestions"))
    undo:SetShown(lastMute~=nil and not preview)
    list:Render(visible,ns.ColourPreview or ns.TipSettings(),preview)
end
function ns.ApplyTipAppearance()
    if not tip then return end
    local cfg=ns.ColourPreview or ns.TipSettings()
    icon:SetSize(cfg.size,cfg.size); tip:SetSize(cfg.width,cfg.height); backdrop(tip,cfg); applyGlow(cfg)
    showText()
end
local function update()
    if ns.RefreshTips then ns.RefreshTips(ns.GetAdvice("now")) end
end
function ns.RestoreTip(key)
    ns.TipSettings().muted[key]=nil; dismissed[key]=nil
    local r=ns.CurrentRecord(); if r then r.seenAlerts[key]=nil end
    if lastMute==key then lastMute=nil end
    update()
end
local function discard(item,permanent)
    if preview or not item or not item.key then return end
    if permanent then
        ns.TipSettings().muted[item.key]=item.title
        lastMute=item.key
    else
        dismissed[item.key]=true
        local r=ns.CurrentRecord()
        if r then r.seenAlerts[item.key]=nil end
    end
    update()
end
function ns.RefreshTips(items)
    if not icon then return end
    local cfg,r=ns.TipSettings(),ns.CurrentRecord()
    if not r then return end
    local s=ns.state
    local visit=s.key.."/"..tostring(s.mapID).."/"..(s.subzone or "")
    local pickupVisit=s.key.."/"..tostring(s.dungeonPickupHub)
    if lastVisit~=visit then
        for k in pairs(dismissed) do if not isPickup(k) and not isVendor(k) then dismissed[k]=nil end end
        lastVisit=visit
    end
    if lastPickupVisit~=pickupVisit then
        for k in pairs(dismissed) do if isPickup(k) then dismissed[k]=nil end end
        for k in pairs(r.seenAlerts) do if isPickup(k) then r.seenAlerts[k]=nil end end
        lastPickupVisit=pickupVisit
        lastPickups={}
    end
    visible={}
    if lastVendorCharacter~=s.key then lastVendorCharacter,lastVendors=s.key,{} end
    local present,newPickups,newVendors,interrupt={},{},{},nil
    for _,item in ipairs(items or {}) do
        local k=item.key
        if k and k~="fish:empty" and k~="roster:welcome" then
            present[k]=true
            if isPickup(k) then newPickups[k]=true end
            if isVendor(k) then
                newVendors[k]=true
                if not lastVendors[k] then r.seenAlerts[k]=nil; dismissed[k]=nil end
            end
            local cat=category(k)
            if not cfg.muted[k] and not dismissed[k] then
                visible[#visible+1]=item
                if item.alert and not r.seenAlerts[k] and cfg.interrupt[cat] then interrupt=interrupt or item end
            end
        end
    end
    for k in pairs(lastPickups) do if not newPickups[k] then r.seenAlerts[k]=nil end end
    lastPickups=newPickups
    lastVendors=newVendors
    for k in pairs(dismissed) do if not present[k] then dismissed[k]=nil end end
    local snoozed=(ns.DB().settings.snoozeUntil or 0)>time()
    local quiet=(cfg.quiet and InCombatLockdown and InCombatLockdown()) or snoozed
    if not preview and not quiet and (cfg.mode=="Window" or cfg.mode=="Both") and interrupt and not tip:IsShown() then
        list:FocusOn(interrupt.key);tip:Show()
    end
    showText()
    updateLauncher(r,quiet,cfg.mode,snoozed)
end
function ns.PreviewTip(on)
    if not tip then return end
    if on and not preview then tip.wasOpen=tip:IsShown() end
    if not on and not preview then return end
    preview=on
    if on then tip:Show() elseif not tip.wasOpen then tip:Hide() end
    ns.ApplyTipAppearance();update()
end
function ns.CreateTipUI()
    icon=CreateFrame("Button",nil,UIParent,template)
    icon:SetFrameStrata("MEDIUM");icon:RegisterForClicks("LeftButtonUp","RightButtonUp")
    position(icon,icon,"launcher","TOPRIGHT",-215,-96)
    createLauncherArt()
    icon:SetScript("OnEnter",launcherTooltip)
    icon:SetScript("OnLeave",function() GameTooltip:Hide() end)
    icon:SetScript("OnClick",function(_,mouse)
        if mouse=="RightButton" then ns.OpenTipOptions();return end
        preview=false
        if not tip:IsShown() then list:FocusOn(nil) end
        tip:SetShown(not tip:IsShown());update()
    end)
    tip=CreateFrame("Frame",nil,UIParent,template);tip:SetFrameStrata("DIALOG");tip:EnableMouse(true);tip:Hide()
    tip:SetSize(ns.TipSettings().width,ns.TipSettings().height)
    local bar=CreateFrame("Frame",nil,tip);bar:SetPoint("TOPLEFT",4,-2);bar:SetPoint("TOPRIGHT",-30,-2);bar:SetHeight(27)
    position(tip,bar,"tipPosition","CENTER",180,70)
    counter=bar:CreateFontString(nil,"OVERLAY","GameFontNormalSmall");counter:SetPoint("LEFT",8,0)
    local close=ns.AdvisorButton(tip,"×",22,21,function() preview=false;tip:Hide();update() end)
    close:SetPoint("TOPRIGHT",-5,-4)
    undo=ns.AdvisorButton(tip,"Undo mute",85,21,function() if lastMute then ns.RestoreTip(lastMute) end end)
    undo:SetPoint("RIGHT",close,"LEFT",-4,0)
    list=ns.CreateSuggestionsList(tip,discard,function(item)
        if preview or not item.alert then return end
        local r=ns.CurrentRecord()
        if r and not r.seenAlerts[item.key] then r.seenAlerts[item.key]=true; return true end
    end,update)
    ns.ApplyTipAppearance()
end
