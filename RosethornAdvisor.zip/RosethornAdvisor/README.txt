While You're Here
By Rosethorn · Horde · WoW Forever 1.60.1

Passing through Undercity at level 30? The rose compass lights up for Going, Going, Guano! and can point you to Faranell. Catch a Raw Rockscale Cod while waiting for the boat? Find its recipe and directions to Kelsey Yance without leaving the game. At the mailbox, see which of your alts could use the materials in your bags.

To install or upgrade, copy the enclosed RosethornAdvisor folder into your WoW Forever Interface/AddOns folder. For upgrades, replace the existing addon files in that folder. The game loads your existing settings and character records. Enable While You're Here at character selection and log in.

Left-click the rose compass to see all current suggestions. Right-click it or type /wyh to open General, Tips and Appearance. Drag the unlocked compass or tip window to move it. Type /wyh now, /wyh professions, /wyh alts or /wyh fishing to open a specific advisor tab. Type /wyh help for the command list.

Appearance, saved window positions, notification preferences, snooze, sale market, selected tabs and profession filter are shared across characters on this WoW account and installation. Each character keeps its own quest progress, pins, destination and profession plan. On upgrading, the addon carries over the most recently seen character's explicit market preference and the longest remaining snooze.

In Appearance, select Alert glow, Background, Text or Window border. Choose a colour on the wheel, adjust brightness on the strip beside it, then drag the checkerboard strip to set transparency. The top is solid and the bottom is fully transparent. Okay saves your changes across all four settings. Cancel discards them. Reset restores the selected colour and transparency to their defaults.

Open /wyh → Tips and tick the advice you want on this account:

  Find dungeon prequests and quest givers
  Spot nearby recipes and training books
  Plan professions and earn Legacy Points
  Send spare materials to the right alt
  Find fishing stops and recipes for your catch
  Compare fishing spots and auction prices

Auction comparisons also require fishing advice. The addon remembers your price preference while fishing advice is off. Under General, choose Glow, Window or Both. Tips also lets you choose which alerts may open the window. Dismiss for this visit, or use Don't show again to mute that tip across characters. Use Undo or restore it from Tips. Scroll the list to read each suggestion. General opens the full advisor, configures auction quotes and starts a fresh fishing session.

Dungeon pickups appear on entering a covered zone, including any quarter of a capital, or when a quest becomes available during a visit. Each card gives the required level, quest level, giver and dungeon. Accepted and completed quests disappear. The advisor checks character, item and chain requirements. Quest level uses the client difficulty colour. A live offer from the current giver takes precedence over older database requirements. Conditional starts are labelled Check availability until the quest giver confirms them. Dismiss hides a pickup until your next visit to the zone.

Mark on map adds a giver to the world map. Right-click a marker to remove it, or untick it in either suggestion list. Navigate targets one giver and shows a direct heading and distance when the client can locate both points. In other zones or when positioning is unavailable it shows the target map and coordinates. Accepting the last relevant pickup clears its marker. Map controls appear only for recorded coordinates.

Now checks the whole roster for profession milestones, training and useful materials. Open General → Full advisor → Professions to select any of the twelve professions. The six primary crafts have skill-specific recipe routes and full-band shopping estimates from Rosethorn's published guide. Select Plan on this character to remember a profession you intend to learn. Each character manages its own plan.

Check the compass when you enter a zone with a useful recipe vendor. At Tailoring 140 in Arathi Highlands, for example, it can point you to Jun'ha in Hammerfall (72.8, 36.6) for the limited-stock Pattern: Azure Silk Cloak. Open your own profession book so the addon can check what you know. Reminders take account of your rank, learned recipes and recipe items already seen in your bags or bank.

With a compatible RestedXP guide, the advisor can read the current arrow. You can also choose a destination using Route. The addon leaves guide progression to you.

The fishing view looks up catches in your bags. All fish lists the supported cooking recipes and where to buy them. Open your own Cooking profession window to record learned recipes. If the client cannot confirm a recipe, the advice says “if you need the recipe”. Directions and map coordinates work without a map addon.

Alts records your characters as you log into them. It shows which character holds each profession, the last recorded skill, materials in bags, and the personal bank tabs you have opened. The snapshot dates tell you when offline characters were last checked. Check Legacy (Y) for credit earned outside this installation. WoW saves data on logout or a UI reload.

The addon works on its own. To record AH prices, open the game's auction house, search for the item and open its offers. The advisor records the cheapest unit buyout in the visible results it can read. You can also enter a known unit price, for example /wyh price 6362 40s or /wyh price followed by a Shift-clicked item link and 1g 5s. Quotes are private to this installation and keyed by realm and auction market. Automatic uses the open AH's venue, or your faction market while travelling. Use /wyh price market neutral, faction or auto to choose where you intend to sell.

Fishing shows gross AH value per hour after five minutes. Unpriced catches are counted separately. It compares your own waters after at least fifteen minutes and ten caught items per spot, using complete recent prices. Cooking comparisons value the fish you could sell raw and the extra ingredients needed to cook it. Listed prices are asking prices; sales take time and auction fees apply. Auctionator is optional. Its cached prices can be shown as indicative estimates because its public API does not identify the auction venue. Fresh quotes observed at your selected AH or entered for that market take priority. See the Fishing tab for quote coverage and comparisons. /wyh fish off silences fishing hints; /wyh fish on restores them.

The Fishing tab compares catching ingredients for your current Cooking skill with fishing for gold and buying ingredients. It can recommend keeping a cheap fish, selling other catches and putting the after-fee proceeds towards more crafts. It compares your own observed waters and the cheapest quoted orange recipe you know in the included fish, meat and clam catalogue. It prices all ingredients, including seasoning, and counts each fish once. Missing prices leave the winner undecided. Oven recipes require the game to report an accessible Iron Oven. Recheck when a recipe changes colour or your skill caps.

Data notes
Per-cast comparisons include empty casts. A spot needs 20 observed casts in fully tracked visits, 15 minutes, 10 landed items and complete recent local prices for the per-cast ranking. For dedicated farming, use value per hour. For a short boat wait, per-cast value can be more informative.
Official profession list: https://worldofwarcraft.blizzard.com/en-us/news/24301516
WoW Forever Legacy system: https://worldofwarcraft.blizzard.com/en-us/news/24307383/get-to-know-the-world-of-warcraft-forever-legacy-system
Rockscale Cod recipe: https://wowforever.ninja/professions/cooking/7828-rockscale-cod/
Kelsey Yance directions: https://www.wow-professions.com/forever/npc/kelsey-yance
Expert Cookbook: https://bindonforever.com/item/16072
Vendor and spell sources for the individual entries are in Data.lua.
