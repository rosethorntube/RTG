Rosethorn Advisor · WoW Forever 1.60.1

Extract the RosethornAdvisor folder into the Interface/AddOns folder of your WoW Forever installation. The path must end in Interface/AddOns/RosethornAdvisor/RosethornAdvisor.toc. Enable it at character selection and log in.

Click Guide or type /rta (also /rosethornadvisor). Drag Guide or the window title to move either. Resize from the bottom-right corner. A fresh, relevant suggestion lights the small tab. Click to read it, or snooze the indicator for ten minutes.

Now checks the whole roster for profession milestones, training and useful materials. Open /rta professions to select any of the twelve professions. The six primary crafts have skill-specific recipe routes and full-band shopping estimates from Rosethorn's published guide. Select Plan on this character to remember a profession you intend to learn. Each character manages its own plan.

With a compatible RestedXP guide, the advisor can read the current arrow. You can also choose a destination using Route. The addon leaves guide progression to you.

The fishing view looks up catches in your bags. All fish lists the supported cooking recipes and where to buy them. Open your own Cooking profession window to record learned recipes. If the client cannot confirm a recipe, the advice says “if you need the recipe”. Directions and map coordinates work without a map addon.

Alts records your characters as you log into them. It shows which character holds each profession, the last recorded skill, materials in bags, and the personal bank tabs you have opened. The snapshot dates tell you when offline characters were last checked. Check Legacy (Y) for credit earned outside this installation. WoW saves data on logout or a UI reload.

The addon works on its own. To record AH prices, open the game's auction house, search for the item and open its offers. The advisor records the cheapest unit buyout in the visible results it can read. You can also enter a known unit price, for example /rtaprice 6362 40s or /rtaprice followed by a Shift-clicked item link and 1g 5s. Quotes are private to this installation and keyed by realm and auction market. Automatic uses the open AH's venue, or your faction market while travelling. Use /rtaprice market neutral, faction or auto to choose where you intend to sell.

Fishing shows gross AH value per hour after five minutes. Unpriced catches are counted separately. It compares your own waters after at least fifteen minutes and ten caught items per spot, using complete recent prices. Cooking comparisons value the fish you could sell raw and the extra ingredients needed to cook it. Listed prices are asking prices; sales take time and auction fees apply. Auctionator is optional. Its cached prices can be shown as indicative estimates because its public API does not identify the auction venue. Fresh quotes observed at your selected AH or entered for that market take priority. See the Fishing tab for quote coverage and comparisons. /rtafish off silences fishing hints; /rtafish on restores them.

The Fishing tab compares catching ingredients for your current Cooking skill with fishing for gold and buying ingredients. It can recommend keeping a cheap fish, selling other catches and putting the after-fee proceeds towards more crafts. It compares your own observed waters and the cheapest quoted orange recipe you know in the included fish, meat and clam catalogue. It prices all ingredients, including seasoning, and counts each fish once. Missing prices leave the winner undecided. Oven recipes require the game to report an accessible Iron Oven. Recheck when a recipe changes colour or your skill caps.

Data notes
Per-cast comparisons include empty casts. A spot needs 20 observed casts in fully tracked visits, 15 minutes, 10 landed items and complete recent local prices for the per-cast ranking. For dedicated farming, use value per hour. For a short boat wait, per-cast value can be more informative.
Official profession list: https://worldofwarcraft.blizzard.com/en-us/news/24301516
WoW Forever Legacy system: https://worldofwarcraft.blizzard.com/en-us/news/24307383/get-to-know-the-world-of-warcraft-forever-legacy-system
Rockscale Cod recipe: https://wowforever.ninja/professions/cooking/7828-rockscale-cod/
Kelsey Yance directions: https://www.wow-professions.com/forever/npc/kelsey-yance
Expert Cookbook: https://bindonforever.com/item/16072
Vendor and spell sources for the individual entries are in Data.lua.
