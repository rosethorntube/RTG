local _, ns = ...

-- Skill targets and shopping estimates from the published Rosethorn guide.
local routes = {
    Alchemy = {
        bands = {
            {limit=150, mats="60 Silverleaf, 90 Peacebloom, 85 Mageroyal, 60 Earthroot, 70 Briarthorn, 40 Stranglekelp.",
             steps={{12, "Minor Force"}, {55, "Minor Defense"}, {65, "Minor Mana"}, {90, "Minor Fortitude"}, {120, "Wisdom"}, {150, "Lesser Mana"}}},
            {limit=225, mats="15 Mageroyal, 70 Stranglekelp, 50 Kingsblood, 40 Goldthorn, 30 Khadgar’s Whisker.",
             steps={{160, "Lesser Mana"}, {195, "Mana"}, {205, "Agility"}, {225, "Greater Mana"}}},
            {limit=300, mats="20 Goldthorn, 20 Khadgar’s Whisker, 30 Arthas’ Tears, 25 Sungrass, 25 Blindweed, 40 Plaguebloom; 40 Murloc Eyes + 3 Discolored Worg Hearts.",
             steps={{240, "Greater Mana"}, {260, "Draught of Detect Undead"}, {270, "Superior Mana"}, {300, "Major Discolored Healing Potion"}}},
        },
        note="Buy about 200 Empty, 110 Leaded and 80 Crystal Vials overall. Expert: Halsey, Undercity; Artisan: Rogvar, Stonard (level 35 / skill 200). Unlock the final potion via Rane Yorick’s Wild Hearts → Return to Quinn → Wild Eyes in Silverpine; 3 hearts + 3 of the eyes cover the quests.",
    },
    Blacksmithing = {
        bands = {
            {limit=150, mats="340 Copper, 380 Bronze, 5 Silver, 30 Iron; 140 Rough Stone, 80 Coarse Stone, 10 Heavy Stone; 15 Medium Leather.",
             steps={{30, "Rough Sharpening"}, {65, "Rough Grinding"}, {75, "Copper Chain Belt"}, {90, "Coarse Grinding"}, {100, "Runed Copper Belt"}, {105, "Heavy Sharpening"}, {110, "Runed Copper Belt"}, {125, "Rough Bronze Leggings"}, {129, "Iron Buckle"}, {140, "Bronze Warhammer"}, {147, "Patterned Bronze Bracers"}, {150, "Green Iron Bracers"}}},
            {limit=225, mats="360 Iron, 100 Steel, 420 Mithril; 160 Heavy Stone; 120 Mageweave.",
             steps={{155, "Green Iron Bracers"}, {165, "Green Iron Leggings"}, {183, "Green Iron Bracers"}, {190, "Heavy Mithril Gauntlet"}, {200, "Golden Scale Bracers"}, {205, "Heavy Mithril Gauntlet"}, {210, "Mithril Plate Pants"}, {215, "Heavy Mithril Gauntlet"}, {225, "Heavy Mithril Breastplate"}}},
            {limit=300, mats="910 Mithril, 1,100 Thorium, 140 Truesilver, 12 Arcanite, 340 Azerothium; 100 Dense Stone, 150 Solid Stone; 85 Mageweave; 155 Thick + 155 Rugged Leather; 15 Black Pearls, 60 Shadowgems, 50 Star Rubies, 10 Large Opals, 135 Essence of Air.",
             steps={{235, "Dense Weightstone"}, {240, "Mithril Coif"}, {246, "Heavy Mithril Boots"}, {250, "Big Black Mace"}, {257, "Arcanite Skeleton Key"}, {270, "Ebon Shiv"}, {275, "Bold Dirk"}, {279, "Ornate Thorium Handaxe"}, {300, "Bold Dirk"}}},
        },
        note="Keep grinding stones. *Make 34 Coarse Grinding Stones early; fill any gap with Silver Skeleton Keys to 80 / Rough Bronze Leggings to 90. Buy hammer, flux and dye. Ebon Shiv / Ornate Handaxe plans: Magnus Frostwake, Caer Darrow, normally after the level 55 Spectral Essence chain. Bold Dirk: BoP plan from Pexmit, Mount Hyjal.",
    },
    Enchanting = {
        bands = {
            {limit=150, mats="30 Strange Dust; 100 Lesser Magic Essence; 30 Lesser Astral Essence; 20 Soul Dust; 1 Shadowgem. Buy 75 Simple Wood, 1 Mote of Magic, Copper + Silver Rods.",
             steps={{2, "Runed Copper Rod"}, {20, "disenchant greens"}, {79, "Lesser Magic Wand"}, {90, "Chest–Minor Absorption"}, {100, "Bracer–Minor Stamina"}, {101, "Runed Silver Rod"}, {110, "Greater Magic Wand"}, {135, "Cloak–Minor Agility"}, {150, "Bracer–Lesser Stamina"}}},
            {limit=225, mats="45 Soul Dust; 55 Vision Dust; 1 Greater Astral + 1 Greater Mystic Essence; 1 Iridescent + 1 Black Pearl. Buy Golden + Truesilver Rods.",
             steps={{155, "Bracer–Lesser Stamina"}, {156, "Runed Golden Rod"}, {185, "Bracer–Lesser Strength"}, {200, "Bracer–Strength"}, {201, "Runed Truesilver Rod"}, {220, "Bracer–Strength"}, {225, "Cloak–Greater Defense"}}},
            {limit=300, mats="70 Vision, 220 Dream, 60 Illusion Dust; 20 Purple Lotus; 4 Greater Eternal Essence; 4 Small + 2 Large Brilliant Shards; 1 Golden Pearl. Buy 20 Crystal Vials + Arcanite Rod.",
             steps={{230, "Gloves–Agility"}, {235, "Boots–Stamina"}, {250, "Chest–Superior Stamina"}, {265, "Lesser Mana Oil"}, {294, "Shield–Greater Stamina"}, {295, "Runed Arcanite Rod"}, {300, "Cloak–Superior Defense"}}},
        },
        note="Reuse the same suitable gear, including a shield; keep all rods. Expert: Hgarth, Sun Rock Retreat. Artisan: Annora inside Uldaman (level 35 / skill 200); bring materials to 250. Formulas: Kulwia, Sun Rock—Minor Agility and Lesser Strength (Lesser Strength also on the AH); Lesser Mana Oil—BRD/Silithus vendors or AH; Daniel Bartlett, Undercity—Shield Greater Stamina, BoP; Lorelae Wintersong, Moonglade—Arcanite Rod and Superior Defense (Superior Defense also on the AH). Buy the first Mote; dust conversion needs the rod already.",
    },
    Engineering = {
        bands = {
            {limit=150, mats="75 Copper, 110 Bronze, 5 Silver; 70 Rough Stone, 55 Coarse Stone; 50 Linen, 30 Wool; 10 Moss Agates.",
             steps={{30, "Rough Blasting Powder"}, {50, "Copper Bolts"}, {51, "Arclight Spanner"}, {75, "Rough Copper Bomb"}, {90, "Coarse Blasting Powder"}, {100, "Coarse Dynamite"}, {105, "Silver Contact"}, {125, "Bronze Tube"}, {135, "Standard Scope"}, {150, "Whirring Bronze Gizmo"}}},
            {limit=225, mats="35 Bronze, 90 Mithril, 5 Steel; 35 Heavy Stone, 120 Solid Stone; 20 Medium Leather; 50 Wool, 25 Mageweave.",
             steps={{160, "Bronze Framework"}, {175, "Explosive Sheep"}, {194, "Solid Blasting Powder"}, {195, "Gyromatic Micro-Adjustor"}, {200, "Mithril Tube"}, {215, "Unstable Trigger"}, {225, "Mithril Casing"}}},
            {limit=300, mats="65 Mithril, 190 Thorium; 65 Dense Stone; 30 Runecloth.",
             steps={{238, "Mithril Casing"}, {250, "Hi-Explosive Bomb"}, {260, "Dense Blasting Powder"}, {285, "Thorium Widget"}, {300, "Thorium Tube"}}},
        },
        note="Keep components: about 60 Rough Powder, 30 Copper Bolts, 45 Coarse Powder, 15 Frameworks and 30 Heavy Powder; retain gizmos, solid powder, triggers and casings. Buy 30 Weak Flux. Artisan: Buzzek, Gadgetzan (level 35 / skill 200). Widget schematic: AH or Sovik, Orgrimmar; Tube plan: Xizzer, Everlook, bought personally.",
    },
    Leatherworking = {
        bands = {
            {limit=150, mats="120 Ruined Leather Scraps; 450 Light + 150 Medium Leather; 30 Light, 12 Medium and 35 Heavy Hides.",
             steps={{30, "Light Leather"}, {55, "Cured Light Hide"}, {75, "Embossed Leather Gloves"}, {80, "Medium Leather"}, {90, "Cured Medium Hide"}, {100, "Fine Leather Belt"}, {115, "Light Leather Pants"}, {125, "Dark Leather Belt"}, {130, "Heavy Leather"}, {143, "Cured Heavy Hide"}, {150, "Hillman’s Leather Gloves"}}},
            {limit=225, mats="150 Medium, 450 Heavy, 400 Thick Leather; 20 Iron Buckles.",
             steps={{155, "Hillman’s Leather Gloves"}, {170, "Barbaric Shoulders"}, {185, "Guardian Gloves"}, {195, "Barbaric Harness"}, {205, "Nightscape Headband"}, {225, "Nightscape Pants"}}},
            {limit=300, mats="250 Thick + 1,200 Rugged Leather; 600 Runecloth.",
             steps={{235, "Nightscape Pants"}, {265, "Wicked Leather Gauntlets"}, {300, "Runic Leather Headband"}}},
        },
        note="Keep 24 Cured Light Hides, 10 Cured Medium Hides, 10 Fine Leather Belts and 30 Cured Heavy Hides. Buy salt, thread and dyes. Expert: Una, Thunder Bluff; Artisan: Hahrana Ironhide, Camp Mojache. Gauntlets pattern: Werg Thickblade, Tirisfal; Headband: Jase Farlane, Light’s Hope. Obtain both before buying late materials.",
    },
    Tailoring = {
        bands = {
            {limit=150, mats="80 Linen, 520 Wool, 240 Silk, 140 Mageweave; 35 Elixirs of Wisdom.",
             steps={{30, "Linen Bolts"}, {55, "Linen Belt"}, {80, "Wool Bolts"}, {95, "Woolen Cape"}, {100, "Double-stitched Woolen Shoulders"}, {120, "Silk Bolts"}, {140, "Gloves of Meditation"}, {150, "Mageweave Bolts"}}},
            {limit=225, mats="580 Silk, 180 Mageweave, 180 Runecloth.",
             steps={{170, "Crimson Silk Vest"}, {190, "Crimson Silk Pantaloons"}, {200, "Black Mageweave Leggings"}, {205, "Black Mageweave Shoulders"}, {215, "Runecloth Bolts"}, {225, "Runecloth Belt"}}},
            {limit=300, mats="4,000 Runecloth; 320 Rugged Leather; 180 Ironweb Spider Silk.",
             steps={{240, "Runecloth Belt"}, {250, "Runecloth Gloves"}, {280, "Runecloth Cuffs"}, {300, "Runecloth Shoulders"}}},
        },
        note="Buy thread and Red Dye. Buy the elixirs. Expert: Josef Gregorian, Undercity; Artisan: Daryl Stack, Tarren Mill. Patterns: Gloves—Qia, Everlook; Cuffs—Pexmit, Mount Hyjal, BoP; Shoulders—world drop/AH. Secure patterns before stockpiling. Late skill-ups are variable; these are working estimates, not a cheapest-route guarantee.",
    },
}

-- End of published crafting routes.

ns.PanelProfessions = {"Alchemy","Blacksmithing","Enchanting","Engineering","Leatherworking","Tailoring",
    "Herbalism","Mining","Skinning","Cooking","First Aid","Fishing"}
local overview = {
    Alchemy="Turn herbs into potions. Keep ingredients for the recipe your Alchemist is working on.",
    Blacksmithing="Make early Warrior gear where it replaces a weak slot. In Rosethorn's route the Paladin finishes the later Blacksmithing milestones.",
    Enchanting="Send disenchantable spare greens to the enchanter. Save rods and compare the value of a useful BoE before disenchanting it.",
    Engineering="Bank ore, stone and cloth for the Warrior and Hunter. Keep intermediate components for later crafts.",
    Leatherworking="Pool skins for the leatherworker closest to the next unclaimed crafting milestone.",
    Tailoring="Pool cloth on the tailor for bags and skill-ups. Check the First Aid needs of the character holding it.",
    Herbalism="Gather Peacebloom and Silverleaf early. In the Barrens add Mageroyal at 50, Briarthorn at 70 and Bruiseweed at 100. Hillsbrad and Stonetalon offer Kingsblood from 125.",
    Mining="Mine Copper on the starting route. In the Barrens, Tin opens at 65 and Silver at 75. Aim for Iron at 125 as you leave, and keep stone for Engineering.",
    Skinning="Skin beasts you kill while questing. A Skinning Knife in your bags lets the Priest supply the Druid on the early Barrens route.",
    Cooking="Open your Cooking window to record your recipes. The Fishing tab compares catch locations and ingredient costs for your current Cooking skill.",
    ["First Aid"]="Craft bandages as cloth arrives. Get the Expert book and the Heavy Silk and Mageweave manuals from the AH or Balai Lok'Wein in Brackenwall Village. At level 35 and skill 225, visit Doctor Gregory Victor in Hammerfall for Triage.",
    Fishing="Cast while you wait for transport. The Fishing tab shows local skill targets, observed catches and comparisons with your other spots.",
}
local bandages={{40,"Linen Bandage"},{80,"Heavy Linen Bandage"},{115,"Wool Bandage"},{150,"Heavy Wool Bandage"},
    {180,"Silk Bandage"},{210,"Heavy Silk Bandage"},{240,"Mageweave Bandage"},{260,"Heavy Mageweave Bandage"},
    {290,"Runecloth Bandage"},{300,"Heavy Runecloth Bandage"}}
local function nextStep(steps,rank)
    for _,step in ipairs(steps) do if rank<step[1] then return step end end
end
local function bandAt(prof,rank)
    for _,band in ipairs(routes[prof] and routes[prof].bands or {}) do
        if rank<band.limit then return band end
    end
end

local function routeStep(prof,rank,owner)
    local band=bandAt(prof,rank)
    local step=band and nextStep(band.steps,rank)
    -- The Silverpine quest unlocks Major Discolored Healing Potion for Horde.
    -- Recipe 13477 is sold to both factions. It stays non-grey through 300.
    if step and prof=="Alchemy" and step[2]=="Major Discolored Healing Potion" and owner
        and owner.faction~="Horde" and not (owner.known and owner.known[1231583]) then
        return {300,"Superior Mana"}
    end
    return step
end
function ns.CraftRouteRecipe(prof,rank,owner)
    local step=routeStep(prof,rank,owner)
    local recipes=ns.CraftNextData and ns.CraftNextData[prof]
    local recipe=step and recipes and recipes[step[2]]
    if not recipe then return end
    local target=math.min(step[1],recipe.grey)
    if prof=="Leatherworking" and step[2]=="Nightscape Pants" and rank<recipe.availableAt then
        target,recipe=math.min(target,recipe.availableAt),recipes["Nightscape Headband"]
    end
    if recipe and rank>=recipe.availableAt and target>rank then return recipe,target end
end
local function caption(rec,state,profession)
    local same=rec.key==state.key
    if same then return rec.name.." (playing now)" end
    local seen=(rec.skillSeen and rec.skillSeen[profession]) or rec.skillsSeen or rec.seen or rec.seenAt
    return (rec.name or "?")..(seen and date and (" (last seen "..date("%d %b",seen)..")") or " (last observed)")
end
local function overviewFor(label,faction)
    if faction=="Horde" then return overview[label] end
    if label=="First Aid" then
        if faction=="Alliance" then return "Deneb Walker in Stromgarde Keep sells the Expert book and manuals. At level 35 and First Aid 225, take Triage from Doctor Gustaf VanHowzen in Theramore." end
        return "Keep cloth for bandages and obtain the manuals for your next rank."
    end
    if label=="Herbalism" then return "Gather Peacebloom and Silverleaf early. Use the Gathering advice for your current skill." end
    if label=="Mining" then return "Gather Copper first. Tin opens at 65 and Iron at 125." end
    if label=="Skinning" then return "Carry a Skinning Knife and skin beasts as you quest." end
    if label=="Blacksmithing" then return "Save bars and grinding stones for your next Blacksmithing recipe." end
    return overview[label]
end
local function recipeStep(label,skill,owner)
    if skill.rank>=skill.cap and skill.cap<300 then return "Train or unlock the next rank before spending materials." end
    local step=routeStep(label,skill.rank,owner) or (label=="First Aid" and nextStep(bandages,skill.rank))
    if step then return "Guide route: "..step[2].." towards "..step[1]..". Check that the recipe is learned." end
    return skill.rank>=300 and "Skill 300 reached." or overviewFor(label,owner and owner.faction)
end

-- The profession selector filters both the live character and observed alts.
ns.ProfessionRouteStep=recipeStep

function ns.AddPlannedProfessionAdvice(state,add,tab)
    if tab~="now" and tab~="alts" then return end
    for key,rec in pairs(ns.DB().characters) do
        if rec.mode==state.mode and rec.plannedProfessions and rec.skills then
            for name in pairs(rec.plannedProfessions) do
                if not rec.skills[name] and ns.ProfessionDefinitions[name] and (name~="Fishing" or ns.FeatureEnabled("fishing")) then
                    local inUse=0
                    for learned in pairs(rec.skills) do
                        local def=ns.ProfessionDefinitions[learned]
                        if def and def.kind~="Secondary" then inUse=inUse+1 end
                    end
                    local slotFree=ns.ProfessionDefinitions[name].kind=="Secondary" or inUse<2
                    local note=slotFree and "A profession slot is available. Visit a trainer when convenient."
                        or "Both primary slots were occupied at the last check. Review the plan before changing either."
                    local seen=rec.seenAt and date and (" Last checked "..date("%d %b",rec.seenAt)..".") or ""
                    add(rec.name.." has "..name.." planned","Level "..(rec.level or "?")..". "..name.." has yet to appear among their observed skills. "..note..seen,
                        slotFree and 18 or 45,"planned:"..key..":"..name,nil,slotFree)
                end
            end
        end
    end
end

local function currentStep(state, prof, skill, fishingLocation)
    if prof == "First Aid" then return ns.FirstAidNext(state, skill) end
    if skill.rank >= skill.cap then return ns.ProfessionTrainingNext(state, prof, skill) end
    if prof == "Fishing" or prof == "Cooking" then
        return ns.FishCookingNext(state, prof, skill, fishingLocation)
    end
    if routes[prof] then
        local step = routeStep(prof,skill.rank,state)
        return ns.CraftNext(state, prof, skill, step)
    end
    return ns.GatheringNext(state, prof, skill)
end

function ns.ProfessionPanelAdvice(state, add)
    local filter = ns.DB().settings.professionFilter
    local roster = ns.GetRosterRows and ns.GetRosterRows() or {}
    local skills = state.skills or {}
    local shown, bestRank, shopOwner = 0
    local shopCharacter=state
    local fishingLocation
    if (not filter or filter == "Fishing" or filter == "Cooking") and skills.Fishing
        and ns.FeatureEnabled("fishing") and ns.FeatureEnabled("fishingLocation") then
        fishingLocation = ns.FishingLocationAdvice(state,"cooking")
    end

    for index, prof in ipairs(ns.PanelProfessions) do
        if not filter or filter == prof then
            local skill = skills[prof]
            if skill then
                local body, target = currentStep(state, prof, skill, fishingLocation)
                local title = ("%s · %d/%d"):format(prof, skill.rank, skill.cap)
                add(title, body or recipeStep(prof, skill, state), index, "current-prof:" .. prof, target)
                shown = shown + 1
                if filter then bestRank, shopOwner = skill.rank, state.name end
            end

            local lines = {}
            for _, rec in ipairs(roster) do
                local other = rec.key ~= state.key and rec.skills and rec.skills[prof]
                if other then
                    lines[#lines + 1] = ("%s · %d/%d"):format(caption(rec, state, prof), other.rank, other.cap)
                    if filter then
                        lines[#lines + 1] = ns.RosterBookAdvice(state, rec, prof, other) or recipeStep(prof, other, rec)
                        if not skill and (not bestRank or other.rank > bestRank) then
                            bestRank, shopOwner = other.rank, rec.name
                            shopCharacter=rec
                        end
                    end
                end
            end
            if #lines > 0 then
                add("Alts · " .. prof, table.concat(lines, "\n"), 20 + index, "roster-prof:" .. prof)
                shown = shown + 1
            elseif filter and not skill then
                add(prof, "No character has reported this profession. " .. overviewFor(prof,state.faction), 20, "roster-prof:" .. prof)
            end
        end
    end

    if not filter then
        if shown == 0 then
            add("Your professions", "Learn a profession or select one above to browse the guide.", 1, "roster-prof:empty")
        end
        return
    end
    local route = routes[filter]
    if route then
        local band = bandAt(filter, bestRank or 1)
        if band then
            local who = shopOwner and (shopOwner .. " · ") or ""
            local mats=band.mats.." Quantities cover the full skill band. Check your current stock before buying."
            if filter=="Alchemy" and band.limit==300 and shopCharacter.faction~="Horde" then
                mats="225–240: Goldthorn, Khadgar's Whisker and Leaded Vials. 240–260: Arthas' Tears and Crystal Vials. From 260: 2 Sungrass, 2 Blindweed and 1 Crystal Vial per Superior Mana Potion. Craft in small batches as it turns yellow at 275 and green at 295."
            end
            add(who .. "Materials for the route to " .. band.limit, mats,
                40, "roster-shop:" .. filter)
        end
        if shopCharacter.faction=="Horde" and state.faction=="Horde" then
            add("Trainers, patterns and supplies", route.note, 41, "roster-notes:" .. filter)
        elseif filter=="Alchemy" and shopCharacter.faction=="Alliance" and bestRank and bestRank>=225 and bestRank<300 then
            add("Recipe: Superior Mana Potion","Ulthir in Darnassus sells the recipe. It requires Alchemy 260 and turns grey at 315.",41,"roster-notes:Alchemy")
        end
    end
end
