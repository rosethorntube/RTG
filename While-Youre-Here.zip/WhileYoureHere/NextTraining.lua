local _, ns = ...

-- Level gates: wow-professions.com/forever/{profession}-trainers.
-- Gathering ranks have no character-level requirement. Cooking only has one at Artisan.
local tiers = {
    [75] = {name="Journeyman", cap=150, level=10},
    [150] = {name="Expert", cap=225, level=20},
    [225] = {name="Artisan", cap=300, level=35},
}
local books = {
    Cooking = {id=16072, name="Expert Cookbook", location="Shadowprey Village, Desolace", detail=", upstairs in the eastern building"},
    Fishing = {id=16083, name="Expert Fishing - The Bass and You", location="Booty Bay", detail=", by the fishing sign on the lower boardwalk"},
}
-- https://bindonforever.com/npc/3955
local allianceCookbook = {vendor="Shandrina", faction="Alliance", mapID=1440, x=.495, y=.671}

function ns.ExpertBookAdvice(state, profession, rank)
    local book = books[profession]
    local held = ns.RecipeItemHeld(state, book.id)
    local requirement = ""
    if profession=="Fishing" and ((rank or 0)<125 or (state.level or 0)<20) then
        requirement = " at level 20 and Fishing 125"
    end
    local unlock = requirement.." to unlock 225."
    if held == "bags" then return "Read "..book.name.." in your bags"..unlock end
    if held == "bank" then return "Withdraw "..book.name.." from your bank and read it"..unlock end
    local body = "Read "..book.name..unlock
    local hint = ns.RecipeShoppingHint(state,book.id)
    if not ns.FeatureEnabled("vendors") then return body..(hint and " "..hint or "") end
    local shop, location, detail = ns.ExpertBookShops[book.id], book.location, book.detail
    local faction = ns.AdvisorFaction and ns.AdvisorFaction(state) or state.faction
    if profession == "Cooking" and faction ~= "Horde" then
        if faction ~= "Alliance" then return body..(hint and " "..hint or "") end
        shop, location, detail = allianceCookbook, "Silverwind Refuge, Ashenvale", ""
    end
    local vendor = ("%s sells it in %s (%.1f, %.1f)%s."):format(shop.vendor,location,shop.x*100,shop.y*100,detail)
    if hint and state.mapID ~= shop.mapID then body = body.." "..hint.." "..vendor
    else body = body.." "..vendor..(hint and " "..hint or "") end
    return body, ns.RecipeVendorTarget(shop)
end

local function onQuest(id)
    local log = C_QuestLog or {}
    if log.IsOnQuest then return log.IsOnQuest(id) end
    local getIndex = log.GetLogIndexForQuestID or GetQuestLogIndexByID
    return getIndex and (getIndex(id) or 0) > 0
end

local function itemCount(state,id)
    local count = state.bags and state.bags[id]
    if count ~= nil then return count end
    if state.bagsScanned then return 0 end
    local getCount = C_Item and C_Item.GetItemCount or GetItemCount
    return getCount and getCount(id,false)
end

-- Quest 6610 allows collecting the ingredients before accepting.
local clamlette = {{12207,"Giant Eggs",12},{7974,"Zesty Clam Meat",10},{8932,"Alterac Swiss",20}}
local function artisanCooking(state)
    local dirge = "Dirge Quikcleave in the Gadgetzan inn (52.6, 28.0)"
    local active = onQuest(6610)
    local missing = {}
    for _,item in ipairs(clamlette) do
        local count = itemCount(state,item[1])
        if count == nil then
            return "Bring 12 Giant Eggs, 10 Zesty Clam Meat and 20 Alterac Swiss to "..dirge.." for Clamlette Surprise."
        end
        local need = item[3] - count
        if need > 0 then missing[#missing+1] = need.." "..(item[1]==12207 and need==1 and "Giant Egg" or item[2]) end
    end
    if #missing == 0 then
        return (active and "Turn in Clamlette Surprise to " or "Take your Clamlette Surprise ingredients to ")..dirge.." to unlock 300."
    end
    return "Collect "..table.concat(missing,", ").." for Clamlette Surprise, then visit "..dirge.."."
end

-- Quest 6607 requires acceptance before these fish can be caught.
local natFish = {
    {id=16967, map=1444, name="Feralas Ahi", water="the Verdantis River, Feralas"},
    {id=16968, map=1443, name="Sar'theris Striker", water="Sar'theris Strand, Desolace"},
    {id=16969, map=1434, name="Savage Coast Blue Sailfin", water="the Savage Coast, Stranglethorn Vale"},
    {id=16970, map=1435, name="Misty Reed Mahi Mahi", water="Misty Reed Strand, Swamp of Sorrows"},
}
local function artisanFishing(state)
    local nat = "Nat Pagle at Tidefury Cove, Dustwallow Marsh (58.6, 60.0)"
    if not onQuest(6607) then return "Accept Nat Pagle, Angler Extreme from "..nat.." before fishing for the four quest fish." end
    local nextFish
    for _,fish in ipairs(natFish) do
        local count = itemCount(state,fish.id)
        if count == nil then return "Catch the four fish in your quest log, then return to "..nat.." to unlock 300." end
        if count == 0 then
            nextFish = nextFish or fish
            if fish.map == state.mapID then nextFish = fish; break end
        end
    end
    if nextFish then return "Catch "..nextFish.name.." in "..nextFish.water.." for Nat Pagle, Angler Extreme." end
    return "Turn in Nat Pagle, Angler Extreme to "..nat.." to unlock 300."
end

function ns.ProfessionTrainingNext(state, profession, skill)
    local definition = ns.ProfessionDefinitions[profession]
    if not definition or profession == "First Aid" or not skill or not skill.rank or not skill.cap
        or skill.rank < skill.cap then return end
    if skill.cap == 300 then return "Maximum skill reached." end
    local tier = tiers[skill.cap]
    if not tier then return end
    local gated = definition.kind ~= "Gathering" and (profession ~= "Cooking" or skill.cap == 225)
    if gated and (state.level or 0) < tier.level then
        return ("Reach character level %d to unlock %s %s (cap %d)."):format(tier.level,tier.name,profession,tier.cap)
    end
    if books[profession] then
        if skill.cap == 150 then return ns.ExpertBookAdvice(state,profession,skill.rank) end
        if skill.cap == 225 then
            if profession == "Fishing" then return artisanFishing(state) end
            return artisanCooking(state)
        end
    end
    local trainer = ns.ProfessionRankTrainer(profession,skill.cap,ns.AdvisorFaction and ns.AdvisorFaction(state) or state.faction)
    return ("Train %s %s%s to unlock %d."):format(tier.name,profession,trainer and " with "..trainer or "",tier.cap)
end
