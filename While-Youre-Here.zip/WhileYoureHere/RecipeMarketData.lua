local _, ns = ...

-- Sources: https://www.wowhead.com/forever/item=<itemID> (Forever data environment 16).
-- Read the binding on the recipe/book itself; the crafted output below it can bind
-- differently. Vendor stock, the presence of a drop and Classic Era data do not
-- establish whether this exact item can be auctioned. Never infer an alternative
-- tradeable version by name or by the spell it teaches.
-- Prices are the undiscounted vendor buyprice in copper, only when a coin seller
-- is documented. Drops and currency-only offers intentionally have no cash price.
-- Item 6346 also has a 4s offer from Lilly: https://questing.wiki/wow-forever/npcs/5757/?inventory=6346
-- Vendor reputation discounts and live stock vary. Checked 24 November 2026.
ns.RecipeMarketFacts = {
    [3682] = {tradeable=true, price=1600}, -- Recipe: Curiously Tasty Omelet
    [3734] = {tradeable=false, price=1600}, -- Recipe: Big Bear Steak
    [3735] = {tradeable=false, price=1800}, -- Recipe: Hot Lion Chops
    [5484] = {tradeable=true, price=240}, -- Recipe: Roasted Kodo Meat
    [5486] = {tradeable=true, price=440}, -- Recipe: Strider Stew
    [5488] = {tradeable=true, price=400}, -- Recipe: Crispy Lizard Tail
    [5640] = {tradeable=true, price=100}, -- Recipe: Rage Potion
    [5642] = {tradeable=true, price=1800}, -- Recipe: Free Action Potion
    [5643] = {tradeable=true, price=2000}, -- Recipe: Great Rage Potion
    [5772] = {tradeable=true, price=500}, -- Pattern: Red Woolen Bag
    [5788] = {tradeable=false, price=650}, -- Pattern: Thick Murloc Armor
    [5789] = {tradeable=false, price=2800}, -- Pattern: Murloc Scale Bracers
    [5973] = {tradeable=false, price=650}, -- Pattern: Barbaric Leggings
    [6039] = {tradeable=true, price=5000}, -- Recipe: Giant Clam Scorcho
    [6047] = {tradeable=false, price=4400}, -- Plans: Golden Scale Coif
    [6053] = {tradeable=false, price=800}, -- Recipe: Holy Protection Potion
    [6056] = {tradeable=false, price=2000}, -- Recipe: Frost Protection Potion
    [6057] = {tradeable=false, price=2000}, -- Recipe: Nature Protection Potion
    [6068] = {tradeable=false, price=1500}, -- Recipe: Shadow Oil
    [6270] = {tradeable=true, price=200}, -- Pattern: Blue Linen Vest
    [6272] = {tradeable=true, price=300}, -- Pattern: Blue Linen Robe
    [6274] = {tradeable=true, price=400}, -- Pattern: Blue Overalls
    [6275] = {tradeable=true, price=800}, -- Pattern: Greater Adept's Robe
    [6325] = {tradeable=true, price=40}, -- Recipe: Brilliant Smallfish
    [6326] = {tradeable=true, price=40}, -- Recipe: Slitherskin Mackerel
    [6328] = {tradeable=true, price=400}, -- Recipe: Longjaw Mud Snapper
    [6330] = {tradeable=true, price=1200}, -- Recipe: Bristle Whisker Catfish
    [6342] = {tradeable=true, price=300}, -- Formula: Enchant Chest - Minor Intellect
    [6346] = {tradeable=true, price=400}, -- Formula: Enchant Chest - Lesser Intellect
    [6368] = {tradeable=true, price=400}, -- Recipe: Rainbow Fin Albacore
    [6369] = {tradeable=true, price=2200}, -- Recipe: Rockscale Cod
    [6661] = {tradeable=true}, -- Recipe: Savory Deviate Delight
    [7087] = {tradeable=false, price=1200}, -- Pattern: Crimson Silk Cloak
    [7088] = {tradeable=false, price=5000}, -- Pattern: Crimson Silk Robe
    [7089] = {tradeable=false, price=1500}, -- Pattern: Azure Silk Cloak
    [7114] = {tradeable=false, price=1000}, -- Pattern: Azure Silk Gloves
    [7451] = {tradeable=false, price=2800}, -- Pattern: Green Whelp Bracers
    [7561] = {tradeable=false, price=2000}, -- Schematic: Goblin Jumper Cables
    [8030] = {tradeable=false, price=10000}, -- Plans: Ebon Shiv
    [8385] = {tradeable=false, price=3500}, -- Pattern: Turtle Scale Gloves
    [8409] = {tradeable=false, price=4000}, -- Pattern: Nightscape Shoulders
    [9301] = {tradeable=true, price=10000}, -- Recipe: Elixir of Shadow Power
    [9302] = {tradeable=false, price=9000}, -- Recipe: Ghost Dye
    [9303] = {tradeable=true, price=8000}, -- Recipe: Philosopher's Stone
    [9304] = {tradeable=true, price=8000}, -- Recipe: Transmute Iron to Gold
    [9305] = {tradeable=false, price=8000}, -- Recipe: Transmute Mithril to Truesilver
    [10858] = {tradeable=false, price=3000}, -- Plans: Solid Iron Maul
    [11039] = {tradeable=false, price=800}, -- Formula: Enchant Cloak - Minor Agility
    [11101] = {tradeable=true, price=2500}, -- Formula: Enchant Bracer - Lesser Strength
    [11163] = {tradeable=false, price=3000}, -- Formula: Enchant Bracer - Lesser Deflection
    [12162] = {tradeable=true, price=3000}, -- Plans: Hardened Iron Shortsword
    [12163] = {tradeable=false, price=4400}, -- Plans: Moonsteel Broadsword
    [12226] = {tradeable=true, price=25}, -- Recipe: Crispy Bat Wing
    [12227] = {tradeable=false, price=1600}, -- Recipe: Lean Wolf Steak
    [12228] = {tradeable=false, price=5000}, -- Recipe: Roast Raptor
    [12229] = {tradeable=false, price=5000}, -- Recipe: Hot Wolf Ribs
    [12232] = {tradeable=false, price=5000}, -- Recipe: Carrion Surprise
    [12239] = {tradeable=true, price=7000}, -- Recipe: Dragonbreath Chili
    [12240] = {tradeable=false, price=7000}, -- Recipe: Heavy Kodo Stew
    [12819] = {tradeable=false, price=16000}, -- Plans: Ornate Thorium Handaxe
    [12958] = {tradeable=true, price=50000}, -- Recipe: Transmute Arcanite
    [13287] = {tradeable=true, price=2500}, -- Pattern: Raptor Hide Harness
    [13308] = {tradeable=false, price=1800}, -- Schematic: Ice Deflector
    [13310] = {tradeable=false, price=2000}, -- Schematic: Accurate Scope
    [13477] = {tradeable=true, price=12000}, -- Recipe: Superior Mana Potion
    [13939] = {tradeable=true, price=16000}, -- Recipe: Spotted Yellowtail
    [13940] = {tradeable=true, price=16000}, -- Recipe: Cooked Glossy Mightfish
    [13941] = {tradeable=true, price=16000}, -- Recipe: Filet of Redgill
    [13942] = {tradeable=true, price=16000}, -- Recipe: Grilled Squid
    [13943] = {tradeable=true, price=16000}, -- Recipe: Hot Smoked Bass
    [13945] = {tradeable=true, price=20000}, -- Recipe: Nightfin Soup
    [13946] = {tradeable=true, price=20000}, -- Recipe: Poached Sunscale Salmon
    [13947] = {tradeable=true, price=20000}, -- Recipe: Lobster Stew
    [13948] = {tradeable=true, price=20000}, -- Recipe: Mightfish Steak
    [13949] = {tradeable=true, price=20000}, -- Recipe: Baked Salmon
    [14468] = {tradeable=true, price=12000}, -- Pattern: Runecloth Bag
    [14481] = {tradeable=false, price=16000}, -- Pattern: Runecloth Gloves
    [14483] = {tradeable=false, price=16000}, -- Pattern: Felcloth Pants
    [14504] = {tradeable=true}, -- Pattern: Runecloth Shoulders
    [14526] = {tradeable=false, price=20000}, -- Pattern: Mooncloth
    [14630] = {tradeable=false, price=1000}, -- Pattern: Enchanter's Cowl
    [14635] = {tradeable=true, price=3000}, -- Pattern: Gem-studded Leather Belt
    [15725] = {tradeable=false, price=12000}, -- Pattern: Wicked Leather Gauntlets
    [15734] = {tradeable=true, price=14000}, -- Pattern: Living Shoulders
    [15740] = {tradeable=false, price=16000}, -- Pattern: Frostsaber Boots
    [15756] = {tradeable=false, price=22000}, -- Pattern: Runic Leather Headband
    [16042] = {tradeable=true, price=12000}, -- Schematic: Thorium Widget
    [16046] = {tradeable=false, price=16000}, -- Schematic: Masterwork Target Dummy
    [16047] = {tradeable=false, price=16000}, -- Schematic: Thorium Tube
    [16050] = {tradeable=false, price=20000}, -- Schematic: Delicate Arcanite Converter
    [16072] = {tradeable=true, price=10000}, -- Expert Cookbook
    [16083] = {tradeable=true, price=10000}, -- Expert Fishing - The Bass and You
    [16084] = {tradeable=true, price=10000}, -- Expert First Aid - Under Wraps
    [16110] = {tradeable=true, price=12000}, -- Recipe: Monster Omelet
    [16112] = {tradeable=true, price=2200}, -- Manual: Heavy Silk Bandage
    [16113] = {tradeable=true, price=5000}, -- Manual: Mageweave Bandage
    [16217] = {tradeable=false, price=12000}, -- Formula: Enchant Shield - Greater Stamina
    [16221] = {tradeable=true, price=16000}, -- Formula: Enchant Chest - Major Stamina
    [16224] = {tradeable=true, price=20000}, -- Formula: Enchant Cloak - Superior Defense
    [16243] = {tradeable=false, price=22000}, -- Formula: Runed Arcanite Rod
    [17062] = {tradeable=true, price=2200}, -- Recipe: Mithril Head Trout
    [18046] = {tradeable=true, price=12000}, -- Recipe: Tender Wolf Steak
    [18239] = {tradeable=true, price=3500}, -- Pattern: Shadowskin Gloves
    [18650] = {tradeable=false, price=5000}, -- Schematic: EZ-Thro Dynamite II
    [18651] = {tradeable=false, price=12000}, -- Schematic: Truesilver Transformer
    [18652] = {tradeable=true, price=12000}, -- Schematic: Gyrofreeze Ice Reflector
    [18656] = {tradeable=true, price=16000}, -- Schematic: Powerful Seaforium Charge
    [20752] = {tradeable=true, price=3000}, -- Formula: Minor Mana Oil
    [20753] = {tradeable=true, price=4000}, -- Formula: Lesser Wizard Oil
    [20754] = {tradeable=true, price=10000}, -- Formula: Lesser Mana Oil
    [20758] = {tradeable=true, price=500}, -- Formula: Minor Wizard Oil
    [21099] = {tradeable=true, price=500}, -- Recipe: Smoked Sagefish
    [21219] = {tradeable=true, price=5000}, -- Recipe: Sagefish Delight
    [21358] = {tradeable=true, price=12000}, -- Pattern: Soul Pouch
    [22307] = {tradeable=true, price=6000}, -- Pattern: Enchanted Mageweave Pouch
    [249879] = {tradeable=false}, -- Recipe: Peace Tea
    [249880] = {tradeable=false}, -- Recipe: Royal Tea
    [249881] = {tradeable=false}, -- Recipe: Root Tea
    [249882] = {tradeable=false}, -- Recipe: Triage Tea
    [249883] = {tradeable=false}, -- Recipe: Sunny Tea
    [249884] = {tradeable=false}, -- Recipe: Sage's Tea
    [251468] = {tradeable=false, price=100000}, -- Plans: Bold Dirk
    [254036] = {tradeable=false}, -- Pattern: Mageweave Reagent Bag
    [254080] = {tradeable=false}, -- Pattern: Runecloth Reagent Bag
    [254124] = {tradeable=false, price=100000}, -- Pattern: Runecloth Cuffs
}
