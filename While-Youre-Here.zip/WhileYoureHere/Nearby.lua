local _,ns=...
local instances={
    ["Ragefire Chasm"]=62031,["Hall of Thanes"]=62031,["Ruins of Lordaeron"]=62031,["Wailing Caverns"]=62031,
    ["The Deadmines"]=62031,["Shadowfang Keep"]=62031,["Excavation Site: Wetlands"]=62031,
    ["Blackfathom Deeps"]=62032,["Razorfen Kraul"]=62032,["City of Dalaran"]=62032,["Gnomeregan"]=62032,
    ["Scarlet Monastery"]=62032,["The Drowned City"]=62032,["Krol'dok Stronghold"]=62032,
    ["Razorfen Downs"]=62033,["Uldaman"]=62033,["Zul'Farrak"]=62033,["Maraudon"]=62033,
    ["Alcaz Prison"]=62033,["The Temple of Atal'Hakkar"]=62033,["Sunken Temple"]=62033,
    ["Blackrock Depths"]=62033,["Blackrock Spire"]=62033,["Blackmaw Hold"]=62033,
    ["Dire Maul"]=62033,["Stratholme"]=62033,["Scholomance"]=62033,["The Shaper's Terrace"]=62033
}
local groups={[62031]="Novice",[62032]="Experienced",[62033]="Master"}
function ns.AddNearbyTips(s,add,vendorAdd)
    local vendors = ns.FeatureEnabled("vendors") and ns.AddRecipeStopTips(s,vendorAdd or add)
    if not ns.FeatureEnabled("dungeons") then return vendors end
    ns.AddDungeonPickupTips(s,add)
    if not GetInstanceInfo then return vendors end
    local name,kind=GetInstanceInfo()
    local id=kind=="party" and instances[name]
    if not id then return vendors end
    local done=false
    if GetAchievementInfo then local ok,_,_,_,value=pcall(GetAchievementInfo,id);done=ok and value==true end
    if not done then
        add("Check "..groups[id].." Spelunker",name.." is on this achievement route. Check the wing in Legacy (Y) and defeat its final boss if you still need credit.",22,"dungeon:"..name,nil,true)
    end
    return vendors
end
