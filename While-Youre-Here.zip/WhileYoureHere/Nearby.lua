local _,ns=...
local instances={
    ["Ragefire Chasm"]=62031,["Hall of Thanes"]=62031,["Ruins of Lordaeron"]=62031,["Wailing Caverns"]=62031,
    ["The Deadmines"]=62031,["Shadowfang Keep"]=62031,["Excavation Site: Wetlands"]=62031,
    ["Blackfathom Deeps"]=62032,["Razorfen Kraul"]=62032,["City of Dalaran"]=62032,["Gnomeregan"]=62032,
    ["Scarlet Monastery"]=62032,["The Drowned City"]=62032,["Krol'dok Stronghold"]=62032,
    ["Razorfen Downs"]=62033,["Uldaman"]=62033,["Zul'Farrak"]=62033,["Maraudon"]=62033,
    ["Alcaz Prison"]=62033,["The Temple of Atal'Hakkar"]=62033,["Sunken Temple"]=62033,
    ["Blackrock Depths"]=62033,["Blackrock Spire"]=62033,["Blackmaw Hold"]=62033,
    ["Dire Maul"]=62033,["Stratholme"]=62033,["Scholomance"]=62033,["The Shaper's Terrace"]=62033
}
local groups={[62031]="Novice",[62032]="Experienced",[62033]="Master"}
local function unfinishedCriterion(id, dungeon)
    if not GetAchievementNumCriteria or not GetAchievementCriteriaInfo then return false end
    local ok, count = pcall(GetAchievementNumCriteria, id)
    if not ok or type(count) ~= "number" then return false end
    for i=1,count do
        local read, name, _, complete = pcall(GetAchievementCriteriaInfo, id, i)
        if read and name == dungeon then return complete == false end
    end
    return false
end
function ns.AddNearbyTips(s,add,vendorAdd,instance)
    instance = instance or ns.CurrentInstance(s)
    local vendors = not instance and ns.FeatureEnabled("vendors") and ns.AddRecipeStopTips(s,vendorAdd or add)
    if not ns.FeatureEnabled("dungeons") then return vendors end
    ns.AddDungeonPickupTips(s,add,instance)
    local name=instance and instance.kind=="party" and (instance.wing or not instance.shared and instance.dungeon)
    local id=name and instances[instance.dungeon]
    if id and unfinishedCriterion(id, name) then
        add("Finish "..name.." for Spelunker","Defeat the final boss for credit towards "..groups[id].." Spelunker. Check your progress in Legacy (Y).",
            35,"dungeon:"..name,nil,false)
    end
    return vendors
end
