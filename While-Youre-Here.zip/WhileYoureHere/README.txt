While You're Here 0.3.17
WoW Forever levelling and profession adviser by Rosethorn

Install or upgrade
Exit WoW. Extract the WhileYoureHere folder into Interface/AddOns. The manifest should be Interface/AddOns/WhileYoureHere/WhileYoureHere.toc.

Upgrading from RosethornAdvisor? With the game closed, open WTF/Account/<account>/SavedVariables. Copy RosethornAdvisor.lua in the same folder and name the copy WhileYoureHere.lua. Keep the original as a backup. If a WhileYoureHere.lua already exists, back it up before replacing it with the older install's data. Move the old RosethornAdvisor addon folder out of Interface/AddOns. Future updates use the WhileYoureHere folder directly.

Log in and left-click the rose compass for your tips. Click Guide to open Fishing. Right-click the compass for General, Tips and Appearance. The addon works on its own. Auctionator adds price estimates and RestedXP can supply its active waypoint.

Guide
• Fishing — Choose Cooking skill, Food for my build or Gold. Cooking checks what you can make from your bags, recipe colours, other ingredients and Cooking caps. Food checks edible servings, class and build. If supplies are ready, the card also names a water for your next casts.
• Log water — Choose the actual water or pool before casting to keep evidence specific to that spot. Labelling stops after an idle period or a change of location. Other fishing sessions still contribute to area history. Gold comparisons use your eligible repeat catches, fishing time and available prices. The session shows catches and estimated gold per hour, with each catch valued at the higher of vendor or estimated after-fee auction proceeds. A price estimate is conditional on selling the fish.
• Now → Before you skip ahead — Select the zone you intend to skip, then optionally a dungeon. Review available pickups or the earliest outstanding prerequisite for covered chains. The check leaves your RestedXP guide and quest log alone.
• Professions — Browse the next step on the current character. Select a trained primary craft and Reserve materials for one upcoming crafting Legacy Point. Use Plan on this character for an unlearned profession.
• Alts — Compare recorded crafting milestones and class-level milestones. Set as main to 60 identifies your preferred character. Bank and alt figures reflect your most recent visit. Open each relevant bank and profession window to update them.

On the way
Dungeon alerts check a covered outdoor zone or capital, including city quarters. Map several givers, or use Navigate for one waypoint. Accepting or completing the relevant pickup clears it. Available records cover Horde and a smaller, identified set of Alliance and shared quests.

Verified missing recipes and applicable training books can glow in the relevant zone or hub. Multiple confirmed purchases from the same merchant share a stop. Open your own profession window to confirm missing recipes. Tradeable books can show an auction alternative. Under General, set Value of travel time to compare a recent auction premium with the time a detour would cost.

At a mailbox, check recorded supplies and recipients eligible to use them. Profession goals and shopping estimates distinguish materials you own from additional purchases. Use the game's Legacy screen for official account credit.

Settings
General, Tips and Appearance are shared across this installation. Move or resize the interface, change colours and transparency, snooze alerts, and switch off individual categories. In Appearance, select Icon border to customise the rose compass frame. Alert glow controls the notification glow separately. Fishing goals, quest progress, pins and profession plans are character-specific. To open a page directly, use /wyh now, /wyh professions, /wyh alts, /wyh fishing or /wyh skip.

Data credits
See DungeonData-Sources.txt and DungeonData-GPL-3.0.txt for dungeon data and licence details.
Official profession list: https://worldofwarcraft.blizzard.com/en-us/news/24301516
WoW Forever Legacy system: https://worldofwarcraft.blizzard.com/en-us/news/24307383/get-to-know-the-world-of-warcraft-forever-legacy-system
Rockscale Cod recipe: https://wowforever.ninja/professions/cooking/7828-rockscale-cod/
Kelsey Yance directions: https://www.wow-professions.com/forever/npc/kelsey-yance
Expert Cookbook: https://bindonforever.com/item/16072
Vendor and spell sources for the individual entries are in Data.lua.
