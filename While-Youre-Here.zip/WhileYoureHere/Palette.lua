local _, ns = ...

local targets = {
    {name="Alert glow", key="glow", alpha="glowAlpha"},
    {name="Icon border", key="iconBorder", alpha="iconBorderAlpha"},
    {name="Background", key="bg", alpha="bgAlpha"},
    {name="Text", key="fg", alpha="fgAlpha"},
    {name="Window border", key="border", alpha="borderAlpha"},
}
local presets = {
    {"White","FFFFFF"}, {"Silver","BCBEC4"}, {"Black","000000"}, {"Parchment","F1E8D4"},
    {"Red","FF3333"}, {"Orange","FF902B"}, {"Gold","FFD957"}, {"Yellow","FFF360"},
    {"Green","48D56D"}, {"Cyan","53E3ED"}, {"Blue","478CFF"}, {"Violet","AA78FF"},
    {"Pink","FF82BD"}, {"Brown","9A6944"},
}
local function rgb(hex)
    return tonumber(hex:sub(1,2),16)/255, tonumber(hex:sub(3,4),16)/255, tonumber(hex:sub(5,6),16)/255
end
local function asHex(r,g,b)
    local function channel(v) return math.floor(math.max(0,math.min(1,v))*255+.5) end
    return ("%02X%02X%02X"):format(channel(r),channel(g),channel(b))
end
local function label(parent,font)
    local text=parent:CreateFontString(nil,"OVERLAY",font or "GameFontHighlightSmall")
    text:SetJustifyH("LEFT")
    return text
end
local function tip(widget,title,body)
    widget:SetScript("OnEnter",function(self)
        GameTooltip:SetOwner(self,"ANCHOR_RIGHT"); GameTooltip:SetText(title)
        if body then GameTooltip:AddLine(body,1,1,1,true) end
        GameTooltip:Show()
    end)
    widget:SetScript("OnLeave",function() GameTooltip:Hide() end)
end
local function solid(parent,layer,w,h,x,y,shade)
    local texture=parent:CreateTexture(nil,layer)
    texture:SetSize(w,h);texture:SetPoint("TOPLEFT",parent,"TOPLEFT",x,-y)
    texture:SetColorTexture(shade,shade,shade,1)
    return texture
end
local function checker(parent,w,h,x,y,tile)
    solid(parent,"BACKGROUND",w,h,x,y,.72)
    for row=0,math.ceil(h/tile)-1 do
        for col=row%2,math.ceil(w/tile)-1,2 do
            solid(parent,"BORDER",math.min(tile,w-col*tile),math.min(tile,h-row*tile),
                x+col*tile,y+row*tile,.33)
        end
    end
end
local function chip(parent,size,x,y)
    checker(parent,size,size,x,y,size/2)
    return solid(parent,"ARTWORK",size,size,x,y,1)
end

local function createWheel(parent,change)
    local ok,wheel=pcall(CreateFrame,"ColorSelect",nil,parent)
    if not ok then return end
    if not wheel.SetColorWheelTexture or not wheel.SetColorRGB then wheel:Hide();return end
    wheel:SetSize(163,136);wheel:SetPoint("TOPLEFT",7,-28);wheel:EnableMouse(true)
    local disc=wheel:CreateTexture(nil,"ARTWORK")
    disc:SetSize(136,136);disc:SetPoint("TOPLEFT");wheel:SetColorWheelTexture(disc)
    local value=wheel:CreateTexture(nil,"ARTWORK")
    value:SetSize(15,136);value:SetPoint("TOPRIGHT");wheel:SetColorValueTexture(value)
    local dot=wheel:CreateTexture(nil,"OVERLAY")
    dot:SetTexture("Interface\\Buttons\\UI-ColorPicker-Buttons")
    dot:SetSize(10,10);dot:SetTexCoord(0,.15625,0,.625);wheel:SetColorWheelThumbTexture(dot)
    local arrows=wheel:CreateTexture(nil,"OVERLAY")
    arrows:SetTexture("Interface\\Buttons\\UI-ColorPicker-Buttons")
    arrows:SetSize(24,9);arrows:SetTexCoord(.25,1,.875,0);wheel:SetColorValueThumbTexture(arrows)
    wheel:SetScript("OnColorSelect",function(_,r,g,b) change(asHex(r,g,b)) end)
    tip(wheel,"Colour and brightness","Choose a hue on the wheel. Drag the strip beside it to lighten or darken the colour.")
    return wheel
end

function ns.CreateTipPalette(page,cfg,close)
    local pane=CreateFrame("Frame",nil,page)
    pane:SetPoint("TOPLEFT",page,"TOPLEFT",4,-page.offset);pane:SetSize(349,272)
    page.offset=page.offset+276
    local target=targets[1]
    local draft, syncing, wheel, currentChip
    local selectorChips, activeLines, bands, presetButtons, presetTints = {},{},{},{},{}
    local heading=label(pane,"GameFontNormal");heading:SetPoint("TOPLEFT",3,-2)
    local amount=label(pane);amount:SetPoint("TOPLEFT",4,-189)
    local status=label(pane);status:SetPoint("TOPRIGHT",-4,-189)
    local slider=CreateFrame("Slider",nil,pane)
    local function transparencyAllowed()
        return target.key~="bg" or cfg.background~="Clear"
    end
    local function draw(syncWheel)
        if not draft then return end
        syncing=true
        draft.selectedColourTarget=target.key
        local r,g,b=rgb(draft[target.key])
        if wheel and syncWheel then wheel:SetColorRGB(r,g,b) end
        for i,t in ipairs(targets) do
            local cr,cg,cb=rgb(draft[t.key])
            selectorChips[i]:SetColorTexture(cr,cg,cb,1)
            activeLines[i]:SetShown(target==t)
        end
        local allowed=transparencyAllowed()
        local transparency=allowed and (100-draft[target.alpha]) or 100
        currentChip:SetColorTexture(r,g,b,1-transparency/100)
        heading:SetText(target.name.." colour")
        amount:SetText("Transparency  "..transparency.."%")
        status:SetText(allowed and "" or "Clear background is always transparent")
        for i,band in ipairs(bands) do band:SetColorTexture(r,g,b,1-(i-1)/(#bands-1)) end
        slider:SetValue(transparency);slider:SetEnabled(allowed)
        for i,button in ipairs(presetButtons) do
            presetTints[i]:SetColorTexture(r,g,b,1-(i-1)/4)
            button:SetEnabled(allowed)
        end
        syncing=false
    end
    local function preview(syncWheel)
        draw(syncWheel)
        ns.ApplyTipAppearance()
    end
    local function changeColour(value,fromWheel)
        if syncing or not draft then return end
        if value~=draft[target.key] then
            draft[target.key]=value;preview(not fromWheel)
        end
    end
    local function setTransparency(value)
        if syncing or not draft or not transparencyAllowed() then return end
        local alpha=100-math.floor(math.max(0,math.min(100,value))+.5)
        if alpha~=draft[target.alpha] then draft[target.alpha]=alpha;preview(false) end
    end
    wheel=createWheel(pane,function(value) changeColour(value,true) end)
    currentChip=chip(pane,24,212,26)
    local currentLabel=label(pane);currentLabel:SetText("Preview");currentLabel:SetPoint("TOPLEFT",244,-32)
    for i,t in ipairs(targets) do
        local choice=t
        local button=ns.AdvisorButton(pane,t.name,136,21,function() target=choice;preview(true) end)
        button:SetPoint("TOPLEFT",209,-(51+(i-1)*23))
        selectorChips[i]=chip(button,12,4,4)
        activeLines[i]=solid(button,"OVERLAY",126,2,5,18,.9)
        activeLines[i]:SetColorTexture(1,.83,.36,1)
    end
    for i,entry in ipairs(presets) do
        local name,hex=entry[1],entry[2]
        local button=CreateFrame("Button",nil,pane)
        if wheel then
            button:SetSize(22,16);button:SetPoint("TOPLEFT",3+(i-1)*24,-169)
            solid(button,"ARTWORK",20,14,1,1,1):SetColorTexture(rgb(hex))
        else
            button:SetSize(32,29);button:SetPoint("TOPLEFT",4+((i-1)%5)*34,-(32+math.floor((i-1)/5)*32))
            solid(button,"ARTWORK",30,27,1,1,1):SetColorTexture(rgb(hex))
        end
        button.colourName=name;tip(button,name)
        button:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square","ADD")
        button:SetScript("OnClick",function() changeColour(hex) end)
    end
    if not wheel and ColorPickerFrame and ColorPickerFrame.SetupColorPickerAndShow then
        local custom=ns.AdvisorButton(pane,"Colour wheel",131,23,function()
            local editing,session=target,draft
            if not session then return end
            local original=session[editing.key]
            local r,g,b=rgb(original)
            local function apply(value)
                if session~=draft then return end
                session[editing.key]=value;preview(true)
            end
            ColorPickerFrame:SetupColorPickerAndShow({r=r,g=g,b=b,hasOpacity=false,
                swatchFunc=function() apply(asHex(ColorPickerFrame:GetColorRGB())) end,
                cancelFunc=function() apply(original) end})
        end)
        custom:SetPoint("TOPLEFT",8,-135)
    end
    slider:SetSize(18,136);slider:SetPoint("TOPLEFT",183,-28);slider:SetOrientation("VERTICAL")
    checker(slider,16,136,1,0,8)
    for i=1,34 do bands[i]=solid(slider,"ARTWORK",16,4,1,(i-1)*4,1) end
    local thumb=slider:CreateTexture(nil,"OVERLAY")
    thumb:SetTexture("Interface\\Buttons\\UI-ColorPicker-Buttons")
    thumb:SetSize(24,9);thumb:SetTexCoord(.25,1,.875,0)
    slider:SetThumbTexture(thumb);slider:SetMinMaxValues(0,100);slider:SetValueStep(1)
    if slider.SetObeyStepOnDrag then slider:SetObeyStepOnDrag(true) end
    slider:EnableMouse(true)
    slider:SetScript("OnValueChanged",function(_,value) setTransparency(value) end)
    tip(slider,"Transparency","Drag down for transparent or up for opaque.")
    for i=1,5 do
        local percent=(i-1)*25
        local button=ns.AdvisorButton(pane,percent.."%",65,22,function() setTransparency(percent) end)
        button:SetPoint("TOPLEFT",3+(i-1)*69,-207)
        presetButtons[i]=button;presetTints[i]=chip(button,12,3,5)
    end
    local function start()
        draft=setmetatable({},{__index=cfg})
        for _,t in ipairs(targets) do draft[t.key],draft[t.alpha]=cfg[t.key],cfg[t.alpha] end
        ns.ColourPreview=draft
        draw(true)
    end
    local function finish(save)
        if not draft then return end
        if save then
            for _,t in ipairs(targets) do cfg[t.key],cfg[t.alpha]=draft[t.key],draft[t.alpha] end
        end
        ns.ColourPreview=nil;draft=nil
    end
    local reset=ns.AdvisorButton(pane,"Reset",77,23,function()
        if not draft then return end
        draft[target.key],draft[target.alpha]=ns.DefaultTipColour(target.key),ns.DefaultTipColour(target.alpha)
        preview(true)
    end)
    reset:SetPoint("TOPLEFT",3,-241);tip(reset,"Reset","Restore the selected colour and transparency to their defaults.")
    local okay=ns.AdvisorButton(pane,"Okay",77,23,function() finish(true);close() end)
    okay:SetPoint("TOPRIGHT",-85,-241)
    local cancel=ns.AdvisorButton(pane,"Cancel",77,23,function() finish(false);close() end)
    cancel:SetPoint("TOPRIGHT",-3,-241)
    return {start=start,stop=function() finish(false) end,refresh=function() draw(true) end}
end
