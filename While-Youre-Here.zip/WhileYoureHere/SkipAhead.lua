local _, ns = ...
local zones, zoneByID, dungeons, dungeonNames
local byQuest, children
local zonesForCharacter, dungeonsForCharacter = {}, {}
local gateFields = {"after", "anyAfter", "active", "activeOrDone"}

local function list(value)
    if type(value) == "table" then return value end
    return value and {value} or {}
end

local function indexCatalogue()
    if byQuest then return end
    zones, zoneByID, dungeons, dungeonNames, byQuest, children = {}, {}, {}, {}, {}, {}
    local function indexRow(q, map)
        byQuest[q.id] = byQuest[q.id] or {}
        table.insert(byQuest[q.id], {q=q, map=map})
        for name in q.dungeon:gmatch("[^/]+") do
            name = name:match("^%s*(.-)%s*$")
            if not dungeonNames[name] then
                dungeonNames[name] = true
                table.insert(dungeons, name)
            end
        end
        for _, field in ipairs(gateFields) do
            for _, id in ipairs(list(q[field])) do
                children[id] = children[id] or {}
                table.insert(children[id], {q=q, field=field})
            end
        end
        if q.routeFrom then
            children[q.routeFrom] = children[q.routeFrom] or {}
            table.insert(children[q.routeFrom], {q=q, field="route"})
        end
    end
    for id, rows in pairs(ns.DungeonPickupData or {}) do
        local zone = {mapID=id, name=ns.DungeonPickupZoneNames[id]}
        zoneByID[id] = zone
        table.insert(zones, zone)
        for _, q in ipairs(rows) do indexRow(q, id) end
    end
    for map, rows in pairs(ns.DungeonInstancePickupData or {}) do
        for _, q in ipairs(rows) do indexRow(q, map) end
    end
    for _, q in ipairs(ns.DungeonItemPickupData or {}) do indexRow(q) end
    table.sort(zones, function(a,b) return a.name < b.name end)
    table.sort(dungeons)
end

local function factionFor(s)
    s = s or ns.state
    return (ns.AdvisorFaction and ns.AdvisorFaction(s)) or (s and s.faction)
end

function ns.SkipZones(s)
    indexCatalogue()
    local allows, key = ns.DungeonCharacterFilter(s)
    if not zonesForCharacter[key] then
        local result = {}
        for _, zone in ipairs(zones) do
            for _, q in ipairs(ns.DungeonPickupData[zone.mapID]) do
                if allows(q) then
                    table.insert(result, zone)
                    break
                end
            end
        end
        zonesForCharacter[key] = result
    end
    return zonesForCharacter[key]
end

function ns.SkipZone(s)
    indexCatalogue()
    local record = ns.CurrentRecord()
    local selected = record and zoneByID[record.skipReviewZone]
    local current = s and ns.OutdoorZoneForData(s, ns.DungeonPickupData)
    local fallback
    for _, zone in ipairs(ns.SkipZones(s)) do
        if zone == selected then return zone end
        if zone.mapID == current then fallback = zone end
    end
    return fallback
end

function ns.SetSkipZone(mapID)
    indexCatalogue()
    local record = ns.CurrentRecord()
    if record and (not mapID or zoneByID[mapID]) then record.skipReviewZone = mapID end
end

function ns.SkipDungeons(s)
    indexCatalogue()
    local allows, key = ns.DungeonCharacterFilter(s)
    if not dungeonsForCharacter[key] then
        local selected = {}
        for _, entries in pairs(byQuest) do
            for _, entry in ipairs(entries) do
                if allows(entry.q) then
                    for name in entry.q.dungeon:gmatch("[^/]+") do selected[name:match("^%s*(.-)%s*$")] = true end
                end
            end
        end
        local result = {}
        for _, name in ipairs(dungeons) do if selected[name] then table.insert(result, name) end end
        dungeonsForCharacter[key] = result
    end
    return dungeonsForCharacter[key]
end

function ns.SetSkipDungeon(name)
    indexCatalogue()
    local record = ns.CurrentRecord()
    if record and (not name or dungeonNames[name]) then record.skipReviewDungeon = name end
end

function ns.SkipDungeon()
    indexCatalogue()
    local record = ns.CurrentRecord()
    local name = record and record.skipReviewDungeon
    if name then
        for _, available in ipairs(ns.SkipDungeons()) do
            if available == name then return name end
        end
    end
end

local function includesDungeon(q, wanted)
    if not wanted then return true end
    return (" / " .. q.dungeon .. " / "):find(" / " .. wanted .. " / ", 1, true) ~= nil
end

local function satisfied(ctx, id, gate)
    if gate == "active" then return ctx.active(id) end
    if gate == "activeOrDone" then return ctx.active(id) or ctx.done(id) end
    return ctx.done(id)
end

local function firstBlocker(ctx, q)
    for _, field in ipairs(gateFields) do
        local ids = list(q[field])
        if field == "anyAfter" then
            local met, first, score = false, nil, -1
            for _, id in ipairs(ids) do
                if ctx.done(id) then met = true break end
                local rank = ctx.active(id) and 3 or 0
                for _, entry in ipairs(byQuest[id] or {}) do
                    if ctx.fits(entry.q) then rank = rank + 1; break end
                end
                if rank > score then first, score = id, rank end
            end
            if first and not met then return first, field, #ids > 1 end
        else
            for _, id in ipairs(ids) do
                if not satisfied(ctx, id, field) then return id, field end
            end
        end
    end
end

local function chooseEntry(ctx, s, id, preferredMap)
    local chosen, weight = nil, -1
    for _, entry in ipairs(byQuest[id] or {}) do
        local q = entry.q
        if ctx.fits(q) then
            local score = (entry.map == preferredMap and 16 or 0) + (ctx.ready(q) and 8 or 0)
                + (s.subzone and q.area == s.subzone and 4 or 0)
                + (q.pin and 2 or 0) + (not q.check and 1 or 0)
            if score > weight then chosen, weight = entry, score end
        end
    end
    return chosen
end

local function location(entry)
    if not entry then return end
    local q = entry.q
    local zone = zoneByID[entry.map] and zoneByID[entry.map].name
        or (type(entry.map) == "string" and entry.map)
    local parts = {q.giver or "Quest start"}
    if q.area and q.area ~= q.giver and q.area ~= zone then table.insert(parts, q.area) end
    if zone and zone ~= q.giver then table.insert(parts, zone) end
    return table.concat(parts, ", ")
end

local function waypoint(entry)
    if not entry or not entry.q.pin then return end
    local q, p = entry.q, entry.q.pin
    return {mapID=p.mapID, x=p.x, y=p.y, name=q.giver, npcID=q.npcID, questID=q.id}
end

-- Only restore a grey step when a known, still-open path reaches a useful
-- later quest. Other completed branches cannot make the grey step necessary.
local function followUp(ctx, s, start, wanted)
    local visited = {}
    local best
    local function walk(id)
        if visited[id] then return end
        visited[id] = true
        for _, edge in ipairs(children[id] or {}) do
            local q, needed = edge.q, true
            if edge.field == "anyAfter" then
                for _, other in ipairs(list(q.anyAfter)) do
                    if other ~= id and ctx.done(other) then needed = false break end
                end
            end
            if needed and ctx.fits(q) and ctx.done(q.id) == false and ctx.active(q.id) == false
                and (not q.skill or (s.skills and s.skills[q.skill.name])) then
                if includesDungeon(q, wanted) and not ctx.grey(q)
                    and (not best or (q.level or 0) > (best.level or 0)
                         or (q.level == best.level and q.id < best.id)) then best = q end
                walk(q.id)
            end
        end
    end
    walk(start)
    return best
end

local function constraint(ctx, s, q)
    if q.offerOnly or q.check then return q.note or "Speak to the quest giver to check availability." end
    if q.skill then return q.skill.name .. " " .. q.skill.rank .. " required." end
    if q.rep then
        local label = _G["FACTION_STANDING_LABEL" .. q.rep.standing] or ("standing " .. q.rep.standing)
        local info = C_Reputation and C_Reputation.GetFactionDataByID and C_Reputation.GetFactionDataByID(q.rep.id)
        local name = (info and info.name) or (GetFactionInfoByID and GetFactionInfoByID(q.rep.id))
        return label .. " with " .. (name or ("faction " .. q.rep.id)) .. " required."
    end
    if q.itemID and not ctx.carries(q.itemID) then
        return q.note or ("Requires " .. ((GetItemInfo and GetItemInfo(q.itemID)) or ("item #" .. q.itemID)) .. ".")
    end
    if q.ghost then return "Available in ghost form." end
    for _, id in ipairs(list(q.disabledWhileActive)) do
        if ctx.active(id) then
            local entry = chooseEntry(ctx, s, id)
            return "Finish " .. (entry and entry.q.name or ("quest #" .. id)) .. " first."
        end
    end
    return "Check availability with the quest giver."
end

-- Follow unmet requirements towards the next action, including across zones.
-- Leave OR branches worded as options and avoid inventing uncatalogued givers.
local function nextRequirement(ctx, s, q, zoneID, planned)
    local seen, option = {}, false
    local id, field, any = firstBlocker(ctx, q)
    while id and not seen[id] do
        -- An earlier local card already explains this branch, even if its
        -- own first actionable prerequisite is several zones away.
        if planned[id] then return end
        option = option or any
        seen[id] = true
        local entry = chooseEntry(ctx, s, id, zoneID)
        local prefix = option and "One route: " or ""
        local active = ctx.active(id)
        if ctx.done(id) == nil or active == nil then
            return prefix .. "Quest history unavailable for prerequisite #" .. id .. "."
        end
        if not entry then
            local title = C_QuestLog and C_QuestLog.GetTitleForQuestID and C_QuestLog.GetTitleForQuestID(id)
            local action = (field == "active" or field == "activeOrDone") and "Accept " or "Complete "
            return prefix .. action .. (title or ("quest #" .. id)) .. " first."
        end
        if active then return prefix .. "Finish " .. entry.q.name .. " from your quest log.", nil, entry end
        if ctx.done(id) then return "Requires " .. entry.q.name .. " to be active." end
        if s.level < entry.q.min then
            return prefix .. "At level " .. entry.q.min .. ", see " .. location(entry) .. " for " .. entry.q.name .. ".", waypoint(entry), entry
        end
        local nextID, nextField, nextAny = firstBlocker(ctx, entry.q)
        if not nextID then
            if not ctx.ready(entry.q) or (entry.q.check and not ctx.offers[id]) then
                return prefix .. entry.q.name .. " — " .. constraint(ctx, s, entry.q), waypoint(entry), entry
            end
            return prefix .. "Start " .. entry.q.name .. " with " .. location(entry) .. ".", waypoint(entry), entry
        end
        id, field, any = nextID, nextField, nextAny
    end
    return "Check the prerequisite chain in your quest log."
end

function ns.SkipAdvice(s, add)
    if not s then return end
    if type(s.level) ~= "number" or s.level < 1 then
        add("Waiting for your level", "Reopen the review once your character has loaded.", 1, "skip:scope")
        return
    end
    local zone = ns.SkipZone(s)
    local faction = factionFor(s)
    if faction ~= "Horde" and faction ~= "Alliance" then
        add("Waiting for your faction", "Reopen the review once your character has loaded.", 1, "skip:scope")
        return
    end
    if not zone then
        add("Choose a zone to review", "Select the zone whose levelling steps you plan to skip.", 1, "skip:zone")
        return
    end
    local wanted = ns.SkipDungeon()
    local scope = "Known dungeon pickups at your level. Grey starters appear when they lead to a useful follow-up."
    if faction == "Alliance" then scope = scope .. " Alliance coverage is partial." end
    local route = ns.GetRouteContext and ns.GetRouteContext(s)
    if route and route.reason == "Active RestedXP waypoint" then scope = scope .. "\n" .. route.compass end
    add(zone.name .. (wanted and (" · " .. wanted) or ""), scope, 1, "skip:scope")
    local ctx = ns.DungeonReviewContext(s)
    local rows = ns.DungeonPickupData[zone.mapID]
    local planned, emitted, uncertain = {}, 0, false
    for _, q in ipairs(rows) do
        if s.level >= q.min and ctx.fits(q) and not planned[q.id] then
            local done, active = ctx.done(q.id), ctx.active(q.id)
            if done == nil or active == nil then
                uncertain = true
            elseif not done then
                local direct = includesDungeon(q, wanted) and not ctx.grey(q)
                local later = not direct and followUp(ctx, s, q.id, wanted)
                if direct or later then
                    local entry = chooseEntry(ctx, s, q.id, zone.mapID)
                    if entry and entry.map == zone.mapID then planned[q.id] = {entry=entry, later=later} end
                end
            end
        end
    end
    for id, plan in pairs(planned) do
        local entry, later = plan.entry, plan.later
        local q = entry.q
        local title, body, target, priority
        if ctx.active(id) then
            title, body, priority = "In your log: " .. q.name, "Continue from your quest log.", 20
        elseif ctx.ready(q) and (not q.check or ctx.offers[id]) then
            title = q.itemStart and ("Use " .. q.giver) or ("Pick up " .. q.name)
            body = q.itemStart and ("Starts " .. q.name .. ".") or (location(entry) .. ".")
            target, priority = waypoint(entry), 10
        elseif firstBlocker(ctx, q) then
            local step, pin = nextRequirement(ctx, s, q, zone.mapID, planned)
            -- One actionable local step per chain. Cross-zone prerequisites
            -- remain visible even though the chosen zone has no ready giver.
            if step then
                title, body, target, priority = "Before " .. q.name, step, pin, 30
            end
        else
            title, body, target, priority = "Check " .. q.name, location(entry) .. ". " .. constraint(ctx, s, q), waypoint(entry), 40
        end
        if title then
            body = body .. "\n" .. q.dungeon .. " · Requires level " .. q.min .. ". " .. (ctx.levelText(q) or "")
            if later then body = body .. "\nLeads to " .. later.name .. " (" .. later.dungeon .. ")." end
            add(title, body, priority, "skip:quest:" .. id, target, false)
            emitted = emitted + 1
        end
    end
    if uncertain then
        add("Quest history unavailable", "Some pickups could not be checked. Reopen this review after your quest log has loaded.", 2, "skip:unknown")
    elseif emitted == 0 and next(planned) then
        add("Check your quest log", "The catalogue could not resolve a first step for these linked quests.", 2, "skip:unresolved")
    elseif emitted == 0 then
        add("No matching pickups found", "No catalogued steps match this zone, your current level and the selected dungeon filter.", 2, "skip:empty")
    end
end
