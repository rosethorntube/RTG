local _, ns = ...

-- Gathering requirements and node locations:
-- https://www.wowhead.com/forever/guide/professions/mining/overview-leveling
-- https://www.wowhead.com/forever/guide/professions/herbalism/overview-leveling
-- https://gearinsight.app/wow/en/forever/prof/skinning
-- https://foreverwow.com/professions/mining/leveling/
-- Character levels here are suggested travel levels, not profession requirements.
local zones = {
    [1411] = {"Durotar", 1, "K","Horde"}, [1412] = {"Mulgore", 1, "K","Horde"},
    [1413] = {"the Barrens", 12, "K","Horde"}, [1420] = {"Tirisfal Glades", 1, "E","Horde"},
    [1421] = {"Silverpine Forest", 12, "E","Horde"}, [1424] = {"Hillsbrad Foothills", 22, "E"},
    [1429] = {"Elwynn Forest",1,"E","Alliance"}, [1426] = {"Dun Morogh",1,"E","Alliance"},
    [1438] = {"Teldrassil",1,"K","Alliance"}, [1436] = {"Westfall",10,"E","Alliance"},
    [1432] = {"Loch Modan",10,"E","Alliance"}, [1439] = {"Darkshore",10,"K","Alliance"},
    [1431] = {"Duskwood",20,"E","Alliance"}, [1437] = {"the Wetlands",20,"E","Alliance"},
    [1453] = {"Stormwind",1,"E","Alliance"}, [1455] = {"Ironforge",1,"E","Alliance"}, [1457] = {"Darnassus",1,"K","Alliance"},
    [1442] = {"Stonetalon Mountains", 18, "K"}, [1440] = {"Ashenvale", 22, "K"},
    [1441] = {"Thousand Needles", 27, "K"}, [1417] = {"Arathi Highlands", 32, "E"},
    [1434] = {"Stranglethorn Vale", 32, "E"}, [1443] = {"Desolace", 32, "K"},
    [1416] = {"Alterac Mountains", 33, "E"}, [1418] = {"the Badlands", 38, "E"},
    [1445] = {"Dustwallow Marsh", 37, "K"}, [1446] = {"Tanaris", 42, "K"},
    [1425] = {"the Hinterlands", 42, "E"}, [1444] = {"Feralas", 42, "K"},
    [1448] = {"Felwood", 50, "K"}, [1419] = {"the Blasted Lands", 50, "E"},
    [1449] = {"Un'Goro Crater", 51, "K"}, [1422] = {"the Western Plaguelands", 52, "E"},
    [1447] = {"Azshara", 50, "K"}, [1452] = {"Winterspring", 55, "K"},
    [1423] = {"the Eastern Plaguelands", 55, "E"}, [1435] = {"the Swamp of Sorrows", 36, "E"},
    [1454] = {"Orgrimmar", 1, "K"}, [1456] = {"Thunder Bluff", 1, "K"},
    [1458] = {"Undercity", 1, "E"},
}
local cityExit = {[1454]=1411,[1456]=1412,[1458]=1420,[1453]=1429,[1455]=1426,[1457]=1438}
local nextZone = {[1429]=1436,[1426]=1432,[1438]=1439,[1420]=1421,[1411]=1413,[1412]=1413}

-- Each band starts at the effective skill required for its common resource.
-- Keep rare vein upgrades incidental; waiting for one is a poor levelling route.
local routes = {
    Mining = {
        {1, "Mine Copper Veins", {1411,1412,1420,1413,1421,1429,1426,1439,1436,1432}},
        {65, "Mine Tin Veins", {1413,1424,1421,1442,1440,1432,1436,1439}, 75, "Silver Veins"},
        {125, "Mine Iron Deposits", {1441,1417,1443,1434,1416,1424}, 155, "Gold Veins"},
        {175, "Mine Mithril Deposits", {1418,1446,1425,1416,1444,1417,1441,1424}, 230, "Truesilver Deposits"},
        {245, "Mine Small Thorium Veins", {1449,1419,1452,1422,1425,1446}},
        {275, "Mine Rich Thorium Veins", {1452,1423,1447,1449}},
    },
    Herbalism = {
        {1, "Gather Peacebloom and Silverleaf", {1411,1412,1420,1413,1421,1429,1426,1438,1436,1432,1439}},
        {50, "Gather Mageroyal", {1413,1421,1442,1436,1432,1439}},
        {70, "Gather Briarthorn", {1413,1421,1442,1440,1436,1432,1439}},
        {100, "Gather Bruiseweed", {1442,1424,1413,1440,1436,1432,1439}},
        {125, "Gather Kingsblood", {1440,1424,1442,1441,1434}},
        {150, "Gather Liferoot along the water", {1424,1434,1445,1417,1444}},
        {170, "Gather Goldthorn on hillsides", {1417,1434,1445,1444}},
        {185, "Gather Khadgar's Whisker near trees", {1434,1417,1435,1445,1444}},
        {205, "Gather Firebloom", {1446,1418}},
        {230, "Gather Sungrass", {1444,1425,1447,1449,1448}},
        {260, "Gather Golden Sansam", {1444,1425,1449,1447,1448,1423}},
        {270, "Gather Dreamfoil", {1449,1447,1448,1423}},
    },
}

local function recommendedZone(state, choices, profession)
    local current = ns.OutdoorZoneForData and ns.OutdoorZoneForData(state, zones) or state.mapID
    current = cityExit[current] or current
    local continent = zones[current] and zones[current][3]
    local level = tonumber(state.level) or 0
    local faction = ns.AdvisorFaction and ns.AdvisorFaction(state) or state.faction
    local best, bestCost
    for _, id in ipairs(choices) do
        local zone = zones[id]
        -- Darkshore is the first mining stop reached from Teldrassil. The
        -- mainland starter routes are overseas, even at a lower suggested level.
        if current == 1438 and id == 1439 and level < 10 and faction == "Alliance" and profession == "Mining" then
            return zone
        end
        -- Prefer reachable zones, then the current zone, then the current continent.
        local cost = math.max(0, zone[2] - level) * 10
        if current ~= id then cost = cost + 2 end
        if nextZone[current] == id then cost = cost - 1 end
        if current ~= id and faction and zone[4] ~= faction then cost = cost + 1 end
        if continent and zone[3] ~= continent then cost = cost + 1 end
        if (not zone[4] or faction == zone[4]) and (not bestCost or cost < bestCost) then
            best, bestCost = zone, cost
        end
    end
    return best
end

-- Maximum skinnable level is ten at the start, grows by one per ten ranks
-- through level 20, then by one per five ranks. The 100/105 boundary matters.
local skinZones = {
    {10, {1411,1412,1420,1429,1426,1438}}, {20, {1413,1421,1436,1432,1439,1431}},
    {25, {1413,1424,1440,1431,1437}}, {30, {1441,1424,1440,1431,1437}}, {33, {1441,1417,1434}},
    {40, {1434,1417,1443}}, {44, {1444,1434,1446}},
    {48, {1444,1446,1425}}, {52, {1449,1419,1448}},
    {55, {1449,1448,1419}}, {60, {1452,1423}},
}
local function skinningStep(state, rank, effective, cap)
    local maximum = math.min(60, effective < 100 and (10 + math.floor(effective / 10)) or math.floor(effective / 5))
    local playerLevel = tonumber(state.level) or 0
    -- At entry rank, even starter beasts qualify. Otherwise stay near the top
    -- of the skinnable range so the suggested beasts can still give skill-ups.
    local high = maximum
    if playerLevel > 0 and (rank < 10 or playerLevel >= maximum - 2) then
        high = math.min(maximum, playerLevel)
    end
    local low = math.max(1, high - 2)
    local choices
    for _, band in ipairs(skinZones) do
        if high <= band[1] then choices = band[2]; break end
    end
    local zone = recommendedZone(state, choices)
    local target = math.min(cap, (math.floor(rank / 25) + 1) * 25)
    local levels = low == high and tostring(high) or (low .. "–" .. high)
    if not zone then return ("Skin fully looted level %s beasts towards Skinning %d."):format(levels,target) end
    local text = ("Skin fully looted level %s beasts in %s towards Skinning %d."):format(levels, zone[1], target)
    if playerLevel > 0 and (high > playerLevel or zone[2] > playerLevel) then
        text = text .. (" Bring a group or return around character level %d."):format(math.max(high, zone[2]))
    end
    return text
end

function ns.GatheringNext(state, prof, skill)
    if prof ~= "Skinning" and not routes[prof] then return end
    local rank = tonumber(skill and skill.rank)
    if not rank or rank < 1 then return end
    local cap = math.min(300, tonumber(skill.cap) or 300)
    if rank >= cap then return end
    local bonus = (tonumber(skill.modifier) or 0) + (tonumber(skill.temp) or 0)
    local effective = math.max(1, rank + bonus)
    if prof == "Skinning" then return skinningStep(state, rank, effective, cap) end
    local bands = routes[prof]
    for i = #bands, 1, -1 do
        local band = bands[i]
        if effective >= band[1] then
            local zone = recommendedZone(state, band[3], prof)
            local target = bands[i + 1] and math.min(cap, bands[i + 1][1] - bonus) or cap
            local text = ("%s%s to %s %d."):format(band[2], zone and " in "..zone[1] or "", prof, target)
            if band[4] and effective >= band[4] then text = text .. " Take " .. band[5] .. " too." end
            if rank < band[1] then text = text .. " Keep your skill bonus active." end
            local level = tonumber(state.level) or 0
            if level > 0 and zone and level < zone[2] then
                text = text .. (" Bring an escort or return around character level %d."):format(zone[2])
            end
            return text
        end
    end
end
