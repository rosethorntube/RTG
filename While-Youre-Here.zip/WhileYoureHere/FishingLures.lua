local _, ns = ...

-- Held consumables, strongest first. Base Fishing is used for the item
-- requirement. Sources: wowhead.com/forever/item={id} and
-- zephras.com/forever/enUS/enchantment/{enchant}/.
local lures = {
    {item=6533,   rank=100, gain=100, enchant=266,  name="Aquadynamic Fish Attractor"},
    {item=6532,   rank=100, gain=75,  enchant=265,  name="Bright Baubles"},
    {item=291005, rank=50,  gain=60,  enchant=8773, name="Camper's Lure"},
    {item=6530,   rank=50,  gain=50,  enchant=264,  name="Nightcrawlers"},
    {item=6529,   rank=1,   gain=25,  enchant=263,  name="Shiny Bauble"},
}
local gainByEnchant = {}
for _, lure in ipairs(lures) do gainByEnchant[lure.enchant] = lure.gain end

local function currentLure(skill)
    local temp, modifier = skill.temp or 0, skill.modifier or 0
    local getEnchant = C_PaperDollInfo and C_PaperDollInfo.GetTemporaryEnchantmentInfo
    if getEnchant then
        local ok, info = pcall(getEnchant, INVSLOT_MAINHAND or 16)
        if not ok or (issecretvalue and issecretvalue(info)) then return end
        if info then
            local id = info.enchantID
            if issecretvalue and issecretvalue(id) then return end
            local gain = gainByEnchant[id]
            -- If the skill and weapon reads disagree, wait for the next scan.
            if gain and gain <= temp + modifier then return gain end
            return
        end
        if temp == 0 then return 0 end
    elseif temp == 0 and modifier == 0 then
        return 0
    end
end

-- The first result is the *additional* skill over the current effective rank.
-- Unrecognised enchants or ambiguous temporary bonuses suppress projections.
function ns.FishingLureGain(state)
    local skill = state and state.skills and state.skills.Fishing
    if not (skill and skill.rank and state.bags) then return end
    for _, lure in ipairs(lures) do
        if skill.rank >= lure.rank and (state.bags[lure.item] or 0) > 0 then
            local active = currentLure(skill)
            if active and lure.gain > active then return lure.gain - active, lure.name end
            return
        end
    end
end
