local _, ns = ...

-- Raw fish ID -> minimum character level to eat the cooked dish, and its
-- damage-food category. Fishing-skill foods have no damage category.
-- Verified against https://foreverdb.net/item/{outputItem} for each cooked
-- output in Data.lua. Foods with no level restriction are usable at level 1.
local foods = {
    [6291]  = {1,  "attack"}, -- Brilliant Smallfish
    [6303]  = {1,  "attack"}, -- Slitherskin Mackerel
    [6289]  = {5,  "attack"}, -- Longjaw Mud Snapper
    [6361]  = {5,  "spell"},  -- Rainbow Fin Albacore
    [21071] = {10, "spell"},  -- Smoked Sagefish
    [6308]  = {15},           -- Bristle Whisker Catfish
    [6362]  = {25},           -- Rockscale Cod
    [8365]  = {25, "attack"}, -- Mithril Head Trout
    [21153] = {30, "spell"},  -- Sagefish Delight
    [13754] = {35, "attack"}, -- Cooked Glossy Mightfish
    [13758] = {35},           -- Filet of Redgill
    [4603]  = {35, "spell"},  -- Spotted Yellowtail
    [13759] = {35, "spell"},  -- Nightfin Soup
    [13760] = {35, "attack"}, -- Poached Sunscale Salmon
    [13889] = {45, "spell"},  -- Baked Salmon
    [13893] = {45, "attack"}, -- Mightfish Steak
}

function ns.FishingFoodType(rawItemID)
    local food = foods[rawItemID]
    return food and food[2]
end

function ns.FishingFoodLevel(rawItemID)
    local food = foods[rawItemID]
    return food and food[1]
end

-- Tree order matches the Forever talent window, independent of client locale.
-- https://timesaver.gg/tools/wow-forever/talent-calculator
local trees = {
    WARRIOR = {{"Arms", "melee", "attack"}, {"Fury", "melee", "attack"}, {"Protection", "tank", "attack"}},
    HUNTER = {{"Beast Mastery", "ranged", "attack"}, {"Marksmanship", "ranged", "attack"}, {"Survival", "melee", "attack"}},
    ROGUE = {{"Assassination", "melee", "attack"}, {"Combat", "melee", "attack"}, {"Subtlety", "melee", "attack"}},
    MAGE = {{"Arcane", "caster", "spell"}, {"Fire", "caster", "spell"}, {"Frost", "caster", "spell"}},
    WARLOCK = {{"Affliction", "caster", "spell"}, {"Demonology", "caster", "spell"}, {"Destruction", "caster", "spell"}},
    DRUID = {{"Balance", "caster", "spell"}, {"Feral", "melee", "attack"}, {"Restoration", "healer", "healing"}},
    SHAMAN = {{"Elemental", "caster", "spell"}, {"Enhancement", "melee", "attack"}, {"Restoration", "healer", "healing"}},
    PALADIN = {{"Holy", "healer", "healing"}, {"Protection", "tank", "attack"}, {"Retribution", "melee", "attack"}},
    PRIEST = {{"Discipline", "healer", "healing"}, {"Holy", "healer", "healing"}, {"Shadow", "caster", "spell"}},
}

-- Keep one choice per distinct food use, even when several trees share it.
local alternatives = {
    DRUID = {{label="Feral", focus="attack"}, {label="Restoration", focus="healing"}, {label="Balance", focus="spell"}},
    SHAMAN = {{label="Enhancement", focus="attack"}, {label="Restoration", focus="healing"}, {label="Elemental", focus="spell"}},
    PALADIN = {{label="Protection / Retribution", focus="attack"}, {label="Holy", focus="healing"}},
    PRIEST = {{label="Shadow", focus="spell"}, {label="Discipline / Holy", focus="healing"}},
}

local function activeCombatConfig()
    local specs = C_SpecializationInfo
    if specs and specs.GetActiveSpecGroup and specs.GetCombatConfigIDForSpecGroup then
        local group = specs.GetActiveSpecGroup()
        return group and specs.GetCombatConfigIDForSpecGroup(group)
    end
    return C_ClassTalents and C_ClassTalents.GetActiveConfigID and C_ClassTalents.GetActiveConfigID()
end

-- The class-wide Forever spec ID cannot identify a tree. Read the three
-- displayed groups in the active combat config, never the Legacy tree.
-- https://github.com/xIGBClutchIx/ForeverPlusPlus/blob/main/docs/forever-api.md
local function activeTreePoints()
    local traits = C_Traits
    if traits and traits.GetConfigInfo and traits.GetGroupDisplayInfoByTreeID and traits.GetGroupCurrencyInfo then
        local config = activeCombatConfig()
        if not config or (traits.ConfigHasStagedChanges and traits.ConfigHasStagedChanges(config)) then return end
        local info = traits.GetConfigInfo(config)
        if not (info and info.treeIDs and #info.treeIDs == 1) then return end
        local groups = traits.GetGroupDisplayInfoByTreeID(info.treeIDs[1])
        if not groups or #groups ~= 3 then return end

        local sorted = {groups[1], groups[2], groups[3]}
        table.sort(sorted, function(a, b) return a.orderIndex < b.orderIndex end)
        local ids, tabForID = {}, {}
        for i, group in ipairs(sorted) do
            if tabForID[group.groupID] or (i > 1 and group.orderIndex == sorted[i - 1].orderIndex) then return end
            ids[i], tabForID[group.groupID] = group.groupID, i
        end

        local rows = traits.GetGroupCurrencyInfo(config, ids)
        if not rows then return end
        local points = {0, 0, 0}
        for _, row in ipairs(rows) do
            local tab = tabForID[row.traitNodeGroupID]
            local currency = row.currencyInfos and row.currencyInfos[1]
            if not (tab and currency and #row.currencyInfos == 1 and type(currency.spent) == "number"
                    and currency.spent >= 0) then return end
            points[tab] = currency.spent
            tabForID[row.traitNodeGroupID] = nil -- reject duplicate rows
        end
        return points
    end

    -- Older clients use either of two signatures. Never inspect another
    -- player, a pet or an inactive dual-spec group.
    if not (GetNumTalentTabs and GetTalentTabInfo and GetNumTalentTabs() == 3) then return end
    local group = GetActiveTalentGroup and GetActiveTalentGroup()
    if GetActiveTalentGroup and not group then return end
    local points = {}
    for tab = 1, 3 do
        local first, second, third, _, fifth
        if group then
            first, second, third, _, fifth = GetTalentTabInfo(tab, false, false, group)
        else
            first, second, third, _, fifth = GetTalentTabInfo(tab)
        end
        local spent
        if type(first) == "string" then spent = third
        elseif type(first) == "number" and type(second) == "string" then spent = fifth end
        if type(spent) ~= "number" or spent < 0 then return end
        points[tab] = spent
    end
    return points
end

local function readBuildProfile(state)
    local class = state and state.class
    local profile = {class=class}
    local list = trees[class]
    if not list then return profile end
    local points
    if not UnitClass or select(2, UnitClass("player")) == class then
        local ok, result = pcall(activeTreePoints)
        if ok then points = result end
    end
    local total = points and (points[1] + points[2] + points[3]) or 0
    if total == 0 then
        -- Class-wide defaults only. All Warriors use attack food, while an
        -- unspent Druid build does not identify a food preference.
        local first = list[1]
        if first[2] == list[2][2] and first[2] == list[3][2] then profile.role = first[2] end
        if first[3] == list[2][3] and first[3] == list[3][3] then profile.food = first[3] end
        return profile
    end
    -- A lead such as 8/7/6 is too slight to identify a main tree. Points
    -- shared across trees may still identify a role (e.g. Holy/Discipline).
    local byRole, byFood = {}, {}
    for i, tree in ipairs(list) do
        local spec, role, food = tree[1], tree[2], tree[3]
        local spent = points[i]
        byRole[role] = (byRole[role] or 0) + spent
        byFood[food] = (byFood[food] or 0) + spent
        if spent > total / 2 then profile.spec = spec end
        if byRole[role] > total / 2 then profile.role = role end
        if byFood[food] > total / 2 then profile.food = food end
    end
    return profile
end

-- Each live Collect builds a fresh character snapshot. Capture the active
-- talents once for all profession, recipe and fishing rows in that snapshot.
function ns.RefreshProfessionBuildProfile(state)
    local profile = readBuildProfile(state)
    if state and state == ns.state then state.professionBuildProfile = profile end
    return profile
end

function ns.ProfessionBuildProfile(state)
    if state and state == ns.state and state.professionBuildProfile then
        return state.professionBuildProfile
    end
    return readBuildProfile(state)
end

function ns.FishingFoodFocus(state)
    return ns.ProfessionBuildProfile(state).food
end

function ns.HybridFoodAlternatives(state)
    local choices = alternatives[state and state.class]
    local result = {}
    if not choices then return result end
    local primary = ns.FishingFoodFocus(state)
    local record = ns.CurrentRecord and ns.CurrentRecord()
    local start = 1
    if record and record.altFoodFocus ~= primary then
        for i, choice in ipairs(choices) do
            if choice.focus == record.altFoodFocus then start = i; break end
        end
    end
    for offset = 0, #choices - 1 do
        local choice = choices[(start - 1 + offset) % #choices + 1]
        if choice.focus ~= primary then result[#result + 1] = choice end
    end
    return result
end

function ns.CycleHybridFood(state)
    local record = ns.CurrentRecord and ns.CurrentRecord()
    if not record then return end
    local choices = ns.HybridFoodAlternatives(state)
    if not choices[2] then return end
    record.altFoodFocus = choices[2].focus
    if ns.RequestRefresh then ns.RequestRefresh() end
    return choices[2]
end
