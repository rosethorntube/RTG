local _, ns = ...

local cities = {[1454]="Horde", [1456]="Horde", [1458]="Horde", [1453]="Alliance", [1455]="Alliance", [1457]="Alliance"}
local mailStops = {["Booty Bay"]="Both",["Ratchet"]="Both",["The Crossroads"]="Horde",["Camp Mojache"]="Horde",["Gadgetzan"]="Both"}
local mailboxOpen=false
if CreateFrame then
    local mailbox=CreateFrame("Frame")
    mailbox:RegisterEvent("MAIL_SHOW")
    mailbox:RegisterEvent("MAIL_CLOSED")
    mailbox:SetScript("OnEvent",function(_,event)
        mailboxOpen=event=="MAIL_SHOW"
        if ns.RequestRefresh then ns.RequestRefresh() end
    end)
end
local function homeCity(s)
    return s.faction and cities[s.mapID]==s.faction
end
local function age(row, name, state)
    if row.key == state.key and state.skills[name] then return "Current skill." end
    local stamp = (row.skillSeen and row.skillSeen[name]) or row.skillsSeen or row.seen
    if type(stamp) == "number" and stamp > 0 and date then
        return "Last recorded "..date("%d %b %Y %H:%M",stamp).."."
    end
    return "The saved character record has no observation date."
end

local function rankAdvice(s,add,vendors)
    -- Fishing and Cooking have dedicated, location-aware rank cards.
    for name,skill in pairs(s.skills) do
        local def=ns.ProfessionDefinitions[name]
        local bookOffered = name=="First Aid" and skill.cap==150 and vendors and vendors[16084]
        if def and not bookOffered and name~="Fishing" and name~="Cooking" and skill.cap<300 and skill.rank>=skill.cap-5 then
            local levelNeeded = def.kind=="Crafting" and ({[75]=10,[150]=20,[225]=35})[skill.cap]
            local eligible = not levelNeeded or s.level>=levelNeeded
            if name=="First Aid" and skill.cap==225 then eligible=s.level>=35 and skill.rank>=225 end
            local body=ns.nextProfessionRank(name,skill.rank,skill.cap,s.level,s.faction).."."
            local shop
            if name=="First Aid" and skill.cap==150 then
                body, shop = ns.FirstAidBookInstruction(s, 16084, "Expert First Aid - Under Wraps", "missing")
            end
            if not eligible and levelNeeded then body=body.." Reach level "..levelNeeded.." before training."
            elseif def.kind~="Secondary" and homeCity(s) then
                body=body.." Ask a city guard for the "..name.." trainer. The highest rank may need a specialist."
            end
            add(name.." "..skill.rank.."/"..skill.cap,body,37+(skill.cap-skill.rank)/100,
                "train-near:"..name..":"..skill.cap,shop,eligible and (homeCity(s) or skill.rank==skill.cap))
        end
    end
end

local uses={
    {"Ore",{"Blacksmithing","Engineering"}}, {"Leather",{"Leatherworking"}},
    {"Cloth",{"Tailoring","First Aid"}}, {"Herbs",{"Alchemy"}},
    {"Enchanting materials",{"Enchanting"}}, {"BoE greens",{"Enchanting"}},
}
local oreIDs={[2770]=true,[2771]=true,[2772]=true,[2775]=true,[2776]=true,[3858]=true,
    [7911]=true,[10620]=true}
local itemNames={[2770]="Copper Ore",[2771]="Tin Ore",[2772]="Iron Ore",[2840]="Copper Bar",
    [2318]="Light Leather",[2319]="Medium Leather",[4234]="Heavy Leather",[4304]="Thick Leather",
    [8170]="Rugged Leather",[2589]="Linen Cloth",[2592]="Wool Cloth",[4306]="Silk Cloth",
    [4338]="Mageweave Cloth",[14047]="Runecloth",[2447]="Peacebloom",[765]="Silverleaf",[10940]="Strange Dust"}
local function itemLabel(id)
    local lookup=(C_Item and C_Item.GetItemNameByID) or GetItemInfo
    local name=lookup and lookup(id)
    return type(name)=="string" and name or itemNames[id] or ("item "..id)
end

local function handoffs(s,add,rows,focus)
    local stop=mailStops[s.subzone]
    if not s.realm or not s.faction or not (mailboxOpen or homeCity(s) or stop=="Both" or stop==s.faction) then return end
    local me=ns.CurrentRecord()
    if not me or me.bagMaterials~=s.bags then return end
    local held=focus and focus.held[s.key.."|bag"] or {}
    if focus and focus.owner.key~=s.key and next(held) then
        local send={}
        for id,n in pairs(held) do send[#send+1]=n.." "..(ns.EfficiencyMaterialName(id) or itemLabel(id)) end
        table.sort(send)
        add("Mail to "..focus.owner.name,table.concat(send,", ")..". Assigned to their "..focus.prof.." "..focus.goal.." goal.",
            31,"craft-mail:"..focus.owner.key..":"..focus.prof,nil,false)
    end
    for _,group in ipairs(uses) do
        local kind,profs=group[1],group[2]
        local tally=s.bags
        if kind=="BoE greens" then tally=me.bagGreens end
        local count,id=0,nil
        for material,total in pairs(tally or {}) do
            local n=total-(held[material] or 0)
            if n>0 and (kind=="BoE greens" or ns.materialKind[material]==kind)
                and (n>count or (n==count and material<id)) then id,count=material,n end
        end
        if id then
            local options,own={},false
            for _,prof in ipairs(profs) do
                if kind=="Cloth" and prof=="First Aid" and #options>0 then break end
                if s.skills[prof] and s.skills[prof].rank<300 then own=true end
                for _,r in ipairs(rows) do
                    local skill=r.skills and r.skills[prof]
                    if r.key~=s.key and ns.CanShareCraftStock(s,r)
                        and skill and skill.rank<300 then
                        options[#options+1]=r.name.." ("..prof.." "..skill.rank.."). "..age(r,prof,s)
                    end
                end
            end
            if #options>0 and not own then
                local item=itemLabel(id)
                local body="You have "..count.." x "..item.." in your bags. "..table.concat(options," ")..
                    " Check the recipient's next recipe before sending."
                if oreIDs[id] then body=body.." Smelt ore into bars if the recipe calls for bars." end
                if kind=="BoE greens" then body=body.." Compare the gear's value with disenchanting it." end
                add("Mail option - "..item,body,47,"profession-mail:"..kind..":"..id,nil,false)
            end
        end
    end
end

function ns.AddProfessionAdvice(s,add,tab,materialAdd,vendors)
    if not s or not s.skills or (tab~="now" and tab~="alts") then return end
    local rows=ns.GetRosterRows()
    local focus
    if ns.FeatureEnabled("professions") then
        focus=ns.AddEfficiencyLP(s,add,tab,rows)
        if tab=="now" then rankAdvice(s,add,vendors) end
    end
    if tab=="now" and ns.FeatureEnabled("materials") then
        if not ns.FeatureEnabled("professions") and ns.DB().settings.efficiencyGoals then
            local _,_,reserved=ns.EfficiencyLPPlans(s,rows)
            focus=reserved
        end
        handoffs(s,materialAdd or add,rows,focus)
    end
end
