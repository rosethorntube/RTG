local _, ns = ...

-- Horde levelling discoveries. Prices and actual stock come from the merchant.
-- Vendor inventories, NPC and item IDs: https://questing.wiki/wow-forever/professions/
-- Map locations and affiliation: https://outof.games/realms/forever/npcs/vendors/
-- Skill requirements / grey points cross-checked with the Forever 1.60.1.70888
-- client item and recipe records: https://github.com/ExcEssIv3/profit/blob/main/export/recipes.json
-- Expert book requirements: https://bindonforever.com/item/16072, /16083, /16084.
-- Each entry's source links to its own recipe or book.
local stops = {}
ns.RecipeStops = stops

local function vendor(mapID, zone, hub, name, x, y, directions)
    return {mapID=mapID, zone=zone, hub=hub, vendor=name, x=x, y=y, directions=directions}
end

local function add(shop, offer)
    for key, value in pairs(shop) do offer[key]=value end
    offer.source = offer.source or ("https://www.wowhead.com/forever/item=" .. offer.item)
    stops[#stops+1] = offer
end

-- Additional catch-based dishes sold outside the fish route: Grilled Squid,
-- Hot Smoked Bass and Lobster Stew.
local caughtFood = {[13942]=true, [13943]=true, [13947]=true}

local function recipe(shop, profession, item, spell, name, skill, grey, limited)
    local craft = name:match("^[^:]+: (.+)$") or name
    add(shop,{profession=profession,item=item,spell=spell,name=name,craft=craft,skill=skill,grey=grey,limited=limited,fishing=caughtFood[item]})
end

-- Keep the existing fish catalogue as the single source for shared recipes.
-- Include the alternative vendors already recorded for each map.
for rawID, fish in pairs(ns.fish) do
    caughtFood[fish.recipeItem] = true
    local function fishAt(shop)
        local hub = shop.mapID == 1434 and "Booty Bay" or nil
        local v=vendor(shop.mapID,shop.zone,hub,shop.vendor,shop.x,shop.y,shop.directions)
        v.faction=shop.faction
        recipe(v,
            "Cooking",fish.recipeItem,fish.spell,"Recipe: "..fish.recipe,fish.skill,fish.grey)
    end
    fishAt(fish)
    for _, shop in pairs(ns.localFishVendors) do
        if shop.items[rawID] and shop.vendor ~= fish.vendor then fishAt(shop) end
    end
end

local shop

shop = vendor(1443, "Desolace", nil, "Wulan", 0.262, 0.697, "Shadowprey Village, upstairs in the eastern building.")
recipe(shop, "Cooking", 21099, 25704, "Recipe: Smoked Sagefish", 80, 160)
recipe(shop, "Cooking", 17062, 20916, "Recipe: Mithril Head Trout", 175, 255)
recipe(shop, "Cooking", 21219, 25954, "Recipe: Sagefish Delight", 175, 255)

shop = vendor(1443, "Desolace", nil, "Kireena", 0.510, 0.536, "Ghost Walker Post. Look for the tauren trade goods vendor.")
recipe(shop, "Cooking", 12232, 15863, "Recipe: Carrion Surprise", 175, 255)
recipe(shop, "Cooking", 12240, 15910, "Recipe: Heavy Kodo Stew", 200, 280)
recipe(shop, "Tailoring", 7114, 3854, "Pattern: Azure Silk Gloves", 120, 170, true)

shop = vendor(1443, "Desolace", nil, "Muuran", 0.556, 0.565, "Ghost Walker Post. Look for the mace merchant.")
recipe(shop, "Blacksmithing", 10858, 3494, "Plans: Solid Iron Maul", 130, 180, true)

shop = vendor(1443, "Desolace", nil, "Vendor-Tron 1000", 0.603, 0.381, "Northern Gizelton Caravan stop. The vendor appears when the caravan stops.")
recipe(shop, "Alchemy", 5642, 6624, "Recipe: Free Action Potion", 150, 215, true)
recipe(shop, "Alchemy", 6068, 3449, "Recipe: Shadow Oil", 165, 230)
recipe(shop, "Alchemy", 5643, 6618, "Recipe: Great Rage Potion", 175, 235)
recipe(shop, "Cooking", 3735, 3398, "Recipe: Hot Lion Chops", 125, 215)
recipe(shop, "Leatherworking", 14635, 3778, "Pattern: Gem-studded Leather Belt", 160, 200, true)
recipe(shop, "Leatherworking", 7451, 9202, "Pattern: Green Whelp Bracers", 165, 205)

shop = vendor(1443, "Desolace", nil, "Super-Seller 680", 0.405, 0.793, "Southern Gizelton Caravan stop. The vendor appears when the caravan stops.")
recipe(shop, "Cooking", 3734, 3397, "Recipe: Big Bear Steak", 110, 190)
recipe(shop, "Cooking", 12227, 15853, "Recipe: Lean Wolf Steak", 125, 205)
recipe(shop, "Cooking", 12239, 15906, "Recipe: Dragonbreath Chili", 200, 280, true)
recipe(shop, "Engineering", 13308, 3957, "Schematic: Ice Deflector", 155, 195)
recipe(shop, "Engineering", 7561, 9273, "Schematic: Goblin Jumper Cables", 165, 200)
recipe(shop, "Engineering", 13310, 3979, "Schematic: Accurate Scope", 180, 220)
recipe(shop, "Tailoring", 14630, 3857, "Pattern: Enchanter's Cowl", 130, 180)
recipe(shop, "Tailoring", 7087, 8789, "Pattern: Crimson Silk Cloak", 145, 195)

shop = vendor(1417, "Arathi Highlands", nil, "Jun'ha", 0.728, 0.366, "Hammerfall. Look for the tailoring supplies vendor.")
recipe(shop, "Tailoring", 7089, 8786, "Pattern: Azure Silk Cloak", 140, 190, true)

shop = vendor(1417, "Arathi Highlands", nil, "Keena", 0.740, 0.326, "Hammerfall. Visit the trade goods vendor in the Horde settlement.")
recipe(shop, "Cooking", 3682, 3376, "Recipe: Curiously Tasty Omelet", 130, 210)
recipe(shop, "Cooking", 12228, 15855, "Recipe: Roast Raptor", 175, 255)
recipe(shop, "Enchanting", 11163, 13646, "Formula: Enchant Bracer - Lesser Deflection", 170, 230, true)
recipe(shop, "Leatherworking", 5973, 7149, "Pattern: Barbaric Leggings", 145, 185, true)

shop = vendor(1417, "Arathi Highlands", nil, "Tunkk", 0.748, 0.346, "Hammerfall. Look for the leatherworking supplies vendor.")
recipe(shop, "Leatherworking", 13287, 4096, "Pattern: Raptor Hide Harness", 140, 180, true)

shop = vendor(1434, "Stranglethorn Vale", "Booty Bay", "Mazk Snipeshot", 0.285, 0.751, "Booty Bay. Look for the engineering supplies vendor by the docks.")
recipe(shop, "Engineering", 13310, 3979, "Schematic: Accurate Scope", 180, 220, true)
recipe(shop, "Engineering", 18651, 23071, "Schematic: Truesilver Transformer", 260, 280, true)

shop = vendor(1434, "Stranglethorn Vale", "Booty Bay", "Glyx Brewright", 0.280, 0.780, "Booty Bay. Look for the alchemy supplies vendor.")
recipe(shop, "Alchemy", 6056, 7258, "Recipe: Frost Protection Potion", 190, 245, true)
recipe(shop, "Alchemy", 6057, 7259, "Recipe: Nature Protection Potion", 190, 250, true)

shop = vendor(1434, "Stranglethorn Vale", "Booty Bay", "Jutak", 0.275, 0.775, "Booty Bay. Look for the blade merchant.")
recipe(shop, "Blacksmithing", 12162, 3492, "Plans: Hardened Iron Shortsword", 135, 185, true)

shop = vendor(1434, "Stranglethorn Vale", "Booty Bay", "Zarena Cromwind", 0.283, 0.755, "Booty Bay. Look for the weapon merchant.")
recipe(shop, "Blacksmithing", 12163, 3496, "Plans: Moonsteel Broadsword", 155, 205, true)

shop = vendor(1434, "Stranglethorn Vale", "Booty Bay", "Xizk Goodstitch", 0.287, 0.769, "Booty Bay. Look for the tailoring supplies vendor.")
recipe(shop, "Tailoring", 14630, 3857, "Pattern: Enchanter's Cowl", 130, 180, true)
recipe(shop, "Tailoring", 7087, 8789, "Pattern: Crimson Silk Cloak", 145, 195, true)

shop = vendor(1434, "Stranglethorn Vale", "Booty Bay", "Rikqiz", 0.284, 0.760, "Booty Bay. Look for the leatherworking supplies vendor.")
recipe(shop, "Leatherworking", 14635, 3778, "Pattern: Gem-studded Leather Belt", 160, 200, true)
recipe(shop, "Leatherworking", 18239, 22711, "Pattern: Shadowskin Gloves", 175, 205, true)

shop = vendor(1434, "Stranglethorn Vale", "Booty Bay", "Blixrez Goodstitch", 0.282, 0.775, "Booty Bay. Look for the leatherworking supplies merchant.")
recipe(shop, "Leatherworking", 5788, 6704, "Pattern: Thick Murloc Armor", 145, 185, true)
recipe(shop, "Leatherworking", 5789, 6705, "Pattern: Murloc Scale Bracers", 165, 205, true)

shop = vendor(1434, "Stranglethorn Vale", "Booty Bay", "Kelsey Yance", 0.282, 0.744, "Booty Bay. Walk into the Old Port Authority from the Ratchet ship dock. Stay on the bottom deck and turn left.")
recipe(shop, "Cooking", 6039, 7213, "Recipe: Giant Clam Scorcho", 175, 255)
recipe(shop, "Cooking", 13943, 18242, "Recipe: Hot Smoked Bass", 240, 320)

shop = vendor(1413, "The Barrens", nil, "Hula'mahi", 0.514, 0.302, "The Crossroads. Look for the reagents and herbs vendor.")
recipe(shop, "Alchemy", 6053, 7255, "Recipe: Holy Protection Potion", 100, 170, true)

shop = vendor(1413, "The Barrens", nil, "Tari'qa", 0.516, 0.300, "The Crossroads. Look for the trade goods vendor.")
recipe(shop, "Cooking", 5486, 6416, "Recipe: Strider Stew", 50, 130)
recipe(shop, "Cooking", 5488, 6418, "Recipe: Crispy Lizard Tail", 100, 180)

shop = vendor(1413, "The Barrens", nil, "Wrahk", 0.522, 0.316, "The Crossroads. Look for the tailoring supplies vendor.")
recipe(shop, "Tailoring", 6270, 7630, "Pattern: Blue Linen Vest", 35, 95, true)
recipe(shop, "Tailoring", 6272, 7633, "Pattern: Blue Linen Robe", 45, 105, true)
recipe(shop, "Tailoring", 5772, 6688, "Pattern: Red Woolen Bag", 90, 150, true)

shop = vendor(1413, "The Barrens", nil, "Zargh", 0.526, 0.298, "The Crossroads. Look for the butcher.")
recipe(shop, "Cooking", 3735, 3398, "Recipe: Hot Lion Chops", 125, 215)

shop = vendor(1413, "The Barrens", nil, "Ranik", 0.619, 0.387, "Ratchet. Look for the trade supplies merchant.")
recipe(shop, "Alchemy", 5640, 6617, "Recipe: Rage Potion", 60, 130, true)
recipe(shop, "Tailoring", 6272, 7633, "Pattern: Blue Linen Robe", 45, 105, true)
recipe(shop, "Tailoring", 6275, 7643, "Pattern: Greater Adept's Robe", 90, 150, true)

shop = vendor(1420, "Tirisfal Glades", nil, "Abigail Shiel", 0.610, 0.524, "Brill. Look for the trade goods vendor.")
recipe(shop, "Cooking", 12226, 15935, "Recipe: Crispy Bat Wing", 1, 85)

shop = vendor(1454, "Orgrimmar", nil, "Hagrus", 0.460, 0.457, "Orgrimmar. Look for the reagent vendor in the Cleft of Shadow.")
recipe(shop, "Alchemy", 5640, 6617, "Recipe: Rage Potion", 60, 130, true)
recipe(shop, "Alchemy", 5643, 6618, "Recipe: Great Rage Potion", 175, 235, true)

shop = vendor(1454, "Orgrimmar", nil, "Borya", 0.631, 0.515, "Orgrimmar. Look for the tailoring supplies vendor in the Drag.")
recipe(shop, "Tailoring", 6270, 7630, "Pattern: Blue Linen Vest", 35, 95, true)
recipe(shop, "Tailoring", 6274, 7639, "Pattern: Blue Overalls", 75, 135, true)
recipe(shop, "Tailoring", 5772, 6688, "Pattern: Red Woolen Bag", 90, 150, true)

shop = vendor(1458, "Undercity", nil, "Algernon", 0.517, 0.747, "Undercity. Look for the alchemy supplies vendor in the Apothecarium.")
recipe(shop, "Alchemy", 9301, 11476, "Recipe: Elixir of Shadow Power", 250, 305, true)
recipe(shop, "Alchemy", 13477, 17553, "Recipe: Superior Mana Potion", 260, 315, true)

shop = vendor(1458, "Undercity", nil, "Daniel Bartlett", 0.641, 0.374, "Undercity. Visit the trade supplies vendor in the Trade Quarter.")
recipe(shop, "Enchanting", 16217, 20017, "Formula: Enchant Shield - Greater Stamina", 265, 325, true)

shop = vendor(1421, "Silverpine Forest", nil, "Lilly", 0.430, 0.508, "The Sepulcher. Look for the enchanting supplies vendor.")
recipe(shop, "Enchanting", 6342, 7443, "Formula: Enchant Chest - Minor Intellect", 20, 120, true)
recipe(shop, "Enchanting", 20758, 25124, "Formula: Minor Wizard Oil", 5, 65)
recipe(shop, "Enchanting", 6346, 7776, "Formula: Enchant Chest - Lesser Intellect", 80, 155, true)
recipe(shop, "Enchanting", 20752, 25125, "Formula: Minor Mana Oil", 150, 180)
recipe(shop, "Enchanting", 20753, 25126, "Formula: Lesser Wizard Oil", 200, 230)
recipe(shop, "Tailoring", 22307, 27658, "Pattern: Enchanted Mageweave Pouch", 190, 235)

shop = vendor(1444, "Feralas", nil, "Jangdor Swiftstrider", 0.744, 0.429, "Camp Mojache. Look for the leatherworking supplies vendor.")
recipe(shop, "Leatherworking", 7451, 9202, "Pattern: Green Whelp Bracers", 165, 205, true)
recipe(shop, "Leatherworking", 8385, 10509, "Pattern: Turtle Scale Gloves", 180, 220, true)
recipe(shop, "Leatherworking", 8409, 10516, "Pattern: Nightscape Shoulders", 185, 225, true)
recipe(shop, "Leatherworking", 15734, 19061, "Pattern: Living Shoulders", 245, 285, true)

shop = vendor(1444, "Feralas", nil, "Bronk", 0.761, 0.433, "Camp Mojache. Look for the alchemy supplies vendor.")
recipe(shop, "Alchemy", 6057, 7259, "Recipe: Nature Protection Potion", 190, 250, true)
recipe(shop, "Alchemy", 9302, 11473, "Recipe: Ghost Dye", 245, 300, true)

shop = vendor(1444, "Feralas", nil, "Sheendra Tallgrass", 0.745, 0.427, "Camp Mojache. Look for the trade goods vendor.")
recipe(shop, "Cooking", 12229, 15856, "Recipe: Hot Wolf Ribs", 175, 255)
recipe(shop, "Cooking", 13947, 18245, "Recipe: Lobster Stew", 275, 355)

shop = vendor(1445, "Dustwallow Marsh", nil, "Balai Lok'Wein", 0.365, 0.304, "Brackenwall Village. Look for the potions, scrolls and reagents vendor.")
recipe(shop, "First Aid", 16112, 7929, "Manual: Heavy Silk Bandage", 180, 240)
recipe(shop, "First Aid", 16113, 10840, "Manual: Mageweave Bandage", 210, 270)

shop = vendor(1446, "Tanaris", nil, "Blizrik Buckshot", 0.507, 0.275, "Gadgetzan. Look for the gunsmith.")
recipe(shop, "Engineering", 18650, 23069, "Schematic: EZ-Thro Dynamite II", 200, 220, true)

shop = vendor(1446, "Tanaris", nil, "Alchemist Pestlezugg", 0.509, 0.270, "Gadgetzan. Look for the alchemy supplies vendor.")
recipe(shop, "Alchemy", 6057, 7259, "Recipe: Nature Protection Potion", 190, 250, true)
recipe(shop, "Alchemy", 9303, 11459, "Recipe: Philosopher's Stone", 225, 280)
recipe(shop, "Alchemy", 9304, 11479, "Recipe: Transmute Iron to Gold", 225, 280)
recipe(shop, "Alchemy", 9305, 11480, "Recipe: Transmute Mithril to Truesilver", 225, 280, true)
recipe(shop, "Alchemy", 12958, 17187, "Recipe: Transmute Arcanite", 275, 290)

shop = vendor(1446, "Tanaris", nil, "Vizzklick", 0.510, 0.274, "Gadgetzan. Look for the tailoring supplies vendor.")
recipe(shop, "Tailoring", 7088, 8802, "Pattern: Crimson Silk Robe", 170, 215, true)
recipe(shop, "Tailoring", 21358, 26085, "Pattern: Soul Pouch", 215, 260)

shop = vendor(1446, "Tanaris", nil, "Krinkle Goodsteel", 0.515, 0.288, "Gadgetzan. Look for the blacksmithing supplies vendor.")
recipe(shop, "Blacksmithing", 6047, 3503, "Plans: Golden Scale Coif", 165, 215, true)

shop = vendor(1446, "Tanaris", nil, "Gikkix", 0.666, 0.221, "Steamwheedle Port. Look for the fisherman on the north-east coast.")
recipe(shop, "Cooking", 13942, 18240, "Recipe: Grilled Squid", 240, 320)

shop = vendor(1452, "Winterspring", nil, "Qia", 0.612, 0.372, "Everlook. Look for the trade goods vendor.")
recipe(shop, "Enchanting", 16221, 20026, "Formula: Enchant Chest - Major Stamina", 275, 335, true)
recipe(shop, "Leatherworking", 15740, 19066, "Pattern: Frostsaber Boots", 250, 290, true)
recipe(shop, "Tailoring", 14468, 18405, "Pattern: Runecloth Bag", 215, 260, true)
recipe(shop, "Tailoring", 14481, 18417, "Pattern: Runecloth Gloves", 230, 275, true)
recipe(shop, "Tailoring", 14526, 18560, "Pattern: Mooncloth", 230, 300)

shop = vendor(1452, "Winterspring", nil, "Xizzer Fizzbolt", 0.608, 0.386, "Everlook. Look for the engineering supplies vendor.")
recipe(shop, "Engineering", 18652, 23077, "Schematic: Gyrofreeze Ice Reflector", 260, 300, true)
recipe(shop, "Engineering", 16047, 19795, "Schematic: Thorium Tube", 275, 315, true)
recipe(shop, "Engineering", 16046, 19814, "Schematic: Masterwork Target Dummy", 275, 315, true)
recipe(shop, "Engineering", 18656, 23080, "Schematic: Powerful Seaforium Charge", 275, 295, true)
recipe(shop, "Engineering", 16050, 19815, "Schematic: Delicate Arcanite Converter", 285, 325, true)

shop = vendor(1452, "Winterspring", nil, "Himmik", 0.613, 0.392, "Everlook. Look for the vendor selling food.")
recipe(shop, "Cooking", 16110, 15933, "Recipe: Monster Omelet", 225, 305)

shop = vendor(1450, "Moonglade", nil, "Lorelae Wintersong", 0.482, 0.401, "Nighthaven. Look for the trade supplies vendor.")
recipe(shop, "Enchanting", 16224, 20015, "Formula: Enchant Cloak - Superior Defense", 285, 345, true)
recipe(shop, "Enchanting", 16243, 20051, "Formula: Runed Arcanite Rod", 290, 350, true)
recipe(shop, "Tailoring", 14483, 18419, "Pattern: Felcloth Pants", 230, 275, true)

-- These raise the cap rather than teaching a craft. Lead allows an early buy
-- while passing a distant shop, up to 25 skill points before the reading rank.
ns.ExpertBookShops = {}
local function book(shop, profession, item, name, level)
    ns.ExpertBookShops[item] = shop
    add(shop,{kind="book",profession=profession,item=item,name=name,skill=125,cap=225,lead=25,level=level})
end
book(vendor(1443,"Desolace",nil,"Wulan",.261,.697,"Shadowprey Village, upstairs in the eastern building."),
    "Cooking",16072,"Expert Cookbook")
book(vendor(1445,"Dustwallow Marsh",nil,"Balai Lok'Wein",.365,.304,"Brackenwall Village, at the potions, scrolls and reagents vendor."),
    "First Aid",16084,"Expert First Aid - Under Wraps")
book(vendor(1434,"Stranglethorn Vale","Booty Bay","Old Man Heming",.274,.771,"Booty Bay, on the lower boardwalk. Look for the fishing sign."),
    "Fishing",16083,"Expert Fishing - The Bass and You",20)

-- These Alliance book vendors are also used by the profession training pages.
local function allianceBook(shop,profession,item,name)
    shop.faction="Alliance"
    add(shop,{kind="book",profession=profession,item=item,name=name,skill=125,cap=225,lead=25})
end
allianceBook(vendor(1440,"Ashenvale",nil,"Shandrina",.495,.671,"Silverwind Refuge."),
    "Cooking",16072,"Expert Cookbook")
allianceBook(vendor(1417,"Arathi Highlands",nil,"Deneb Walker",.270,.588,"Stromgarde Keep."),
    "First Aid",16084,"Expert First Aid - Under Wraps")
