local _, ns = ...

local milestones = {150, 225, 300}
local components = {}
local essenceGroups = {
    {10938,10939,"Magic Essence"}, {10998,11082,"Astral Essence"},
    {11134,11135,"Mystic Essence"}, {16202,16203,"Eternal Essence"},
}
local essences = {}
local disenchantMaterials = {
    [10940]="Strange Dust", [11083]="Soul Dust", [11137]="Vision Dust",
    [11176]="Dream Dust", [16204]="Illusion Dust", [14343]="Small Brilliant Shard",
    [14344]="Large Brilliant Shard",
}
-- WoW Forever essence Use tooltips: one greater splits into three lesser.
-- https://www.wowhead.com/forever/item=10939/greater-magic-essence
for _, group in ipairs(essenceGroups) do
    local lesser, greater, label = group[1],group[2],group[3]
    essences[lesser] = {inputs={{id=greater,amount=1}}, outputCount=3}
    essences[greater] = {inputs={{id=lesser,amount=3}}, outputCount=1}
    disenchantMaterials[lesser], disenchantMaterials[greater] = label,label
end

local function copyCounts(source)
    local counts = {}
    for id, amount in pairs(source or {}) do counts[id] = amount end
    return counts
end

local function requirements(profession, recipe)
    local inputs, complete = ns.EfficiencyIngredients(profession, recipe)
    if not complete then return end
    local ordered = {}
    for id, amount in pairs(inputs) do ordered[#ordered+1] = {id=id, amount=amount} end
    table.sort(ordered,function(a,b) return a.id < b.id end)
    return ordered
end

local function nextMilestone(rank)
    for _, goal in ipairs(milestones) do
        if rank < goal then return goal end
    end
end

local function routeFrom(state, profession, rank)
    return function()
        if rank >= 300 then return end
        local recipe, stop = ns.CraftRouteRecipe(profession,rank,state)
        if not recipe or not stop or stop <= rank then return end
        local start = rank
        rank = stop
        return recipe,start
    end
end

local function firstConsumer(state, profession, output, rank)
    for recipe in routeFrom(state,profession,rank) do
        local inputs, complete = ns.EfficiencyIngredients(profession, recipe)
        if complete and inputs[output] then return recipe.name end
    end
end

local function outputUse(state, profession, output, afterRank)
    local own = firstConsumer(state,profession,output,afterRank)
    if own then return own end
    for _, other in ipairs(ns.PanelProfessions) do
        if other ~= profession and ns.CraftNextData[other] then
            local skill = state.skills and state.skills[other]
            local use = firstConsumer(state,other,output,skill and skill.rank or 1)
            if use then return use.." ("..other..")" end
        end
    end
end

function ns.CraftOutputKeepNote(state, profession, recipe, afterRank)
    local output = ns.EfficiencyMaterialID(recipe.name)
    local use = output and outputUse(state,profession,output,afterRank)
    if use then return "Keep for later: "..recipe.name.." for "..use.."." end
end

local function sortedKeys(entries)
    local keys = {}
    for key in pairs(entries) do keys[#keys+1] = key end
    table.sort(keys)
    return keys
end

function ns.EnchantingRetention(state, rank, short)
    local goal = nextMilestone(rank)
    if not goal then return end
    local soon, later = {}, {}
    for recipe, start in routeFrom(state,"Enchanting",rank) do
        local inputs, complete = ns.EfficiencyIngredients("Enchanting",recipe)
        if complete then
            for id in pairs(inputs) do
                local name = disenchantMaterials[id]
                if name then
                    if start < goal then soon[name] = true
                    else later[name] = true end
                end
            end
        end
    end
    for name in pairs(soon) do later[name] = nil end
    local function retention(label, names)
        if next(names) then return label..table.concat(sortedKeys(names),", ").."." end
    end
    local notes = {}
    notes[#notes+1] = retention("Keep to "..goal..": ",soon)
    if not short then notes[#notes+1] = retention("Keep for later: ",later) end
    notes[#notes+1] = "Keep both sizes of needed essences (3 lesser = 1 greater)."
    notes[#notes+1] = "Glimmering and Glowing Shards are spare on this route. Sell only surplus after checking your other needs."
    return table.concat(notes,"\n")
end

local function getComponents(profession)
    if components[profession] then return components[profession] end
    local producers = {}
    for _, recipe in pairs(ns.CraftNextData[profession]) do
        local id = ns.EfficiencyMaterialID(recipe.name)
        local inputs = id and requirements(profession, recipe)
        if inputs and #inputs > 0 then producers[id] = {recipe=recipe, inputs=inputs} end
    end
    if profession == "Enchanting" then
        for id, conversion in pairs(essences) do producers[id] = conversion end
    end
    components[profession] = producers
    return producers
end

local function put(counts, id, newValue, journal)
    if journal then journal[#journal+1] = {counts=counts, id=id, old=counts[id]} end
    counts[id] = newValue
end

local function addCount(counts, id, amount, journal)
    put(counts,id,(counts[id] or 0)+amount,journal)
end

local function takeStock(plan, id, target, journal)
    local held = math.min(target,plan.stock[id] or 0)
    if held > 0 then addCount(plan.stock,id,-held,journal) end
    local withdrawn = math.min(target-held,plan.bank[id] or 0)
    if withdrawn > 0 then
        addCount(plan.bank,id,-withdrawn,journal)
        addCount(plan.collect,id,withdrawn,journal)
    end
    return target-held-withdrawn
end

local function rollback(journal)
    for i = #journal, 1, -1 do
        local entry = journal[i]
        entry.counts[entry.id] = entry.old
    end
end

local function status(plan, recipe)
    local spell = recipe.spell
    local value = plan.status[spell]
    if not value then
        value = ns.NextRecipeStatus(plan.state,spell)
        plan.status[spell] = value
    end
    return value
end

-- A component is made here only from available items and a known recipe, or
-- from a recipe already reached earlier in the same planned route.
local function tryMake(plan, id, rank, journal, active)
    local producer = plan.producers[id]
    if not producer or active[id] then return false end
    local recipe = producer.recipe
    if recipe and (recipe.availableAt > rank or (not plan.previous[recipe.spell] and status(plan,recipe) ~= "known")) then
        return false
    end
    active[id] = true
    for _, input in ipairs(producer.inputs) do
        local remaining = takeStock(plan,input.id,input.amount,journal)
        while remaining > 0 do
            if not tryMake(plan,input.id,rank,journal,active) then
                active[id] = nil
                return false
            end
            remaining = takeStock(plan,input.id,remaining,journal)
        end
    end
    active[id] = nil
    local amount = producer.outputCount or recipe.outputCount or 1
    addCount(plan.stock,id,amount,journal)
    addCount(recipe and plan.prepare or plan.convert,id,amount,journal)
    return true
end

local function fulfill(plan, id, remaining, rank)
    while remaining > 0 do
        local journal = {}
        if not tryMake(plan,id,rank,journal,{}) then
            rollback(journal)
            addCount(plan.buy,id,remaining)
            return
        end
        remaining = takeStock(plan,id,remaining)
    end
end

function ns.BuildMaterialsPlan(state, profession, record)
    local skill = state.skills and state.skills[profession]
    if not skill or not ns.CraftNextData[profession] then return end
    local goal = nextMilestone(skill.rank)
    if not goal then return end

    local plan = {
        state=state, skill=skill, goal=goal, rank=skill.rank, steps={},
        buy={}, collect={}, prepare={}, convert={}, keep={}, check={}, learn={}, previous={}, status={},
        stock=copyCounts(state.bagsScanned and state.bags),
        bank=copyCounts(record and record.bankSeen and record.bankMaterials),
        bankSeen=record and record.bankSeen, producers=getComponents(profession),
    }
    while plan.rank < goal do
        local start = plan.rank
        local recipe, stop = ns.CraftRouteRecipe(profession,start,state)
        if not recipe then break end
        local nextRank = math.min(goal,stop)
        local count = nextRank-start
        if recipe.source == "ability" then
            plan.steps[#plan.steps+1] = start.."–"..nextRank.." · Disenchant spare uncommons"
            plan.disenchant = true
        else
            local inputs = requirements(profession,recipe)
            if not inputs then break end
            local remaining = {}
            -- Reserve all the direct inputs first. A speculative component
            -- should not take stock already needed directly in the same step.
            for i,input in ipairs(inputs) do
                remaining[i] = takeStock(plan,input.id,count*input.amount)
            end
            for i,input in ipairs(inputs) do fulfill(plan,input.id,remaining[i],start) end
            local output = ns.EfficiencyMaterialID(recipe.name)
            if output then
                addCount(plan.stock,output,count*(recipe.outputCount or 1))
                plan.keep[output] = plan.keep[output] or outputUse(state,profession,output,nextRank)
            end
            plan.steps[#plan.steps+1] = start.."–"..nextRank.." · "..recipe.name.." ×"..count
            if not plan.previous[recipe.spell] then
                local learned = status(plan,recipe)
                if learned == "missing" then plan.learn[#plan.learn+1] = recipe.name end
                if learned == "unknown" then plan.check[#plan.check+1] = recipe.name end
                plan.previous[recipe.spell] = true
            end
        end
        plan.rank = nextRank
    end
    -- Include existing crafted components that are still useful on this route.
    for id, producer in pairs(plan.producers) do
        local alreadyOwned = state.bagsScanned and state.bags and (state.bags[id] or 0)>0
        if producer.recipe and (alreadyOwned or plan.collect[id]) and not plan.keep[id] then
            plan.keep[id] = firstConsumer(state,profession,id,skill.rank)
        end
    end
    return plan
end

local function linesFor(counts)
    local names = {}
    for id, amount in pairs(counts) do
        names[#names+1] = {name=ns.EfficiencyMaterialName(id), amount=amount}
    end
    table.sort(names,function(a,b) return a.name < b.name end)
    local lines = {}
    for i, item in ipairs(names) do lines[i] = item.name.." ×"..item.amount end
    return table.concat(lines,"\n")
end

local function conversionLines(counts)
    local lines = {}
    for _, id in ipairs(sortedKeys(counts)) do
        local conversion = essences[id]
        local input, output = conversion.inputs[1],counts[id]
        local used = output/conversion.outputCount*input.amount
        lines[#lines+1] = ns.EfficiencyMaterialName(input.id).." x"..used.." into "..ns.EfficiencyMaterialName(id).." x"..output
    end
    return table.concat(lines,"\n")
end

local function keepLines(keep)
    local lines = {}
    for id, use in pairs(keep) do lines[#lines+1] = ns.EfficiencyMaterialName(id).." for "..use end
    table.sort(lines)
    return table.concat(lines,"\n")
end

local function addPlan(state, add, profession, first, record)
    local skill = state.skills and state.skills[profession]
    local key = "materials-plan:"..profession
    if not skill then
        add(profession,"Learn this profession to estimate what your character needs.",first,key)
        return
    end
    local plan = ns.BuildMaterialsPlan(state,profession,record)
    if not plan then
        add(profession.." · "..skill.rank.."/"..skill.cap,"Skill 300 reached.",first,key)
        return
    end
    local notes = {"Minimum estimate for the Guide route at one craft per skill-up. Yellow and green recipes can take more. Recheck as you level."}
    if not state.bagsScanned then notes[#notes+1] = "Your bags haven’t been read yet. Bag stock is excluded." end
    if plan.disenchant then notes[#notes+1] = "Disenchanting gains and drops are unpredictable and excluded from the item counts." end
    if plan.rank < plan.goal then
        notes[#notes+1] = "Partial estimate through "..plan.rank..". The guide lacks recipe data for the next step."
    end
    add(profession.." · "..skill.rank.." → "..plan.goal,table.concat(notes,"\n"),first,key)

    if skill.cap < plan.goal then
        local trainer = ns.ProfessionTrainingNext(state,profession,{rank=skill.cap,cap=skill.cap})
        add("Training needed",trainer or ("Raise your current skill cap of "..skill.cap.." before reaching "..plan.goal.."."),
            first+1,key..":training")
    end
    if next(plan.collect) then
        local when = date and type(plan.bankSeen)=="number" and date("%d %b",plan.bankSeen)
        local label = when and ("Bank last seen "..when..". Check these stacks before buying.")
            or "Check these stacks in your last recorded bank before buying."
        add("Collect from your bank",linesFor(plan.collect).."\n"..label,first+2,key..":bank")
    end
    if next(plan.prepare) then
        add("Make from stock",linesFor(plan.prepare),first+3,key..":components")
    end
    if next(plan.convert) then
        add("Convert essences from stock",conversionLines(plan.convert),first+3.1,key..":essences")
    end
    if next(plan.buy) then
        add("Gather or buy",linesFor(plan.buy),first+4,key..":buy")
    elseif #plan.steps > 0 and plan.rank == plan.goal and state.bagsScanned then
        local stock = next(plan.collect) and "Your bags and recorded bank" or "Your bags"
        add("Materials covered",stock.." cover this minimum estimate.",first+4,key..":buy")
    end
    if next(plan.keep) then
        add("Keep for later",keepLines(plan.keep),first+4.1,key..":keep")
    end
    if profession == "Enchanting" then
        add("Keep from disenchanting",ns.EnchantingRetention(state,skill.rank),first+4.2,key..":disenchanting")
    end
    if #plan.learn > 0 then
        add("Recipes to learn",table.concat(plan.learn,", ")..".",first+5,key..":learn")
    end
    if #plan.check > 0 then
        add("Check your recipes","Open "..profession.." to verify "..table.concat(plan.check,", ")..".",first+6,key..":check")
    end
    if #plan.steps > 0 then
        add("Crafting route",table.concat(plan.steps,"\n"),first+7,key..":steps")
    end
end

function ns.AddMaterialsPlan(state, add, filter)
    local record = ns.CurrentRecord and ns.CurrentRecord()
    if filter and ns.CraftNextData[filter] then
        addPlan(state,add,filter,1,record)
        return
    end
    if not filter then
        local shown = 0
        for _, profession in ipairs(ns.PanelProfessions) do
            if ns.CraftNextData[profession] and state.skills and state.skills[profession] then
                addPlan(state,add,profession,1+shown*10,record)
                shown = shown+1
            end
        end
        if shown > 0 then return end
    end
    add("Materials Needed","Select Alchemy, Blacksmithing, Enchanting, Engineering, Leatherworking or Tailoring to estimate materials to your next crafting milestone.",1,"materials-plan:welcome")
end
