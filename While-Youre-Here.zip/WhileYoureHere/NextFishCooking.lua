local _, ns = ...

local reagents = {
    [159]="Refreshing Spring Water", [2678]="Mild Spices", [2692]="Hot Spices", [3713]="Soothing Spices",
}
-- Forever item effects and minimum eating levels: zephras.com/forever/enUS/item/{outputItem}/
local meatFood = {
    [769]={level=1, buff="+1 Strength", stat="strength"},
    [3730]={level=5, buff="+3 Strength", stat="strength"},
    [12184]={level=15, buff="+5 Intellect", stat="intellect"},
    [12208]={level=35, buff="+15 Agility", stat="agility"},
    [20424]={level=45, buff="+20 Strength", stat="strength"},
}
-- Additional recipe vendors: forever-tavern.com/items/{itemID}-recipe-.../
local extraShops = {
    [5467]={item=5484,vendor="Wunna Darkmane",hub="Bloodhoof Village",zone="Mulgore",mapID=1412,x=.456,y=.617,faction="Horde"},
    [12208]={item=18046,vendor="Innkeeper Fizzgrimble",hub="Gadgetzan",zone="Tanaris",mapID=1446,x=.525,y=.279},
}
local function enabled(key) return not ns.FeatureEnabled or ns.FeatureEnabled(key) end
local function rawName(recipe) return (recipe.name:gsub("^Raw ", ""):gsub("^Large Raw ", "Large ")) end

-- Keep the next build-food milestone separate from what can skill up right now.
function ns.NextFishFoodUnlock(s, rank, focus)
    focus = focus or ns.FishingFoodFocus(s)
    if not focus or not rank then return end
    local best, bestID
    for id, recipe in pairs(ns.fish) do
        if recipe.skill > rank and ns.FishingFoodType(id) == focus
                and (s.level or 0) >= (ns.FishingFoodLevel(id) or 1)
                and (not best or recipe.skill < best.skill or (recipe.skill == best.skill and id < bestID)) then
            best, bestID = recipe, id
        end
    end
    if best then return ("At Cooking %d, %s gives %s."):format(best.skill,rawName(best),best.buff) end
end

local function source(s, id, recipe)
    local localShop = ns.localFishVendors[s.mapID]
    if localShop and localShop.items[id] and (not localShop.faction or s.faction == localShop.faction) then
        return localShop, recipe.recipeItem
    end
    local shop = extraShops[id]
    if shop and shop.faction and shop.faction ~= s.faction then shop = nil end
    -- RecipeStops describes the Horde route. Shared fish vendors have neutral defaults
    -- where available; avoid treating an opposing capital as a valid alternative.
    if s.faction == "Horde" then
        for _, offer in ipairs(ns.RecipeStops or {}) do
            if offer.spell == recipe.spell then
                if offer.mapID == s.mapID then return offer, offer.item end
                if not shop then shop = offer end
            end
        end
    end
    if recipe.vendor and (not recipe.faction or recipe.faction == s.faction) then shop = recipe end
    return shop, recipe.recipeItem or (shop and shop.item)
end

local function learnRecipe(s, id, r, status, target)
    if status == "known" then return end
    local shop, item = source(s,id,r)
    local held = item and ns.RecipeItemHeld and ns.RecipeItemHeld(s,item)
    if held == "bags" then return "Learn " .. r.recipe .. " from the recipe in your bags." end
    if held == "bank" then return "Collect the " .. r.recipe .. " recipe from your bank." end
    if status == "unknown" then return "Open Cooking to check " .. r.recipe .. "." end
    if id == 5503 then return "Learn Boiled Clams from a Cooking trainer." end
    local text = "Learn the " .. r.recipe .. " recipe."
    if enabled("vendors") then
        if target then
            local zone = ns.DungeonPickupZoneNames and ns.DungeonPickupZoneNames[target.mapID]
            text = ("Buy the %s recipe from %s%s."):format(r.recipe,target.name,zone and (", " .. zone) or "")
        elseif shop then
            text = ("Buy the %s recipe from %s, %s."):format(r.recipe,shop.vendor,shop.hub or shop.zone)
            target = ns.RecipeVendorTarget(shop)
        end
    else
        target = nil
    end
    local market = item and ns.RecipeShoppingHint and ns.RecipeShoppingHint(s,item)
    if market then text = text .. " " .. market end
    return text,target
end

local function foodMatch(s, id, focus)
    if not focus then return 0 end
    local fish = ns.fish[id]
    if fish then
        if ns.FishingFoodType(id) == focus and (s.level or 0) >= (ns.FishingFoodLevel(id) or 1) then return 2, fish.buff end
        return 0
    end
    local food = meatFood[id]
    if not food or (s.level or 0) < food.level then return 0 end
    if food.stat == "intellect" and (focus == "spell" or focus == "healing") then return 1, food.buff end
    if focus == "attack" and (food.stat == "agility" or (food.stat == "strength" and s.class ~= "HUNTER")) then return 1, food.buff end
    return 0
end

local function difficulty(rank, recipe)
    if rank < recipe.yellow then return 3, "orange", recipe.yellow end
    if rank < recipe.green then return 2, "yellow", recipe.green end
    return 1, "green", recipe.grey
end

local function progress(s, skill, recipe, id, allowFishMilestone)
    local _, colour, nextRank = difficulty(skill.rank,recipe)
    local line = ("%s to Cooking %d."):format(colour:sub(1,1):upper() .. colour:sub(2), math.min(nextRank,skill.cap))
    local match, buff = foodMatch(s,id,ns.FishingFoodFocus(s))
    if match > 0 then return line .. " " .. buff .. "." end
    local nextFood = allowFishMilestone and ns.NextFishFoodUnlock(s,skill.rank)
    return nextFood and (line .. " " .. nextFood) or line
end

local function materialsAvailable(bags, id, r)
    local count = math.floor((bags[id] or 0)/(r.mainPerCraft or r.fishPerCraft or 1))
    local main = count
    for ingredient, qty in pairs(r.ingredients or {}) do
        count = math.min(count,math.floor((bags[ingredient] or 0)/qty))
    end
    return count, main
end

-- A green recipe may still use up a cheap, ordinary catch that will soon
-- give no more Cooking points. Never assume a scarce fish is expendable.
local staples = {[6291]=true, [6289]=true, [6303]=true, [6361]=true, [6308]=true}
local function useBeforeGrey(earlier, later)
    if not later or earlier.id == later.id or earlier.recipe.grey >= later.recipe.yellow then return false end
    local value = ns.CatchSaleValue
    local oldPrice, _, oldQuote
    local newPrice, _, newQuote
    if value then
        oldPrice, _, oldQuote = value(earlier.id)
        newPrice, _, newQuote = value(later.id)
    end
    if (oldQuote and oldQuote.ah) or (newQuote and newQuote.ah) then
        -- Green has a lower chance than orange. Spend only a substantially
        -- cheaper ingredient when local AH evidence can distinguish the two.
        return oldQuote and oldQuote.comparable and newQuote and newQuote.comparable
            and oldPrice and newPrice and oldPrice * 3 <= newPrice
    end
    return staples[earlier.id] == true
end

local function recipeChoices(s, skill, allowFish, bagsOnly)
    local best, bestScore, stocked, stockedScore
    local fading = {}
    local bags, focus = s.bags or {}, ns.FishingFoodFocus(s)
    for _, book in ipairs({ns.otherCooking, ns.fish}) do
        for id, r in pairs(book) do
            if (not bagsOnly or (bags[id] or 0) > 0) and skill.rank >= r.skill and not ns.RecipeOutlevelled(skill,r) then
                local count, main = materialsAvailable(bags,id,r)
                if book ~= ns.fish or allowFish or main > 0 then
                    local status = ns.NextRecipeStatus(s,r.spell)
                    local match = foodMatch(s,id,focus)
                    local diff = difficulty(skill.rank,r)
                    local score = diff * 6 + match * 10 + math.min(count,5) - (r.station and 1 or 0)
                    local c = {id=id, recipe=r, count=count, main=main, status=status}
                    local stationReady = not r.station or (ns.CookingStationReady and ns.CookingStationReady(r))
                    local heldBook = r.recipeItem and (bags[r.recipeItem] or 0) > 0
                    if (status == "known" or heldBook and count > 0) and main > 0 and stationReady and (not bagsOnly or count > 0) then
                        c.readBook = status ~= "known"
                        local cooked = bags[r.outputItem] or 0
                        local ready = diff * 24 + match * (cooked > 0 and 1 or 4) + math.min(count, 5) + (count > 0 and 100 or 0)
                        if c.readBook then ready = ready - 12 end
                        if not stocked or ready > stockedScore or (ready == stockedScore and id < stocked.id) then
                            stocked, stockedScore = c, ready
                        end
                        if status == "known" and count > 0 and diff == 1 and r.grey - skill.rank <= 5 and r.grey < skill.cap
                                and not r.station and not next(r.ingredients or {}) and (r.mainPerCraft or r.fishPerCraft or 1) == 1 then
                            fading[#fading+1] = c
                        end
                    end
                    if not bagsOnly then
                        local shop, item = source(s,id,r)
                        local held = item and ns.RecipeItemHeld and ns.RecipeItemHeld(s,item)
                        if status == "known" then score = score + 100
                        elseif held then score = score + 80
                        elseif status == "missing" then score = score + (shop and enabled("vendors") and 30 or 0) end
                        if main > 0 then score = score + 45 end
                        if shop and shop.mapID == s.mapID and status == "missing" then score = score + 6 end
                        if book == ns.otherCooking and not s.skills.Fishing then score = score + 5 end
                        if not stationReady then score = score - 180 end
                        if not best or score > bestScore or (score == bestScore and id < best.id) then best,bestScore = c,score end
                    end
                end
            end
        end
    end
    if stocked and not stocked.readBook and stocked.count > 0 and skill.rank < stocked.recipe.yellow then
        table.sort(fading,function(a,b)
            if a.recipe.grey ~= b.recipe.grey then return a.recipe.grey < b.recipe.grey end
            return a.id < b.id
        end)
        for _, earlier in ipairs(fading) do
            if useBeforeGrey(earlier,stocked) then
                earlier.followup = stocked
                return earlier,best
            end
        end
    end
    return stocked,best
end

local function readyLine(s, skill, choice, tea)
    if tea and tea.status == "known" and (tea.ready or 0) > 0 and not tea.isGrey then
        local limit = math.min(skill.cap, select(3,difficulty(skill.rank,tea)))
        return ("Brew %s up to %d times with the supplies in your bags. %s."):format(
            tea.name,math.min(tea.ready,limit-skill.rank),tea.buff)
    end
    if not choice or choice.count <= 0 then return end
    local r = choice.recipe
    local limit = math.min(skill.cap, select(3,difficulty(skill.rank,r)))
    local count = math.min(choice.count, limit-skill.rank)
    if choice.followup then
        return ("Cook up to %d x %s from your bags first. Stop at Cooking %d or when you run out. Save %s for afterwards."):format(
            count,r.recipe,limit,choice.followup.recipe.name)
    end
    if choice.readBook then
        if choice.status == "unknown" then
            return ("Check %s in Cooking. You have the recipe and materials for %d craft%s."):format(r.recipe,count,count==1 and "" or "s")
        end
        return ("Read the %s recipe in your bags, then cook up to %d. %s"):format(r.recipe,count,progress(s,skill,r,choice.id,false))
    end
    return ("Cook up to %d x %s from your bags%s. %s"):format(count,r.recipe,
        r.station and (" at an "..r.station) or "",progress(s,skill,r,choice.id,enabled("fishing") and s.skills.Fishing ~= nil))
end

function ns.ReadyCookingStep(s)
    local skill = s.skills and s.skills.Cooking
    if not skill or skill.rank >= skill.cap or not s.bags then return end
    local choice = recipeChoices(s,skill,enabled("fishing"),true)
    local tea = ns.FishingFoodFocus(s) == "healing" and ns.HealingFoodOption and ns.HealingFoodOption(s,skill.rank)
    return readyLine(s,skill,choice,tea)
end

-- For a food goal a cooked serving is usable regardless of Cooking skill or
-- who made it. Only raw ingredients need a known recipe and its workstation.
function ns.ReadyBuildFood(s, focus)
    focus = focus or ns.FishingFoodFocus(s)
    if not focus or not s.bags then return end
    local bags, skill, best = s.bags, s.skills and s.skills.Cooking
    local function consider(id,name,buff,match,eatLevel,cooked,craftable,grey)
        if cooked == 0 and craftable == 0 then return end
        local packed = cooked > 0 and 1 or 0
        local score = packed*100000 + match*10000 + eatLevel*100 + (tonumber(buff:match("%d+")) or 0)
        if not best or score > best.score or (score == best.score and id < best.id) then
            best = {id=id, score=score, name=name, buff=buff, cooked=cooked, craftable=craftable, grey=grey}
        end
    end
    for _,book in ipairs({ns.fish,ns.otherCooking}) do
        for id,r in pairs(book) do
            if (bags[r.outputItem] or 0)>0 or (bags[id] or 0)>0 then
                local match,buff = foodMatch(s,id,focus)
                if match > 0 then
                    local level = book == ns.fish and (ns.FishingFoodLevel(id) or 1) or meatFood[id].level
                    local ready = 0
                    if skill and skill.rank >= r.skill and ns.NextRecipeStatus(s,r.spell) == "known"
                            and (not r.station or (ns.CookingStationReady and ns.CookingStationReady(r))) then
                        ready = materialsAvailable(bags,id,r)
                    end
                    consider(id,r.recipe,buff,match,level or 1,bags[r.outputItem] or 0,ready,ns.RecipeOutlevelled(skill,r))
                end
            end
        end
    end
    if focus == "healing" then
        for _,tea in ipairs(ns.HealingTeas or {}) do
            if (s.level or 0) >= tea.level then
                local ready = 0
                if skill and skill.rank >= tea.skill and ns.NextRecipeStatus(s,tea.spell) == "known" then
                    ready = math.min(bags[tea.drink] or 0,math.floor((bags[tea.herb] or 0)/2))
                end
                consider(tea.itemID,tea.name,"+"..tea.power.." Healing Power",2,tea.level,bags[tea.itemID] or 0,ready,ns.RecipeOutlevelled(skill,tea))
            end
        end
    end
    if not best then return end
    if best.cooked > 0 then
        return ("%d x %s in your bags gives %s."):format(best.cooked,best.name,best.buff),best
    end
    return ("Your bags have ingredients for %d x %s (%s).%s"):format(best.craftable,best.name,best.buff,
        best.grey and " This grey recipe gives no Cooking skill-ups." or ""),best
end

local function supply(s, choice, full)
    local r = choice.recipe
    local parts = {}
    if full or choice.main == 0 then parts[1] = ("%d %s"):format(r.mainPerCraft or r.fishPerCraft or 1,r.name) end
    for id,n in pairs(r.ingredients or {}) do
        local missing = full and n or n - ((s.bags or {})[id] or 0)
        if missing > 0 then parts[#parts+1] = missing .. " " .. (reagents[id] or ("item "..id)) end
    end
    table.sort(parts)
    return table.concat(parts," and ")
end

-- Only verified, reachable water and dishes this character can eat. Grey recipes stay
-- out of levelling recommendations. Match the player's current server-hour window.
local function hybridCatch(s, where, focus)
    local cooking, fishing = s.skills.Cooking,s.skills.Fishing
    if not (cooking and fishing and enabled("fishing") and enabled("fishingLocation")) then return end
    local best, bestScore
    local currentMap = s.mapID
    local localSpot = where and where.localZone and where.spot
    if localSpot then currentMap = localSpot.mapID end
    local effective = fishing.rank + (fishing.temp or 0) + (fishing.modifier or 0)
    for _, spot in ipairs(ns.FishingWaters) do
        if (not spot.faction or spot.faction == s.faction) and effective >= spot.minimum
                and (spot.mapID == currentMap or (s.level or 0) >= spot.level) then
            for _, id in ipairs(spot.fish) do
                local r = ns.fish[id]
                if r and ns.FishBitesNow(id,s.hour) and ns.FishingFoodType(id) == focus and cooking.rank >= r.skill
                        and (not r.station or (ns.CookingStationReady and ns.CookingStationReady(r)))
                        and (s.level or 0) >= (ns.FishingFoodLevel(id) or 1) then
                    local grey = ns.RecipeOutlevelled(cooking,r)
                    local status = ns.NextRecipeStatus(s,r.spell)
                    local known = status == "known"
                    local score = difficulty(cooking.rank,r)*4 + (known and 11 or 0)
                        + (spot.mapID == currentMap and 18 or 0) + (effective >= spot.noEscape and 3 or 0)
                        + ((s.bags and s.bags[id] or 0) > 0 and 7 or 0)
                    local cooked = s.bags and s.bags[r.outputItem] or 0
                    if cooked > 0 then score = score + 15 end
                    if grey then score = score - 100 end
                    if (not grey or known) and (not best or score > bestScore) then
                        best,bestScore = {id=id, r=r, spot=spot,status=status,grey=grey,cooked=cooked},score
                    end
                end
            end
        end
    end
    return best
end

-- Healing teas use herbs and a drink. A spell-damage fish never serves as a
-- healing substitute. If scanning found nothing actionable, distinguish an
-- unopened recipe window from a confirmed missing recipe.
function ns.HealingFoodLine(s,rank)
    if not rank or not ns.HealingFoodOption then return end
    local tea = ns.HealingFoodOption(s,rank,true)
    if tea then
        local action = tea.status == "known" and ("Use " .. tea.materials .. ".") or tea.source
        local foodOnly = tea.isGrey and " Food only. No skill-ups." or ""
        return ("%s (%s). %s%s"):format(tea.name,tea.buff,action or "Open Cooking to check the recipe.",foodOnly)
    end
    for _, r in ipairs(ns.HealingTeas or {}) do
        if rank < r.skill and (s.level or 0) >= r.level then
            return ("At Cooking %d, %s gives +%d Healing Power."):format(r.skill,r.name,r.power)
        end
    end
end

function ns.HybridFishOption(s, where)
    if not (s.skills and s.skills.Cooking and ns.HybridFoodAlternatives) then return end
    local opt = (ns.HybridFoodAlternatives(s) or {})[1]
    if not opt then return end
    local packed = ns.ReadyBuildFood(s,opt.focus)
    if packed then return opt.label .. " option: " .. packed end
    if opt.focus == "healing" then
        local line = ns.HealingFoodLine(s,s.skills.Cooking.rank)
        return line and (opt.label .. " option: " .. line)
    end
    if not (enabled("fishing") and enabled("fishingLocation") and s.skills.Fishing) then return end
    local same = where and where.fishID and ns.fish[where.fishID]
    if same and ns.FishingFoodType(where.fishID) == opt.focus
            and (s.level or 0) >= (ns.FishingFoodLevel(where.fishID) or 1)
            and s.skills.Cooking.rank >= same.skill and not ns.RecipeOutlevelled(s.skills.Cooking,same) then
        local line = ("%s option: %s gives %s when cooked."):format(opt.label,rawName(same),same.buff)
        -- The main location row already carries this catch's acquisition advice.
        return line
    end
    local best = hybridCatch(s,where,opt.focus)
    if best then
        local note = ""
        local target
        if best.status == "missing" then
            local learn
            learn,target = learnRecipe(s,best.id,best.r,"missing")
            if learn then note = " " .. learn end
        end
        if best.status == "unknown" then note = " Check your recipe." end
        if best.grey then note = " Food only. No Cooking skill-ups." end
        if best.cooked > 0 then
            return ("%s option: eat %s from your bags for %s.%s"):format(opt.label,best.r.recipe,best.r.buff,note)
        end
        if best.status == "known" and (s.bags and s.bags[best.id] or 0) > 0 then
            return ("%s option: cook the %s in your bags for %s.%s"):format(opt.label,rawName(best.r),best.r.buff,note)
        end
        return ("%s option: fish %s for %s (%s).%s"):format(opt.label,best.spot.water,rawName(best.r),best.r.buff,note),target
    end
    local nextFood = ns.NextFishFoodUnlock(s,s.skills.Cooking.rank,opt.focus)
    return opt.label .. " option: " .. (nextFood or "No suitable fish for your current skills and level.")
end

local function fishingStep(s, skill, where)
    if not where or not where.spot then return where and where.body or ("Work towards Fishing %d."):format(skill.cap) end
    local spot, fish = where.spot, ns.fish[where.fishID]
    local effective = skill.rank + (skill.modifier or 0) + (skill.temp or 0)
    local lines = {"Fish " .. spot.water .. (fish and (" for " .. rawName(fish)) or "") .. "."}
    local target
    if fish and s.skills.Cooking then
        local cooking = s.skills.Cooking
        if where.status == "known" and cooking.rank < cooking.cap and not ns.RecipeOutlevelled(cooking,fish) then
            lines[#lines+1] = progress(s,cooking,fish,where.fishID,true)
        elseif where.status ~= "known" then
            lines[#lines+1],target = learnRecipe(s,where.fishID,fish,where.status,where.vendorTarget)
        elseif where.matches then lines[#lines+1] = fish.buff .. "." end
    end
    if effective < spot.noEscape then
        local extra,lure = ns.FishingLureGain(s)
        if extra and effective < spot.minimum then lines[#lines+1] = "Apply " .. lure .. " before casting." end
        lines[#lines+1] = ("Aim for %d effective Fishing to avoid escapes."):format(spot.noEscape)
    elseif not fish then
        lines[#lines+1] = ("Practise to Fishing %d."):format(skill.cap)
    end
    return table.concat(lines," "),target
end

-- Optional 'where' is the shared, already-evaluated Fishing tab verdict.
local function nextStep(s, profession, skill, where)
    local fishOn = enabled("fishing")
    local locations = fishOn and enabled("fishingLocation") and s.skills.Fishing
    if profession == "Fishing" then
        if not locations then return ("Work towards Fishing %d."):format(skill.cap) end
        return fishingStep(s,skill,where or ns.FishingLocationAdvice(s,"cooking"))
    end
    if profession ~= "Cooking" then return end
    local choice, fallback = recipeChoices(s,skill,fishOn)
    local tea = ns.FishingFoodFocus(s) == "healing" and ns.HealingFoodOption and ns.HealingFoodOption(s,skill.rank)
    local ready = readyLine(s,skill,choice,tea)
    if ready then return ready end
    if tea and ((tea.status == "known" and (tea.ready or 0) > 0) or not choice) then
        local action = tea.status == "known" and ((tea.ready or 0) > 0 and ("Brew %s up to %d times."):format(tea.name,tea.ready)
            or ("Get %s for %s."):format(tea.materials,tea.name))
            or (tea.name .. ". " .. (tea.source or "Open Cooking to check the recipe."))
        local rankTarget = tea.yellow and (" Aim for Cooking %d."):format(math.min(skill.cap,select(3,difficulty(skill.rank,tea)))) or ""
        return action .. " " .. tea.buff .. "." .. rankTarget, tea.target
    end
    if not choice and locations then
        where = where or ns.FishingLocationAdvice(s,"cooking")
        local fish = where and ns.fish[where.fishID]
        if fish then
            local learn, target = learnRecipe(s,where.fishID,fish,where.status,where.vendorTarget)
            if learn then return learn .. " Then fish " .. where.spot.water .. " for " .. rawName(fish) .. ".",target end
            local extra = fish.reagent and (" Add " .. fish.reagent .. " per craft.") or ""
            return ("Fish %s for %s.%s %s"):format(where.spot.water,rawName(fish),extra,progress(s,skill,fish,where.fishID,true))
        end
    end
    choice = choice or fallback
    if not choice then return "Open Cooking and choose an orange or yellow recipe for skill-ups." end
    local r, id = choice.recipe,choice.id
    local learn, target = learnRecipe(s,id,r,choice.status)
    if learn then return learn .. " Each craft uses " .. supply(s,choice,true) .. ".", target end
    local action
    if choice.count > 0 then
        action = ("Cook up to %d × %s%s."):format(choice.count,r.recipe,r.station and (" at an "..r.station) or "")
    else
        local inputs = supply(s,choice)
        if choice.main > 0 then
            action = ("Buy %s from a trade or Cooking supplier for %s."):format(inputs,r.recipe)
        elseif (id == 3685 or id == 12184) and s.mapID == 1417 and (s.level or 0) >= 30 then
            -- Both ingredients observed: ahledger.com/wow-forever/npcs/2559-highland-strider
            action = ("Hunt Highland Striders here for %s. Use %s per %s."):format(r.name,supply(s,choice,true),r.recipe)
        else
            action = ("Get %s for %s."):format(inputs,r.recipe)
        end
        if r.station then action = action .. " Use an " .. r.station .. "." end
    end
    return action .. " " .. progress(s,skill,r,id,fishOn and s.skills.Fishing ~= nil)
end

function ns.FishCookingNext(s, profession, skill, where)
    local text,target = nextStep(s,profession,skill,where)
    if not text then return end
    local filter = ns.DB and ns.DB().settings.professionFilter
    if profession == "Cooking" or (profession == "Fishing" and filter == "Fishing" and enabled("fishing") and enabled("fishingLocation")) then
        local alt,altTarget = ns.HybridFishOption(s,where)
        if alt then
            text = text .. "\n" .. alt
            target = target or altTarget
        end
    end
    return text,target
end
