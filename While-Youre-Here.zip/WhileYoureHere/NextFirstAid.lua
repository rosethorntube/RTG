local _, ns = ...

-- Skill bands and teachers: https://www.wowhead.com/forever/guide/professions/first-aid/overview
-- Reagents and grey thresholds: https://1mw.io/en/professions/first-aid/recipes
ns.FirstAidBandages = {
    {from=1,   spell=3275,  name="Linen Bandage",           cloth="Linen Cloth",     count=1},
    {from=40,  spell=3276,  name="Heavy Linen Bandage",     cloth="Linen Cloth",     count=2},
    {from=80,  spell=3277,  name="Wool Bandage",            cloth="Wool Cloth",      count=1},
    {from=115, spell=3278,  name="Heavy Wool Bandage",      cloth="Wool Cloth",      count=2},
    {from=150, spell=7928,  name="Silk Bandage",            cloth="Silk Cloth",      count=1},
    {from=180, spell=7929,  name="Heavy Silk Bandage",      cloth="Silk Cloth",      count=2, manual=16112},
    {from=210, spell=10840, name="Mageweave Bandage",       cloth="Mageweave Cloth", count=1, manual=16113},
    {from=240, spell=10841, name="Heavy Mageweave Bandage", cloth="Mageweave Cloth", count=2, doctor=true},
    {from=260, spell=18629, name="Runecloth Bandage",       cloth="Runecloth",       count=1, doctor=true},
    {from=290, spell=18630, name="Heavy Runecloth Bandage", cloth="Runecloth",       count=2, doctor=true},
}

local allianceShop = {vendor="Deneb Walker", mapID=1417, zone="Arathi Highlands", x=.270, y=.588}
local doctors = {
    Horde="Doctor Gregory Victor in Hammerfall, Arathi Highlands (73.4, 36.8)",
    Alliance="Doctor Gustaf VanHowzen in Theramore, Dustwallow Marsh (67.6, 48.8)",
}
local hordeTrainers = {
    [1454]="Arnok in the Valley of Spirits, Orgrimmar",
    [1458]="Mary Edras in the Rogues' Quarter, Undercity",
    [1456]="Pand Stonebinder on Spirit Rise, Thunder Bluff",
    [1411]="Rawrk in Razor Hill, Durotar",
    [1420]="Nurse Neela in Brill, Tirisfal Glades",
    [1412]="Vira Younghoof in Bloodhoof Village, Mulgore",
}

function ns.FirstAidBookInstruction(s, id, name, status)
    local prefix = status == "unknown" and "If unlearned, " or ""
    local function action(verb, rest)
        if prefix == "" then verb = verb:gsub("^%l", string.upper) end
        return prefix .. verb .. " " .. name .. rest
    end
    local held = ns.RecipeItemHeld(s, id)
    if held == "bags" then return action("read", " from your bags.") end
    if held == "bank" then return action("collect", " from your bank and read it.") end
    local hint = ns.RecipeShoppingHint(s,id)
    local shop, village
    if s.faction == "Horde" then
        shop, village = ns.ExpertBookShops[16084], "Brackenwall Village"
    elseif s.faction == "Alliance" then
        shop, village = allianceShop, "Stromgarde Keep"
    end
    if ns.FeatureEnabled("vendors") then
        if not shop then return action("read",".")..(hint and " "..hint or "") end
        if hint and s.mapID ~= shop.mapID then
            local vendor = ("%s sells it in %s, %s (%.1f, %.1f)."):format(
                shop.vendor,village,shop.zone,shop.x*100,shop.y*100)
            return action("buy",".").." "..hint.." "..vendor, ns.RecipeVendorTarget(shop)
        end
        local source = string.format(" from %s in %s, %s (%.1f, %.1f).",
            shop.vendor, village, shop.zone, shop.x * 100, shop.y * 100)
        return action("buy", source)..(hint and " "..hint or ""), ns.RecipeVendorTarget(shop)
    end
    return action("read", ".")..(hint and " "..hint or "")
end

function ns.FirstAidNext(s, skill)
    local rank, cap = skill.rank, skill.cap
    local doctor = doctors[s.faction] or "your faction's trauma surgeon"
    local localTrainer = s.faction == "Horde" and hordeTrainers[s.mapID] or "a First Aid trainer"
    if rank >= 300 then return "First Aid is at its 300 cap." end
    if rank >= cap then
        if cap == 75 then return "Learn Journeyman First Aid from " .. localTrainer .. " to raise your cap to 150." end
        if cap == 150 then
            local text, target = ns.FirstAidBookInstruction(s, 16084, "Expert First Aid - Under Wraps", "missing")
            return text .. " It raises your cap to 225.", target
        end
        if cap == 225 then
            local action = (s.level or 0) < 35 and "Reach level 35, then complete" or "Complete"
            return action .. " Triage with " .. doctor .. " to raise your cap to 300."
        end
        return "Check your First Aid training rank before making more bandages."
    end
    for i = #ns.FirstAidBandages, 1, -1 do
        local bandage = ns.FirstAidBandages[i]
        if rank >= bandage.from then
            local nextBandage = ns.FirstAidBandages[i + 1]
            local goal = math.min(nextBandage and nextBandage.from or 300, cap)
            local craft = string.format("Make %ss to %d (%d %s each).",
                bandage.name, goal, bandage.count, bandage.cloth)
            local status = ns.NextRecipeStatus(s, bandage.spell)
            if status == "known" then return craft end
            if bandage.manual then
                local step, target = ns.FirstAidBookInstruction(s, bandage.manual, "Manual: " .. bandage.name, status)
                return step .. string.format(" Use %d %s per bandage to reach %d.",
                    bandage.count, bandage.cloth, goal), target
            end
            -- Linen Bandage comes with Apprentice First Aid.
            if bandage.from == 1 then return craft end
            local trainer = bandage.doctor and doctor or localTrainer
            local start = status == "missing" and "Learn the recipe from " or "If unlearned, learn the recipe from "
            return craft .. " " .. start .. trainer .. "."
        end
    end
    return "Learn Apprentice First Aid from " .. localTrainer .. "."
end
