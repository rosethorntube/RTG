local _,ns=...

local sample={title="Fish while waiting in Ratchet",body="Cast from the pier. Kilxx sells the Rainbow Fin Albacore recipe beside the waterfront."}
local empty={title="All caught up",body="New suggestions appear here as you travel, level up and collect materials."}
local template=BackdropTemplateMixin and "BackdropTemplate" or nil
local backdrop={
    bgFile="Interface\\Buttons\\WHITE8X8",
    edgeFile="Interface\\Buttons\\WHITE8X8",
    edgeSize=1,
}

function ns.AdvisorTooltip(frame,title,body)
    frame:SetScript("OnEnter",function(self)
        if not GameTooltip then return end
        local heading=type(title)=="function" and title() or title
        local detail=type(body)=="function" and body() or body
        GameTooltip:SetOwner(self,"ANCHOR_TOP")
        GameTooltip:AddLine(heading,1,.83,.48,true)
        GameTooltip:AddLine(detail,.92,.9,.84,true)
        GameTooltip:Show()
    end)
    local function hide(self)
        if GameTooltip and (not GameTooltip.IsOwned or GameTooltip:IsOwned(self)) then GameTooltip:Hide() end
    end
    frame:SetScript("OnLeave",hide)
    if frame.HookScript then frame:HookScript("OnHide",hide) end
end

function ns.SetGuideButtonSelected(button,selected)
    if button.selected==selected then return end
    button.selected=selected
    if button.SetBackdropColor then
        if selected then
            button:SetBackdropColor(.25,.19,.105,1)
            button:SetBackdropBorderColor(.67,.48,.25,1)
        else
            button:SetBackdropColor(.12,.12,.103,1)
            button:SetBackdropBorderColor(.32,.285,.206,1)
        end
    end
    if selected then button.label:SetTextColor(1,.86,.55)
    else button.label:SetTextColor(.92,.84,.70) end
end

function ns.CreateGuideButton(parent,text,width,height,onClick)
    local button=CreateFrame("Button",nil,parent,template)
    button:SetSize(width,height)
    if button.SetBackdrop then button:SetBackdrop(backdrop) end
    local label=button:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    label:SetPoint("LEFT",4,0)
    label:SetPoint("RIGHT",-4,0)
    label:SetWordWrap(false)
    label:SetJustifyH("CENTER")
    button.label=label
    button:SetFontString(label)
    button:SetNormalFontObject(GameFontNormalSmall)
    button:SetText(text)
    button:SetHighlightTexture("Interface\\Buttons\\UI-Listbox-Highlight2","ADD")
    if GameFontDisableSmall then button:SetDisabledFontObject(GameFontDisableSmall) end
    if button.SetMotionScriptsWhileDisabled then button:SetMotionScriptsWhileDisabled(true) end
    ns.SetGuideButtonSelected(button,false)
    button:SetScript("OnClick",onClick)
    return button
end

local function tone(texture,hex,alpha)
    local r,g,b=tonumber(hex:sub(1,2),16)/255,tonumber(hex:sub(3,4),16)/255,tonumber(hex:sub(5,6),16)/255
    texture:SetColorTexture(r,g,b,alpha)
end

local function questID(item)
    return tonumber((item.key or ""):match("^dungeon:pickup:(%d+)$"))
end

local function makeText(parent,font)
    local t=parent:CreateFontString(nil,"OVERLAY",font)
    t:SetJustifyH("LEFT")
    t:SetJustifyV("TOP")
    t:SetWordWrap(true)
    return t
end

local function textStyle(label,cfg,size)
    local hex=cfg.fg
    label:SetFont(STANDARD_TEXT_FONT,size,"")
    label:SetTextColor(tonumber(hex:sub(1,2),16)/255,tonumber(hex:sub(3,4),16)/255,
        tonumber(hex:sub(5,6),16)/255,cfg.fgAlpha/100)
end

-- Both suggestion views use the same per-giver marker and active route.
function ns.PickupGroups(items)
    local groups,byRow={},{}
    local map=ns.AdvisorMap
    if not map then return groups,byRow end
    for _,item in ipairs(items) do
        local id=questID(item)
        local key=id and item.target and map.key(item.target)
        if key then
            groups[key]=groups[key] or {}
            groups[key][#groups[key]+1]=id
            byRow[item]=key
        end
    end
    return groups,byRow
end

function ns.VendorNavigationTarget(item)
    local target=item.vendorTarget or item.target
    if type(target)=="table" and (target==item.vendorTarget or target.kind=="vendor")
        and type(target.name)=="string" and target.name:find("%S")
        and ns.AdvisorMap.waypointAvailable(target) then return target end
end

function ns.CreatePickupControls(c,changed)
    c.mark=CreateFrame("CheckButton",nil,c,"UICheckButtonTemplate")
    c.mark:SetSize(24,24)
    c.markLabel=makeText(c.mark,"GameFontHighlightSmall")
    c.markLabel:SetText("Mark on map")
    c.markLabel:SetPoint("LEFT",c.mark,"RIGHT",1,0)
    if c.mark.SetHitRectInsets then c.mark:SetHitRectInsets(0,-80,0,0) end
    c.mark:SetScript("OnClick",function(self)
        if not c.questIDs then return end
        ns.AdvisorMap.setMarked(c.mapTarget,self:GetChecked() and true or false,c.questIDs)
        changed()
    end)
    ns.AdvisorTooltip(c.mark,"Mark on map","Pin this quest giver on your world map. You can mark more than one giver.")
    c.go=ns.CreateGuideButton(c,"Navigate",87,21,function()
        if not c.mapKey then return end
        local map=ns.AdvisorMap
        if map.isTarget(c.mapTarget,c.routeKind) then map.stop()
        else map.navigate(c.mapTarget,c.questIDs,c.routeKind) end
        changed()
    end)
    ns.AdvisorTooltip(c.go,function() return c.go:GetText() end,function()
        if c.mapTarget and ns.AdvisorMap.isTarget(c.mapTarget,c.routeKind) then
            return "Stop guiding you to this location."
        end
        return "Set this location as the active destination for the direction arrow."
    end)
end

function ns.UpdatePickupControls(c,item,key,ids,offset,inset)
    local map=ns.AdvisorMap
    local vendor=not key and ns.VendorNavigationTarget(item)
    local target=key and item.target or vendor
    c.mapTarget,c.mapKey,c.questIDs=target,key or (vendor and map.key(vendor)),ids
    c.routeKind=vendor and "vendor" or nil
    c.mark:SetShown(key~=nil)
    c.go:SetShown(not not target)
    if not target then return false end
    inset=inset or 0
    c.go:ClearAllPoints()
    if key then
        c.mark:ClearAllPoints()
        c.mark:SetPoint("TOPLEFT",inset-2,-offset)
        c.mark:SetChecked(map.getIsMarked(target))
        c.go:SetWidth(87)
        c.go:SetPoint("LEFT",c.mark,"RIGHT",85,0)
    else
        c.go:SetWidth(124)
        c.go:SetPoint("TOPLEFT",inset,-offset)
    end
    local navigating=map.isTarget(target,c.routeKind)
    c.go:SetText(navigating and "Stop route" or (vendor and "Navigate to vendor" or "Navigate"))
    c.go:SetEnabled(navigating or map.waypointAvailable(target))
    return true
end

function ns.CreateSuggestionsList(parent,discard,acknowledge,changed)
    local scroll=CreateFrame("ScrollFrame",nil,parent,"UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT",parent,"TOPLEFT",10,-34)
    scroll:SetPoint("BOTTOMRIGHT",parent,"BOTTOMRIGHT",-31,9)
    local child=CreateFrame("Frame",nil,scroll)
    child:SetSize(200,1)
    scroll:SetScrollChild(child)
    local cards={}
    local list={scroll=scroll}
    local rendering,displayOnly,focus,pendingFocus=false,false,nil,false
    local function isOpen()
        if parent.IsVisible then return parent:IsVisible() end
        return parent:IsShown()
    end

    local function readViewport()
        if not isOpen() or displayOnly then return end
        local top=scroll:GetVerticalScroll()
        local bottom=top+scroll:GetHeight()
        local newlyRead=false
        for _,card in ipairs(cards) do
            -- The heading must enter the viewport. Merely creating a widget
            -- below the fold must not clear the alert on an unread suggestion.
            if card.item and card.item.alert and card.top+card.headingHeight>top and card.top<bottom then
                if acknowledge(card.item) then newlyRead=true end
            end
        end
        return newlyRead
    end

    local function onScroll()
        if not rendering and readViewport() then changed() end
    end
    if scroll.HookScript then
        scroll:HookScript("OnVerticalScroll",onScroll)
    else
        local previous=scroll:GetScript("OnVerticalScroll")
        scroll:SetScript("OnVerticalScroll",function(self,value)
            if previous then previous(self,value) end
            onScroll()
        end)
    end

    local function createCard()
        local c=CreateFrame("Frame",nil,child)
        c.title=makeText(c,"GameFontNormal")
        c.title:SetPoint("TOPLEFT",10,-8)
        c.body=makeText(c,"GameFontHighlightSmall")
        c.dismiss=ns.CreateGuideButton(c,"Dismiss",68,21,function() if c.item then discard(c.item,false) end end)
        c.mute=ns.CreateGuideButton(c,"Don't show again",113,21,function() if c.item then discard(c.item,true) end end)
        c.mute:SetPoint("LEFT",c.dismiss,"RIGHT",5,0)
        ns.AdvisorTooltip(c.dismiss,"Dismiss","Hide this tip until you log out of this character. Changing zones or reloading the UI keeps it hidden.")
        ns.AdvisorTooltip(c.mute,"Don't show again","Mute this tip across your characters. Restore it in Settings under Tips.")
        ns.CreatePickupControls(c,changed)
        c.wash=c:CreateTexture(nil,"BACKGROUND")
        c.wash:SetAllPoints(c)
        c.edge=c:CreateTexture(nil,"ARTWORK")
        c.edge:SetPoint("TOPLEFT",0,-1)
        c.edge:SetPoint("BOTTOMLEFT",0,1)
        c.edge:SetWidth(2)
        return c
    end

    function list:FocusOn(key)
        focus,pendingFocus=key,true
    end

    function list:Render(items,cfg,preview)
        if rendering or not isOpen() then return end
        rendering=true
        displayOnly=preview or #items==0
        local shown=preview and {sample} or (#items==0 and {empty} or items)
        local width=math.max(110,parent:GetWidth()-43)
        local y,focusAt=0,0
        local matched,byRow=ns.PickupGroups(shown)
        for i,item in ipairs(shown) do
            local c=cards[i]
            if not c then c=createCard();cards[i]=c end
            c.item=item
            c.top=y
            if focus and item.key==focus then focusAt=y end
            c:ClearAllPoints()
            c:SetPoint("TOPLEFT",child,"TOPLEFT",1,-y)
            c:SetWidth(width)
            tone(c.wash,cfg.border,cfg.background=="Clear" and 0 or cfg.bgAlpha*.0006)
            tone(c.edge,cfg.border,cfg.borderAlpha*(i==1 and .0065 or .0028))
            textStyle(c.title,cfg,cfg.font+2)
            textStyle(c.body,cfg,cfg.font)
            c.title:SetWidth(width-20)
            c.title:SetText(item.title or "")
            c.headingHeight=8+math.max(cfg.font+2,c.title:GetStringHeight())
            c.body:ClearAllPoints()
            c.body:SetPoint("TOPLEFT",10,-c.headingHeight-4)
            c.body:SetWidth(width-20)
            c.body:SetText(item.body or "")
            local offset=c.headingHeight+4+math.max(cfg.font,c.body:GetStringHeight())+5
            local key=byRow[item]
            if ns.UpdatePickupControls(c,item,key,matched[key],offset,10) then
                offset=offset+26
            end
            c.dismiss:SetShown(not displayOnly)
            c.mute:SetShown(not displayOnly)
            if not displayOnly then
                c.dismiss:ClearAllPoints()
                c.dismiss:SetPoint("TOPLEFT",10,-offset)
                offset=offset+22
            end
            c:SetHeight(offset+8)
            c:Show()
            y=y+offset+15
        end
        for i=#shown+1,#cards do
            local c=cards[i]
            c.item,c.mapKey=nil,nil
            c:Hide()
        end
        child:SetSize(width+2,math.max(1,y-7))
        scroll:UpdateScrollChildRect()
        local old=scroll:GetVerticalScroll()
        local to=math.min(pendingFocus and focusAt or old,scroll:GetVerticalScrollRange())
        if old~=to then scroll:SetVerticalScroll(to) end
        pendingFocus,focus=false,nil
        readViewport()
        rendering=false
    end
    return list
end
