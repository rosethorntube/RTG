local _, ns = ...
local goals = {cooking=true, food=true, gold=true}
function ns.FishingGoal(s)
    local record = s and ns.DB().characters[s.key]
    local goal = record and record.fishingGoal
    return goals[goal] and goal or "cooking"
end
function ns.SetFishingGoal(s, goal)
    local record = s and ns.DB().characters[s.key]
    if record and goals[goal] then record.fishingGoal = goal end
end
function ns.EfficiencyDestinationMap(s)
    local context = s and ns.GetRouteContext and ns.GetRouteContext(s)
    return context and context.destinationMapID
end
function ns.AdvisorFaction(s)
    return s and s.faction or (UnitFactionGroup and UnitFactionGroup("player"))
end

local sharedShops = {["Old Man Heming"]=true, ["Kelsey Yance"]=true, ["Kilxx"]=true,
    ["Gikkix"]=true, ["Ranik"]=true, ["Vendor-Tron 1000"]=true, ["Super-Seller 680"]=true,
    ["Lorelae Wintersong"]=true, ["Blizrik Buckshot"]=true, ["Alchemist Pestlezugg"]=true,
    ["Vizzklick"]=true, ["Krinkle Goodsteel"]=true, ["Qia"]=true, ["Xizzer Fizzbolt"]=true,
    ["Himmik"]=true}
function ns.RecipeShopAccessible(s, shop)
    if not shop then return false end
    local faction = ns.AdvisorFaction(s)
    if shop.faction then return shop.faction == faction end
    if faction == "Horde" then return true end
    return sharedShops[shop.vendor] or shop.hub == "Booty Bay" or false
end
function ns.AccessibleFishShop(s, id, preferred)
    if ns.RecipeShopAccessible(s, preferred) then return preferred end
    local recipe = ns.fish[id]
    if not recipe then return end
    if ns.RecipeShopAccessible(s, recipe) then return recipe end
    local selected
    for _, shop in ipairs(ns.RecipeStops or {}) do
        if shop.item == recipe.recipeItem and ns.RecipeShopAccessible(s,shop) then
            if shop.mapID == s.mapID then return shop end
            if not selected or shop.vendor < selected.vendor then selected = shop end
        end
    end
    return selected
end

-- Compare the purchase premium to the player's chosen value of a minute.
-- A waypoint establishes a destination zone, never a walking time.
function ns.DetourHint(s, id, premium, age)
    local rate = tonumber(ns.DB().settings.timeGoldPerHour)
    if not rate or rate <= 0 or not premium or premium <= 0 or type(age) ~= "number" or age < 0 or age > 1 then return end
    local seconds = premium * 3600 / (10000 * rate)
    local duration = seconds < 60 and (math.max(1,math.floor(seconds+.5)).." sec") or
        (("%g"):format(math.ceil(seconds / 6) / 10).." min")
    local dest = ns.EfficiencyDestinationMap(s)
    local localShop, onRoute
    for _, shop in ipairs(ns.RecipeStops or {}) do
        if shop.item == id and ns.RecipeShopAccessible(s,shop) then
            if shop.mapID == s.mapID then localShop = shop.zone end
            if dest and shop.mapID == dest then onRoute = shop.zone end
        end
    end
    local route = localShop and (" A vendor is in "..localShop..".") or
        (onRoute and (" A vendor is in your destination zone, "..onRoute..".") or "")
    return ("AH pays off if it saves %s at %gg/hour."):format(duration,rate)..route
end

