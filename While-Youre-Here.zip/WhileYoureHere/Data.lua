local _, ns = ...
ns.title = "While You're Here"

-- The first grey rank is already too late for a skill-up. Use the character's
-- rank in the recipe's profession, independently of their level or skill cap.
function ns.RecipeOutlevelled(skill, recipe)
    local grey = recipe.grey or recipe.untilRank
    return type(grey) == "number" and skill ~= nil and type(skill.rank) == "number"
        and skill.rank >= grey
end

local function spellbookConfirms(fn, spell)
    if type(fn) ~= "function" then return false end
    local ok, value = pcall(fn, spell)
    return ok and (value == true or value == 1)
end

-- A negative spellbook lookup is inconclusive for trade recipes. Only a
-- scan of this character's own profession can confirm a recipe is missing.
function ns.NextRecipeStatus(state, spell)
    if not spell then return "unknown" end
    if state.missing and state.missing[spell] then return "missing" end
    if state.known and state.known[spell] then return "known" end
    if spellbookConfirms(C_SpellBook and C_SpellBook.IsSpellKnown, spell)
        or spellbookConfirms(IsPlayerSpell, spell) or spellbookConfirms(IsSpellKnown, spell) then
        return "known"
    end
    return "unknown"
end

-- World map positions are fractions of the zone map. These are recipe vendors,
-- not catch locations. Each record is keyed by the raw fish item ID.
local vendors = {
    gikkix = {
        vendor = "Gikkix", zone = "Tanaris", mapID = 1446,
        x = 0.666, y = 0.221,
        directions = "Steamwheedle Port, on the north-east coast of Tanaris. Look for Gikkix the fisherman.",
        vendorSource = "https://bindonforever.com/npc/8137",
    },
    harn = {
        vendor = "Harn Longcast", faction = "Horde", zone = "Mulgore", mapID = 1412,
        x = 0.467, y = 0.592,
        directions = "Bloodhoof Village, on the shore of Stonebull Lake.",
        vendorSource = "https://warcraftforever.wiki/wiki/Harn_Longcast",
    },
    kilxx = {
        vendor = "Kilxx", zone = "The Barrens", mapID = 1413,
        x = 0.628, y = 0.382,
        directions = "Ratchet, on the waterfront by the docks. Look for Kilxx the fisherman.",
        vendorSource = "https://azeroth.wiki/forever/map/the-barrens/kilxx",
    },
    kelsey = {
        vendor = "Kelsey Yance", zone = "Stranglethorn Vale", mapID = 1434,
        x = 0.282, y = 0.743,
        directions = "Booty Bay. Walk ashore from the Ratchet ship dock into the Old Port Authority, the large building at its end. Stay on the bottom deck and turn left inside.",
        vendorSource = "https://www.wow-professions.com/forever/npc/kelsey-yance",
    },
    sheendra = {
        vendor = "Sheendra Tallgrass", faction = "Horde", zone = "Feralas", mapID = 1444,
        x = 0.745, y = 0.427,
        directions = "Camp Mojache, east Feralas. Look for Sheendra the trade supplies vendor inside the Horde camp.",
        vendorSource = "https://bindonforever.com/npc/8145",
    },
    zansoa = {
        vendor = "Zansoa", faction = "Horde", zone = "Durotar", mapID = 1411,
        x = 0.561, y = 0.734,
        directions = "Sen'jin Village, on the south-east Durotar coast. Look for the fishing supplies vendor.",
        vendorSource = "https://warcraftforever.wiki/wiki/Zansoa",
    },
}

local function soldBy(vendor, recipe)
    for key, value in pairs(vendor) do
        recipe[key] = value
    end
    recipe.source = "https://www.wowhead.com/forever/spell=" .. recipe.spell
    return recipe
end

function ns.RecipeVendorTarget(shop)
    if not (shop and shop.vendor and shop.mapID and shop.x and shop.y) then return end
    return {kind="vendor", name=shop.vendor, mapID=shop.mapID, x=shop.x, y=shop.y}
end

-- Yellow, green and grey are the Cooking skill at which each colour begins.
-- Reagents listed here are in addition to one raw fish, and apply per craft.
-- Output and input counts: https://wowforeverhq.com/professions/cooking/
-- Output item records: https://zephras.com/forever/enUS/item/{itemID}/
ns.fish = {
    [4603] = soldBy(vendors.gikkix, {
        name = "Raw Spotted Yellowtail", recipe = "Spotted Yellowtail",
        recipeItem = 13939, spell = 18238,
        outputItem = 6887, outputPerCraft = 1, fishPerCraft = 1,
        skill = 225, yellow = 265, green = 285, grey = 305,
        buff = "+22 spell damage",
    }),
    [6289] = soldBy(vendors.harn, {
        name = "Raw Longjaw Mud Snapper", recipe = "Longjaw Mud Snapper",
        recipeItem = 6328, spell = 7753,
        outputItem = 4592, outputPerCraft = 1, fishPerCraft = 1,
        skill = 50, yellow = 90, green = 110, grey = 130,
        buff = "+10 attack power",
    }),
    [6291] = soldBy(vendors.harn, {
        name = "Raw Brilliant Smallfish", recipe = "Brilliant Smallfish",
        recipeItem = 6325, spell = 7751,
        outputItem = 6290, outputPerCraft = 1, fishPerCraft = 1,
        skill = 1, yellow = 45, green = 65, grey = 85,
        buff = "+2 attack power",
    }),
    [6303] = soldBy(vendors.zansoa, {
        name = "Raw Slitherskin Mackerel", recipe = "Slitherskin Mackerel",
        recipeItem = 6326, spell = 7752,
        outputItem = 787, outputPerCraft = 1, fishPerCraft = 1,
        skill = 1, yellow = 45, green = 65, grey = 85,
        buff = "+6 attack power",
    }),
    [6308] = soldBy(vendors.kilxx, {
        name = "Raw Bristle Whisker Catfish", recipe = "Bristle Whisker Catfish",
        recipeItem = 6330, spell = 7755,
        outputItem = 4593, outputPerCraft = 1, fishPerCraft = 1,
        skill = 100, yellow = 140, green = 160, grey = 180,
        buff = "+8 Fishing",
    }),
    [6361] = soldBy(vendors.kilxx, {
        name = "Raw Rainbow Fin Albacore", recipe = "Rainbow Fin Albacore",
        recipeItem = 6368, spell = 7827,
        outputItem = 5095, outputPerCraft = 1, fishPerCraft = 1,
        skill = 50, yellow = 90, green = 110, grey = 130,
        buff = "+1 spell damage",
    }),
    [6362] = soldBy(vendors.kelsey, {
        name = "Raw Rockscale Cod", recipe = "Rockscale Cod",
        recipeItem = 6369, spell = 7828,
        outputItem = 4594, outputPerCraft = 1, fishPerCraft = 1,
        skill = 175, yellow = 190, green = 210, grey = 230,
        buff = "+12 Fishing",
    }),
    [8365] = soldBy(vendors.kelsey, {
        name = "Raw Mithril Head Trout", recipe = "Mithril Headed Trout",
        recipeItem = 17062, spell = 20916,
        outputItem = 8364, outputPerCraft = 1, fishPerCraft = 1,
        skill = 175, yellow = 215, green = 235, grey = 255,
        buff = "+20 attack power",
    }),
    [13754] = soldBy(vendors.kelsey, {
        name = "Raw Glossy Mightfish", recipe = "Cooked Glossy Mightfish",
        recipeItem = 13940, spell = 18239,
        outputItem = 13927, outputPerCraft = 1, fishPerCraft = 1,
        ingredients = {[3713] = 1},
        skill = 225, yellow = 265, green = 285, grey = 305,
        buff = "+30 attack power",
        reagent = "1 Soothing Spices",
    }),
    [13758] = soldBy(vendors.kelsey, {
        name = "Raw Redgill", recipe = "Filet of Redgill",
        recipeItem = 13941, spell = 18241,
        outputItem = 13930, outputPerCraft = 1, fishPerCraft = 1,
        skill = 225, yellow = 265, green = 285, grey = 305,
        buff = "+18 Fishing",
    }),
    [13759] = soldBy(vendors.gikkix, {
        name = "Raw Nightfin Snapper", recipe = "Nightfin Soup",
        recipeItem = 13945, spell = 18243,
        outputItem = 13931, outputPerCraft = 1, fishPerCraft = 1,
        ingredients = {[159] = 1},
        skill = 250, yellow = 290, green = 310, grey = 330,
        buff = "+22 spell damage",
        reagent = "1 Refreshing Spring Water",
    }),
    [13760] = soldBy(vendors.gikkix, {
        name = "Raw Sunscale Salmon", recipe = "Poached Sunscale Salmon",
        recipeItem = 13946, spell = 18244,
        outputItem = 13932, outputPerCraft = 1, fishPerCraft = 1,
        skill = 250, yellow = 290, green = 310, grey = 330,
        buff = "+40 attack power",
        station = "Iron Oven",
    }),
    [13889] = soldBy(vendors.sheendra, {
        name = "Raw Whitescale Salmon", recipe = "Baked Salmon",
        recipeItem = 13949, spell = 18247,
        outputItem = 13935, outputPerCraft = 1, fishPerCraft = 1,
        ingredients = {[3713] = 1},
        skill = 275, yellow = 315, green = 335, grey = 355,
        buff = "+28 spell damage",
        reagent = "1 Soothing Spices", station = "Iron Oven",
    }),
    [13893] = soldBy(vendors.sheendra, {
        name = "Large Raw Mightfish", recipe = "Mightfish Steak",
        recipeItem = 13948, spell = 18246,
        outputItem = 13934, outputPerCraft = 1, fishPerCraft = 1,
        ingredients = {[2692] = 1, [3713] = 1},
        skill = 275, yellow = 315, green = 335, grey = 355,
        buff = "+40 attack power",
        reagent = "1 Hot Spices and 1 Soothing Spices", station = "Iron Oven",
    }),
    [21071] = soldBy(vendors.kelsey, {
        name = "Raw Sagefish", recipe = "Smoked Sagefish",
        recipeItem = 21099, spell = 25704,
        outputItem = 21072, outputPerCraft = 1, fishPerCraft = 1,
        ingredients = {[2678] = 1},
        skill = 80, yellow = 120, green = 140, grey = 160,
        buff = "+4 spell damage",
        reagent = "1 Mild Spices",
    }),
    [21153] = soldBy(vendors.kelsey, {
        name = "Raw Greater Sagefish", recipe = "Sagefish Delight",
        recipeItem = 21219, spell = 25954,
        outputItem = 21217, outputPerCraft = 1, fishPerCraft = 1,
        ingredients = {[2692] = 1},
        skill = 175, yellow = 215, green = 235, grey = 255,
        buff = "+7 spell damage",
        reagent = "1 Hot Spices",
    }),
}

-- Prefer a verified vendor in the current zone. The default record remains useful elsewhere.
-- Other shops can stock the same fish recipe.
ns.localFishVendors = {
    [1424] = {
        vendor="Derak Nightfall", zone="Hillsbrad Foothills", hub="Tarren Mill", mapID=1424, x=0.631, y=0.194, faction="Horde",
        directions="Beside the inn in Tarren Mill.",
        items={[6308]=true,[21071]=true,[21153]=true},
        source="https://questing.wiki/wow-forever/npcs/2397/?inventory=6330",
    },
    [1454] = {
        vendor="Shankys", faction="Horde", zone="Orgrimmar", mapID=1454, x=0.699, y=0.298,
        directions="Find the fishing supplier by the water in the Valley of Honor.",
        items={[6361]=true,[6362]=true,[8365]=true},
        source="https://warcraftforever.wiki/wiki/Shankys",
    },
    [1458] = {
        vendor="Lizbeth Cromwell", faction="Horde", zone="Undercity", mapID=1458, x=0.810, y=0.308,
        directions="Ask a guard for the Fishing trainer. Lizbeth is the fishing supplier nearby.",
        items={[6291]=true,[6289]=true,[6362]=true,[8365]=true},
        source="https://bindonforever.com/npc/4574",
    },
    [1456] = {
        vendor="Sewa Mistrunner", faction="Horde", zone="Thunder Bluff", mapID=1456, x=0.558, y=0.470,
        directions="Look for the fishing supplier beside the central pond.",
        items={[6291]=true,[6308]=true},
        source="https://bindonforever.com/npc/3029",
    },
    [1443] = {
        vendor="Wulan", faction="Horde", zone="Desolace", mapID=1443, x=0.261, y=0.697,
        directions="Shadowprey Village, upstairs in the eastern building. Wulan also sells the Expert Cookbook.",
        items={[6362]=true},
        source="https://www.wowhead.com/forever/item=6369",
    },
}
