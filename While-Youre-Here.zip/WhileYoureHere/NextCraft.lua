local _, ns = ...

-- The regional vendor catalogue supplies most waypoints. These shops complete
-- the existing levelling route; shared vendors retain their original records.
-- Coordinates: warcraftforever.wiki/wiki/Sovik, /wiki/Kulwia; forever-tavern.com
-- (Werg); elitegrindlab.com (Jase); wow-professions.com/forever/npc (Magnus).
local function shop(name, zone, mapID, x, y, note)
    return {vendor=name, zone=zone, mapID=mapID, x=x, y=y, note=note}
end
local kulwia = shop("Kulwia", "Sun Rock Retreat", 1442, .453, .593)
local magnus = shop("Magnus Frostwake", "Caer Darrow", 1422, .680, .770, "Equip Spectral Essence to see him.")
-- Pexmit is a rare merchant with several reported positions.
local pexmit = shop("Pexmit", "Mount Hyjal")
-- Forever item 13477 is also stocked by the Alliance reagent vendor Ulthir.
local allianceShops = {[13477]=shop("Ulthir","Darnassus",1457,.558,.245)}
local extraShops = {
    [11039]=kulwia, [11101]=kulwia,
    [8030]=magnus, [12819]=magnus,
    [251468]=pexmit, [254124]=pexmit,
    [16042]=shop("Sovik", "Orgrimmar", 1454, .757, .253),
    [20754]=shop("Kania", "Cenarion Hold", 1451, .520, .397),
    [15725]=shop("Werg Thickblade", "the Bulwark", 1420, .833, .697),
    [15756]=shop("Jase Farlane", "Light's Hope Chapel", 1423, .709, .481),
}
local function shopFor(state, item)
    if state.faction == "Alliance" then return allianceShops[item] end
    if state.faction ~= "Horde" then return end
    local candidate
    for _, row in ipairs(ns.RecipeStops or {}) do
        if row.item == item and (not row.faction or row.faction == state.faction) then
            if row.mapID == state.mapID then return row end
            candidate = candidate or row
        end
    end
    return candidate or extraShops[item]
end

-- Starter elixirs share a skill curve. The trainer alternatives below match the
-- normal route's skill-up chance throughout the ranks where they are offered.
local function alchemyChoice(state, rank, label, recipe)
    local recipes = ns.CraftNextData.Alchemy
    local profile = ns.ProfessionBuildProfile(state)
    local role = profile.role
    local bags = state.bags or {}
    local preferred, reason, altHerb, defaultHerb
    if label == "Minor Force" and role == "caster" then
        preferred, reason = recipes["Minor Arcane Elixir"], "+5 spell damage."
        altHerb, defaultHerb = 2447, 765 -- Peacebloom or Silverleaf
    elseif label == "Minor Defense" and role == "melee" and rank >= 15 then
        preferred, reason = recipes["Elixir of Minor Strength"], "+4 Strength."
        altHerb, defaultHerb = 2449, 2447 -- Earthroot or Peacebloom
    elseif label == "Minor Defense" and (role == "healer" or role == "caster") and rank >= 25 then
        preferred, reason = recipes["Minor Mana"], "Restores mana."
        altHerb, defaultHerb = 785, 765 -- Mageroyal or Silverleaf
    end
    if not preferred then return recipe end
    local status = ns.NextRecipeStatus(state, preferred.spell)
    if (preferred.source == "starter" and status ~= "missing") or status == "known" then
        -- Retain the guide craft if its distinguishing herb is already in the
        -- bags and the proposed alternative's herb is absent.
        if not ((bags[defaultHerb] or 0) > 0 and (bags[altHerb] or 0) == 0) then
            return preferred, reason
        end
    end
    return recipe
end

local function leatherChoice(state, skill, label)
    if label ~= "Barbaric Harness" or skill.rank < 185 or (state.level or 0) < 36 then return end
    local profile = ns.ProfessionBuildProfile(state)
    local wantsAgility = profile.class == "HUNTER" or profile.class == "ROGUE" or profile.spec == "Feral"
    if not wantsAgility then return end
    local headband = ns.CraftNextData.Leatherworking["Nightscape Headband"]
    if ns.NextRecipeStatus(state, headband.spell) ~= "known" then return end
    local bags = state.bags or {}
    if not state.bagsScanned then return end
    if (bags[4304] or 0) < 5 or (bags[4291] or 0) < 2 or (bags[8176] or 0) > 0 then return end
    if not GetInventoryItemID or GetInventoryItemID("player", 1) then return end
    return "Make one Nightscape Headband for your empty head slot (+12 Agility, +11 Stamina). 5 Thick Leather, 2 Silken Thread."
end

local function shopping(state, recipe, status)
    local held = recipe.item and ns.RecipeItemHeld(state, recipe.item)
    if held == "bags" then return "Read the recipe in your bags." end
    if held == "bank" then return "Collect the recipe from your bank and read it." end
    local hint = ns.RecipeShoppingHint and ns.RecipeShoppingHint(state, recipe.item)
    local shop = ns.FeatureEnabled("vendors") and shopFor(state, recipe.item)
    local detail
    if shop then
        local location = shop.vendor .. " in " .. (shop.hub or shop.zone) .. "."
        if shop.note then location = location .. " " .. shop.note end
        if hint and not ((shop.mapID and shop.mapID == state.mapID) or shop.zone == state.zone) then
            return hint .. " Vendor option is " .. location, ns.RecipeVendorTarget(shop)
        end
        detail = (status == "missing" and "Buy the recipe from " or "If unlearned, buy the recipe from ")
            .. location
    elseif recipe.source == "drop" then
        detail = status == "missing" and "The pattern is a world drop." or "If unlearned, the pattern is a world drop."
    else
        return hint or (status == "missing" and "Learn the recipe first." or nil)
    end
    if hint and hint ~= "" then detail = detail .. " " .. hint end
    return detail, shop and ns.RecipeVendorTarget(shop)
end

local function craftsFromBags(bags, inputs, reserve)
    local count
    for id, perCraft in pairs(inputs) do
        local available = math.max(0, (bags[id] or 0) - (reserve and reserve[id] or 0))
        local batches = math.floor(available / perCraft)
        count = count and math.min(count,batches) or batches
    end
    return count or 0
end

local function bagAdvice(state, profession, skill, recipe, target)
    if not state.bagsScanned or not ns.EfficiencyIngredients or not ns.EfficiencyMaterialName then return end
    local inputs, complete = ns.EfficiencyIngredients(profession,recipe)
    if not complete or not inputs or not next(inputs) then return end
    local bags = state.bags or {}
    local count = math.min(craftsFromBags(bags,inputs),target-skill.rank)
    if count > 0 then
        return ("Your bags cover %d craft%s."):format(count,count==1 and "" or "s")
    end
    local missing = {}
    local component
    for id, quantity in pairs(inputs) do
        local short = quantity - (bags[id] or 0)
        if short > 0 then
            local name = ns.EfficiencyMaterialName(id) or ("item "..id)
            missing[#missing+1] = short.." "..name
            for _, candidate in pairs(ns.CraftNextData[profession]) do
                if candidate.name == name and candidate.availableAt <= skill.rank and skill.rank < candidate.grey
                        and ns.NextRecipeStatus(state,candidate.spell) == "known" then
                    local materials, known = ns.EfficiencyIngredients(profession,candidate)
                    if known and materials and craftsFromBags(bags,materials,inputs) > 0
                            and (not component or candidate.grey < component.grey or
                            (candidate.grey == component.grey and candidate.spell < component.spell)) then
                        component = candidate
                    end
                end
            end
        end
    end
    if component then
        return ("Make %s first with the materials in your bags. It can still give a skill-up and supplies %s."):format(component.name,recipe.name), true
    end
    table.sort(missing)
    return "Still needed for one craft: "..table.concat(missing,", ").."."
end

function ns.CraftNext(state, profession, skill, step)
    local recipes = ns.CraftNextData[profession]
    if not recipes or not step or skill.rank >= skill.cap then return end
    local label = step[2]
    local recipe = recipes[label]
    if not recipe then return end
    local target = math.min(step[1], skill.cap, recipe.grey)
    -- Forever unlocks Nightscape Pants at 210. The original written route
    -- starts them at 205; the preceding Headband still grants points here.
    if profession == "Leatherworking" and label == "Nightscape Pants" and skill.rank < recipe.availableAt then
        target = math.min(target, recipe.availableAt)
        recipe = recipes["Nightscape Headband"]
    end
    if skill.rank < recipe.availableAt then
        return recipe.name .. " is available for this route at " .. recipe.availableAt
            .. ". Use a yellow or orange recipe until then."
    end
    if target <= skill.rank then
        return "Open "..profession.." and choose a yellow or orange recipe for your next skill-up."
    end
    if recipe.source == "ability" then
        local retention = ns.EnchantingRetention(state,skill.rank,true)
        return "Disenchant spare uncommon gear towards "..target..".\n"..retention
    end
    local reason
    if profession == "Alchemy" then
        recipe, reason = alchemyChoice(state, skill.rank, label, recipe)
        if recipe.source == "quest" and state.faction ~= "Horde" and ns.NextRecipeStatus(state,recipe.spell) ~= "known" then
            local alternative = recipes["Superior Mana"]
            if alternative and skill.rank >= alternative.availableAt and skill.rank < alternative.grey
                    and ns.NextRecipeStatus(state,alternative.spell) == "known" then
                recipe = alternative
                target = math.min(target,recipe.grey)
            else
                return "Choose a known orange or yellow Alchemy recipe for your next skill-up."
            end
        end
    elseif profession == "Leatherworking" then
        local alternative = leatherChoice(state, skill, label)
        if alternative then return alternative end
    end
    local status = ns.NextRecipeStatus(state, recipe.spell)
    local verb = recipe.name:match("^Enchant ") and "Apply " or "Make "
    local heading = verb .. recipe.name .. " to " .. target .. "."
    if reason then heading = heading .. " " .. reason end
    local note = ns.CraftOutputKeepNote(state,profession,recipe,target)
    local keep = note and ("\n"..note) or ""
    local text = heading .. " " .. recipe.materials .. " per craft."
    if status == "known" then
        local detail, first = bagAdvice(state,profession,skill,recipe,target)
        if first then return detail end
        return (detail and (heading.." "..detail) or text)..keep
    end
    if recipe.item then
        local how, waypoint = shopping(state, recipe, status)
        if how then return text .. " " .. how..keep, waypoint end
    elseif recipe.source == "trainer" then
        local how = status == "missing" and "Learn it from your " or "If unlearned, visit your "
        return text .. " " .. how .. profession .. " trainer."..keep
    elseif recipe.source == "quest" then
        return text .. " For the training, finish Wild Hearts, Return to Quinn and Wild Eyes in Silverpine."..keep
    end
    return text..keep
end
