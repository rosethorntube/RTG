local _, ns = ...

-- A map/subzone alone cannot distinguish a river, its coast and a pool.
-- Attach observations to a water only after the player selects it in the Guide.
local choicesByMap, ids, timed = {}, {}, {}
for _, spot in ipairs(ns.FishingWaters) do
    local list = choicesByMap[spot.mapID] or {}
    list[#list + 1] = spot
    choicesByMap[spot.mapID] = list
    ids[spot] = ("%d/%s/%s"):format(spot.mapID, spot.pool and "school" or "open", spot.water)
    for _, fish in ipairs(spot.fish) do
        if fish == 13759 or fish == 13760 then timed[spot] = true end
    end
end

local selected, selectedSubzone, lastActivity
local activeTrip, activeSample, lastTick
local revision = 0

local function outdoorMap(state)
    if not state or (IsInInstance and IsInInstance()) then return end
    return ns.OutdoorZoneForData and ns.OutdoorZoneForData(state, choicesByMap) or state.mapID
end

function ns.FishingWaterChoices(state)
    return choicesByMap[outdoorMap(state)] or {}
end

local function endSegment()
    activeTrip, activeSample, lastTick = nil, nil, nil
end

function ns.ClearFishingWaterSelection()
    selected, selectedSubzone, lastActivity = nil, nil, nil
    endSegment()
end

function ns.CurrentFishingWaterSelection(state)
    if selected and (outdoorMap(state) ~= selected.mapID or (state.subzone or "") ~= selectedSubzone
            or GetTime() - lastActivity >= 120) then
        ns.ClearFishingWaterSelection()
    end
    return selected
end

function ns.SelectFishingWaterSample(state, spot)
    if spot and (not ids[spot] or outdoorMap(state) ~= spot.mapID) then return false end
    ns.ClearFishingWaterSelection()
    if spot then
        selected, selectedSubzone, lastActivity = spot, state.subzone or "", GetTime()
    end
    if ns.RequestRefresh then ns.RequestRefresh() end
    return true
end

local function sampleKey(spot, state)
    local skill = state and state.skills and state.skills.Fishing
    if not ids[spot] or not skill or not skill.rank then return end
    local effective = skill.rank + (skill.modifier or 0) + (skill.temp or 0)
    if effective < spot.minimum then return end
    local band = effective >= spot.noEscape and "no-escape" or math.floor(effective / 10)
    local period = "all"
    if timed[spot] then
        local hour = GetGameTime and GetGameTime() or state.hour
        if type(hour) ~= "number" or hour < 0 or hour >= 24 then return end
        period = math.floor(hour / 6)
    end
    return ids[spot] .. "/" .. band .. "/" .. period
end

local function advance(sample, now)
    if not sample or sample ~= activeSample then return end
    if now > lastTick then
        sample.seconds = sample.seconds + now - lastTick
        lastTick = now
        revision = revision + 1
    end
    lastActivity = now
end

function ns.ObserveWaterCast(trip, location, now)
    local spot = ns.CurrentFishingWaterSelection(location)
    local key = spot and sampleKey(spot, ns.state)
    if not key then endSegment(); return end
    if activeTrip ~= trip or not activeSample or activeSample.key ~= key then
        activeSample = {key=key, casts=0, seconds=0, items={}}
        activeTrip, lastTick = trip, now
        trip.waterSamples = trip.waterSamples or {}
        trip.waterSamples[#trip.waterSamples + 1] = activeSample
    end
    advance(activeSample, now)
    activeSample.casts = activeSample.casts + 1
    revision = revision + 1
    return activeSample
end

function ns.FinishWaterCast(trip, sample, now)
    if trip == activeTrip then advance(sample, now) end
end

-- A catch with no observed cast must never appear as extra loot for another
-- cast. Start a fresh segment rather than stretching the previous clock.
function ns.BreakWaterSample() endSegment() end

function ns.ObserveWaterItem(trip, sample, tag, item, now)
    if not sample or trip ~= activeTrip or sample ~= activeSample then return end
    advance(sample, now)
    local stack = sample.items[tag] or {id=item.id, link=item.link, count=0}
    stack.count = stack.count + item.count
    sample.items[tag] = stack
    revision = revision + 1
end

local function addVisit(index, trip, visit)
    for _, segment in ipairs(trip.waterSamples or {}) do
        if segment.seconds > 0 and segment.casts > 0 then
            local sample = index[segment.key]
            if not sample then
                sample = {seconds=0, casts=0, visits=0, quantity=0, items={}, variants={}}
                index[segment.key] = sample
            end
            if sample.lastVisit ~= visit then
                sample.visits, sample.lastVisit = sample.visits + 1, visit
            end
            sample.seconds = sample.seconds + segment.seconds
            sample.casts = sample.casts + segment.casts
            for tag, item in pairs(segment.items) do
                local id, count = item.id, item.count
                sample.quantity = sample.quantity + count
                sample.items[id] = (sample.items[id] or 0) + count
                local variant = sample.variants[tag] or {id=id, link=item.link, count=0, visits=0}
                if variant.lastVisit ~= visit then
                    variant.visits, variant.lastVisit = variant.visits + 1, visit
                end
                variant.count = variant.count + count
                sample.variants[tag] = variant
            end
        end
    end
end

local cachedState, cachedTrip, cachedHistory, cachedRevision, cachedBucket, cachedMarket, cachedPrices, index
local function currentIndex(state)
    local history, trip = ns.GetFishingWaterTrips(state)
    local bucket = math.floor(GetTime() / 5)
    local market = ns.MarketKey and ns.MarketKey()
    local prices = ns.FeatureEnabled("prices")
    if state ~= cachedState or history ~= cachedHistory or trip ~= cachedTrip or
        cachedRevision ~= revision or cachedBucket ~= bucket or cachedMarket ~= market or cachedPrices ~= prices then
        index = {}
        for i, visit in ipairs(history or {}) do addVisit(index, visit, i) end
        if trip then addVisit(index, trip, 0) end
        cachedState, cachedHistory, cachedTrip = state, history, trip
        cachedRevision, cachedBucket, cachedMarket, cachedPrices = revision, bucket, market, prices
    end
    return index
end

function ns.FishingWaterSample(state, spot)
    if state ~= ns.state or not ns.GetFishingWaterTrips then return end
    local key = sampleKey(spot, state)
    local sample = key and currentIndex(state)[key]
    if not sample or sample.comparable ~= nil then return sample end
    sample.comparable = sample.seconds >= 900 and sample.casts >= 20 and sample.quantity >= 10
    sample.goldComparable = false
    if sample.comparable and sample.visits >= 2 and ns.FeatureEnabled("prices") then
        local copper, repeatUnits, priced = 0, 0, true
        for _, item in pairs(sample.variants) do
            if item.visits >= 2 then
                repeatUnits = repeatUnits + item.count
                local value, method, info = ns.CatchSaleValue(item.id, item.link)
                local thinAuction = method == "auction" and info and info.source == "native"
                    and (info.offers or 0) < 2
                if value == nil or not info or not info.comparable or thinAuction then
                    priced = false
                else
                    item.recurringCopper = item.count * value
                    copper = copper + item.recurringCopper
                end
            end
        end
        sample.repeatUnits = repeatUnits
        -- One lucky auction item cannot make a spot win. Require recurring
        -- sale evidence for most of the catch, using the existing after-cut valuation.
        if priced and repeatUnits >= 0.8 * sample.quantity then
            sample.goldComparable = true
            sample.netCopperPerHour = copper * 3600 / sample.seconds
        end
    end
    return sample
end
