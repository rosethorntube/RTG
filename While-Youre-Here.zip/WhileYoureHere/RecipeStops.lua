local _, ns = ...
local byMap, byProfession, professionBySpell, hubMaps = {}, {}, {}, {}
local currentCharacter, missing = nil, {}

local function track(profession, spell)
    if not spell then return end
    byProfession[profession] = byProfession[profession] or {}
    byProfession[profession][spell] = true
    professionBySpell[spell] = profession
end
for _, recipes in ipairs({ns.fish, ns.otherCooking}) do
    for _, recipe in pairs(recipes) do track("Cooking", recipe.spell) end
end
for _, bandage in ipairs(ns.FirstAidBandages or {}) do track("First Aid", bandage.spell) end
for _, tea in ipairs(ns.HealingTeas or {}) do track("Cooking", tea.spell) end
if ns.TrackCraftNextRecipes then ns.TrackCraftNextRecipes(track) end
for _, row in ipairs(ns.RecipeStops) do
    byMap[row.mapID] = byMap[row.mapID] or {}
    table.insert(byMap[row.mapID], row)
    track(row.profession, row.spell)
    if row.hub then
        local name = row.hub:lower()
        if hubMaps[name] == nil then hubMaps[name] = row.mapID
        elseif hubMaps[name] ~= row.mapID then hubMaps[name] = false end
    end
end

local function call(fn, ...)
    if type(fn) ~= "function" then return end
    local ok, result = pcall(fn, ...)
    if ok then return result end
end
local function isForeign(trade)
    return call(trade.IsTradeSkillLinked) or call(trade.IsTradeSkillGuild)
        or call(trade.IsNPCCrafting) or call(trade.IsDataSourceChanging)
        or call(IsTradeSkillLinked) or call(IsTradeSkillGuild)
end
local function professionName(id, name)
    for profession in pairs(byProfession) do
        local def = ns.ProfessionDefinitions[profession]
        if def and (id == def.id or name == profession or (name and
            name == (call(C_Spell and C_Spell.GetSpellName, def.spell) or call(GetSpellInfo, def.spell)))) then
            return profession
        end
    end
end

-- Only an explicit Boolean from the player's own open profession can establish
-- an unlearned recipe. A filtered or collapsed legacy list proves positives only.
function ns.ScanTrackedRecipes(s, record)
    if currentCharacter ~= s.key then currentCharacter, missing = s.key, {} end
    record.known = record.known or {}
    s.known, s.missing = record.known, missing
    record.recipeSkillRanks = record.recipeSkillRanks or {}
    for profession, skill in pairs(s.skills) do
        if byProfession[profession] then
            local previous = record.recipeSkillRanks[profession]
            if previous and skill.rank < previous then
                -- Dropping and relearning a profession removes its old recipes.
                for spell in pairs(byProfession[profession]) do s.known[spell], missing[spell] = nil,nil end
            end
            record.recipeSkillRanks[profession] = skill.rank
        end
    end
    local trade = C_TradeSkillUI or {}
    if isForeign(trade) then return end
    local info = call(trade.GetBaseProfessionInfo) or {}
    local profession = professionName(info.professionID or info.skillLineID, info.professionName)
    local count, link = GetNumTradeSkills, GetTradeSkillRecipeLink
    if not profession then profession = professionName(nil, call(GetTradeSkillLine)) end
    if not profession then
        profession = professionName(nil, call(GetCraftSkillLine))
        count, link = GetNumCrafts, GetCraftRecipeLink
    end
    if not profession or not s.skills[profession] then return end
    for i = 1, call(count) or 0 do
        local recipeLink = call(link, i)
        local id = recipeLink and tonumber(recipeLink:match("enchant:(%d+)") or recipeLink:match("spell:(%d+)"))
        if id and professionBySpell[id] == profession then s.known[id], missing[id] = true, nil end
    end
    if not trade.GetRecipeInfo then return end
    for spell in pairs(byProfession[profession]) do
        local recipe = call(trade.GetRecipeInfo, spell)
        if type(recipe) == "table" and type(recipe.learned) == "boolean" then
            s.known[spell] = recipe.learned or nil
            missing[spell] = not recipe.learned or nil
        end
    end
end
function ns.ObserveRecipeLearned(spell)
    local s = ns.state
    if s and spell and professionBySpell[spell] and s.known then
        s.known[spell], missing[spell] = true, nil
    end
end

function ns.RecipeItemHeld(s, id)
    local n = s.bags and s.bags[id]
    if n == nil and not s.bagsScanned then n = call((C_Item and C_Item.GetItemCount) or GetItemCount, id, false) end
    if (n or 0) > 0 then return "bags" end
    local record = ns.CurrentRecord()
    if record and record.bankMaterials and (record.bankMaterials[id] or 0) > 0 then return "bank" end
end

local function locationNames(s)
    return {s.zone or "", s.subzone or "", call(GetMinimapZoneText) or "", call(GetZoneText) or ""}
end
local function insideHub(s, mapID, row, names)
    if not row.hub then return true end
    for _, name in ipairs(names) do
        if name:lower() == row.hub:lower() then return true end
    end
    if s.mapID ~= mapID or not s.x or not s.y then return false end
    -- Include the dock, boardwalk and indoor vendors on a localised client.
    if row.hub == "Booty Bay" then
        return s.x >= .255 and s.x <= .291 and s.y >= .723 and s.y <= .782
    end
    return row.x and row.y and (s.x-row.x)^2 + (s.y-row.y)^2 < .018^2
end

local function relevant(s, row)
    if (row.fishing or row.profession == "Fishing") and not ns.FeatureEnabled("fishing") then return end
    local skill = s.skills[row.profession]
    if not skill or not ns.RecipeShopAccessible(s,row) then return end
    if skill.rank < row.skill - (row.lead or 0) or (row.level and s.level < row.level) then return end
    if row.kind == "book" then
        if skill.cap >= row.cap then return end
    elseif ns.RecipeOutlevelled(skill, row) or ns.NextRecipeStatus(s,row.spell) == "known" then
        return
    end
    if not ns.RecipeItemHeld(s, row.item) then return skill end
end
function ns.AddRecipeStopTips(s, add)
    local offered = {}
    if not ns.AdvisorFaction(s) or call(IsInInstance) then return offered end
    if GetInstanceInfo then
        local _, kind = GetInstanceInfo()
        if kind and kind ~= "none" then return offered end
    end
    local mapID = ns.OutdoorZoneForData(s, byMap)
    local names = locationNames(s)
    if not mapID and not s.mapID then
        -- A loading screen can leave only the settlement name. Do not resolve
        -- conflicting or ambiguous place names to a guessed zone.
        for _, name in ipairs(names) do
            if name ~= "" then
                local candidate = hubMaps[name:lower()]
                if not candidate or (mapID and candidate ~= mapID) then return offered end
                mapID = candidate
            end
        end
    end
    local groups, singles = {}, {}
    for _, row in ipairs(byMap[mapID] or {}) do
        if not offered[row.item] and insideHub(s, mapID, row, names) then
            local skill = relevant(s, row)
            if skill then
                offered[row.item] = true
                local confirmed = row.kind == "book" or (s.missing and s.missing[row.spell])
                local title = (confirmed and "Buy " or "Check ") .. row.name .. " at " .. row.vendor
                local detail = row.vendor
                local waypoint
                if row.x and row.y then
                    detail = detail .. (" (%.1f, %.1f)"):format(row.x*100, row.y*100)
                    waypoint = ns.RecipeVendorTarget(row)
                end
                detail = detail .. ". " .. row.directions .. " Requires " .. row.profession .. " " .. row.skill .. "."
                if skill.rank < row.skill and confirmed then detail = detail .. " Buy ahead for your next skill-ups." end
                if row.kind == "book" then detail = detail .. " Raises your skill cap to " .. row.cap .. "." end
                if row.limited then detail = detail .. " Limited stock." end
                local market = ns.RecipeShoppingHint and ns.RecipeShoppingHint(s,row.item)
                if not confirmed then detail = detail .. " Open " .. row.profession .. " to confirm." end
                if market then detail = detail .. "\n" .. (confirmed and "" or "If unlearned · ") .. market end
                local item={title=title,detail=detail,row=row,pin=waypoint,market=market,confirmed=confirmed}
                if confirmed and waypoint then
                    local key=row.vendor..":"..mapID
                    groups[key]=groups[key] or {}
                    table.insert(groups[key],item)
                else
                    singles[#singles+1]=item
                end
            end
        end
    end
    for _,items in pairs(groups) do
        table.sort(items,function(a,b) return a.row.item<b.row.item end)
        if #items==1 then singles[#singles+1]=items[1]
        else
            local first=items[1]
            local lines={first.row.directions}
            local ids={}
            for _,item in ipairs(items) do
                ids[#ids+1]=item.row.item
                lines[#lines+1]=item.row.name.." ("..item.row.profession.." "..item.row.skill..")"
                    ..(item.row.limited and " - limited stock" or "")
                    ..(item.market and ("\n"..item.market) or "")
            end
            add("One visit to "..first.row.vendor.." ("..#items.." purchases)",table.concat(lines,"\n"),
                15,"vendor:"..first.row.vendor..":"..table.concat(ids,"-"),first.pin,true)
        end
    end
    for _,item in ipairs(singles) do
        add(item.title,item.detail,item.confirmed and 15 or 58,"vendor:"..item.row.vendor..":"..item.row.item,
            item.pin,item.confirmed)
    end
    return offered
end
