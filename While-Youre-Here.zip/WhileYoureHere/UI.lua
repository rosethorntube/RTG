local _, ns = ...

local panel, scroll, content, routeButton, snoozeButton, picker, choices, planButton
local fishingLocationCheck, alternativeButton, guideControls
local crafts = {Engineering=true,Blacksmithing=true,Tailoring=true,Leatherworking=true,Enchanting=true,Alchemy=true}
local function learnedCraft(selected)
    local s=ns.state
    return s and s.mode=="normal" and selected and crafts[selected] and s.skills and s.skills[selected]
end
local tab = "now"
local tabs, cards = {}, {}
local currentAdvice = {}
local refreshPending, initialised, rendering = false, false, false
local lastContent
local lastPositionCheck = 0
local frame = CreateFrame("Frame")
local backdrop = {
    bgFile = "Interface\\Buttons\\WHITE8X8",
    edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1,
}
local template = BackdropTemplateMixin and "BackdropTemplate" or nil
local routeOrder = { "auto", "camp", "boat", "leavebarrens" }
local routeLabels = { auto = "Automatic", camp = "Camp Mojache", boat = "Boat crossing", leavebarrens = "Leaving the Barrens" }

local function style(f, r, g, b, alpha)
    if not f.SetBackdrop then return end
    f:SetBackdrop(backdrop)
    f:SetBackdropColor(r, g, b, alpha or 1)
    f:SetBackdropBorderColor(0.4, 0.32, 0.17, 0.95)
end

local function textLabel(parent, font, text)
    local label = parent:CreateFontString(nil, "OVERLAY", font)
    label:SetText(text)
    label:SetJustifyH("LEFT")
    label:SetJustifyV("TOP")
    return label
end

local function button(parent, text, width, height, action)
    local b = CreateFrame("Button", nil, parent, template)
    b:SetSize(width, height)
    style(b, 0.12, 0.115, 0.095)
    b.label = textLabel(b, "GameFontNormalSmall", text)
    b.label:SetPoint("CENTER")
    b:SetHighlightTexture("Interface\\Buttons\\UI-Listbox-Highlight2", "ADD")
    b:SetScript("OnClick", action)
    return b
end

local function movable(f, handle, key)
    f:SetMovable(true)
    f:SetClampedToScreen(true)
    handle:EnableMouse(true)
    handle:RegisterForDrag("LeftButton")
    handle:SetScript("OnDragStart", function() f:StartMoving() end)
    handle:SetScript("OnDragStop", function()
        f:StopMovingOrSizing()
        ns.SaveWindowPosition(f, key)
    end)
end

local function waypointTarget(item)
    if (item.key or ""):match("^dungeon:pickup:") then return end
    local t = item.target
    if type(t) ~= "table" or not t.mapID or type(t.x) ~= "number" or type(t.y) ~= "number" then return end
    local vendor=ns.VendorNavigationTarget(item)
    if vendor and ns.AdvisorMap.key(vendor)==ns.AdvisorMap.key(t) then return end
    if not C_Map or not C_Map.SetUserWaypoint or not UiMapPoint or not UiMapPoint.CreateFromCoordinates then return end
    if C_Map.CanSetUserWaypointOnMap and not C_Map.CanSetUserWaypointOnMap(t.mapID) then return end
    return t
end

local function placePin(self)
    local t = self.target
    if not t then return end
    local ok = pcall(C_Map.SetUserWaypoint, UiMapPoint.CreateFromCoordinates(t.mapID, t.x, t.y))
    if ok and C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
        pcall(C_SuperTrack.SetSuperTrackedUserWaypoint, true)
    end
end

local function draw(items)
    local width = math.max(150, scroll:GetWidth() - 5)
    local signature = {tab, tostring(math.floor(width)), tostring(#items)}
    local groups,byRow=ns.PickupGroups(items)
    for _, item in ipairs(items) do
        signature[#signature + 1] = (item.title or "") .. "\n" .. (item.body or "")
        local giver=byRow[item]
        if giver then
            local map=ns.AdvisorMap
            signature[#signature+1]=table.concat({item.key,giver,tostring(map.getIsMarked(item.target)),
                tostring(map.isTarget(item.target)),tostring(map.waypointAvailable(item.target))},"|")
        else
            local vendor=ns.VendorNavigationTarget(item)
            if vendor then
                local map=ns.AdvisorMap
                signature[#signature+1]=map.key(vendor).."|"..tostring(map.isTarget(vendor,"vendor"))
            end
        end
        local target = waypointTarget(item)
        if target then signature[#signature + 1] = target.mapID .. ":" .. target.x .. ":" .. target.y end
    end
    local key = table.concat(signature, "\t")
    if key == lastContent then return end
    lastContent = key
    content:SetWidth(width)
    local y = 0
    if #items == 0 then
        items = {{title = "All caught up", body = tab == "fishing" and "No fish in the guide found in your bags. Open All fish to look up a recipe." or "There are no suggestions for this view yet."}}
    end
    for i, item in ipairs(items) do
        local card = cards[i]
        if not card then
            card = CreateFrame("Frame", nil, content)
            card.title = textLabel(card, "GameFontNormal", "")
            card.title:SetTextColor(1, 0.78, 0.40)
            card.title:SetPoint("TOPLEFT")
            card.body = textLabel(card, "GameFontHighlightSmall", "")
            card.body:SetPoint("TOPLEFT", card.title, "BOTTOMLEFT", 0, -4)
            card.pin = button(card, "Pin", 34, 18, placePin)
            card.pin:SetPoint("TOPRIGHT")
            ns.CreatePickupControls(card,function() ns.RequestRefresh() end)
            cards[i] = card
        end
        card:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -y)
        card:SetWidth(width)
        local target = waypointTarget(item)
        card.pin.target = target
        if target then card.pin:Show() else card.pin:Hide() end
        card.title:SetWidth(width - (target and 42 or 2))
        card.title:SetText(item.title or "")
        card.body:SetWidth(width - 2)
        card.body:SetText(item.body or "")
        local height = math.max(18, card.title:GetStringHeight()) + 4 + card.body:GetStringHeight() + 14
        local giver=byRow[item]
        if ns.UpdatePickupControls(card,item,giver,groups[giver],height-8) then
            height=height+26
        end
        card:SetHeight(height)
        card:Show()
        y = y + height
    end
    for i = #items + 1, #cards do cards[i]:Hide() end
    content:SetHeight(math.max(1, y))
    scroll:UpdateScrollChildRect()
    if scroll:GetVerticalScroll() > scroll:GetVerticalScrollRange() then
        scroll:SetVerticalScroll(scroll:GetVerticalScrollRange())
    end
end

local function refresh()
    if not initialised or rendering then return end
    rendering = true
    local record = ns.CurrentRecord()
    if record then
        record.seenAlerts = record.seenAlerts or {}
        currentAdvice = ns.GetAdvice("now") or {}
        ns.RefreshTips(currentAdvice)
        if panel:IsShown() then
            routeButton.label:SetText("Route: " .. (routeLabels[record.destination] or routeLabels.auto))
            snoozeButton.label:SetText((ns.DB().settings.snoozeUntil or 0) > time() and "Unsnooze" or "Snooze 10m")
            guideControls.update(tab)
            if tab=="professions" then
                local selected=ns.DB().settings.professionFilter
                picker.label:SetText(selected or "All professions")
                picker:Show()
                if selected then
                    local planned=record.plannedProfessions and record.plannedProfessions[selected]
                    if learnedCraft(selected) then
                        planButton.label:SetText(ns.CraftIsFocus(ns.state,selected) and "Release materials" or "Reserve materials")
                    else
                        planButton.label:SetText(planned and "Remove from my plan" or "Plan on this character")
                    end
                    planButton:SetShown(not learnedCraft(selected) or ns.CraftFocusGoal(ns.state,selected)~=nil)
                else planButton:Hide() end
            else
                picker:Hide()
                choices:Hide()
                planButton:Hide()
            end
            if tab=="fishing" then
                local enabled=ns.FeatureEnabled("fishing")
                local locationEnabled = ns.FeatureEnabled("fishingLocation")
                fishingLocationCheck:SetChecked(locationEnabled)
                fishingLocationCheck:SetEnabled(enabled)
                fishingLocationCheck.label:SetAlpha(enabled and 1 or 0.55)
                fishingLocationCheck:Show()
                local skills = ns.state and ns.state.skills or {}
                local alternatives = enabled and locationEnabled and skills.Fishing and skills.Cooking
                    and ns.HybridFoodAlternatives(ns.state)
                if alternatives and #alternatives >= 2 then
                    alternativeButton.label:SetText("Alternative: " .. alternatives[1].label)
                    local available = panel:GetWidth() - 61 - fishingLocationCheck.label:GetStringWidth()
                    alternativeButton:SetWidth(math.min(170, available))
                    alternativeButton:Show()
                else
                    alternativeButton:Hide()
                end
            else
                fishingLocationCheck:Hide()
                alternativeButton:Hide()
            end
            for name, b in pairs(tabs) do
                if name == tab then b.label:SetTextColor(1, 0.85, 0.48) else b.label:SetTextColor(0.73, 0.71, 0.65) end
            end
            draw(tab == "now" and currentAdvice or (ns.GetAdvice(tab) or {}))
        end
    end
    rendering = false
end

local function selectTab(name)
    tab=name
    ns.DB().settings.advisorTab=name
    choices:Hide()
    guideControls.close()
    scroll:ClearAllPoints()
    local extraRow=tab=="professions" or tab=="alts" or tab=="skip" or tab=="now"
    scroll:SetPoint("TOPLEFT",14,tab=="fishing" and -121 or (extraRow and -96 or -71))
    scroll:SetPoint("BOTTOMRIGHT",-32,48)
    scroll:SetVerticalScroll(0)
    refresh()
end

function ns.FullAdvisorShown()
    return panel and panel:IsShown()
end

function ns.OpenFullAdvisor(name)
    panel:Show()
    local selected=name or ns.DB().settings.advisorTab
    selectTab((tabs[selected] or selected=="skip") and selected or "now")
end

local renderPending = false
function ns.RequestRefresh()
    if renderPending or not initialised then return end
    renderPending = true
    local function run()
        renderPending = false
        refresh()
    end
    if C_Timer and C_Timer.After then C_Timer.After(0.15, run) else run() end
end

local function cycleRoute()
    local r = ns.CurrentRecord()
    if not r then return end
    local current = r.destination or "auto"
    local nextRoute = "auto"
    for i, name in ipairs(routeOrder) do
        if name == current then
            nextRoute=routeOrder[i % #routeOrder + 1]
            if nextRoute=="camp" and ns.AdvisorFaction(ns.state)~="Horde" then nextRoute="boat" end
            break
        end
    end
    if nextRoute == "auto" then r.destination = nil else r.destination = nextRoute end
    ns.RefreshPosition()
    refresh()
end

local function snooze()
    local settings = ns.DB().settings
    if (settings.snoozeUntil or 0) > time() then
        settings.snoozeUntil = nil
    else
        settings.snoozeUntil = time() + 600
    end
    refresh()
end

local function makeFrames()
    ns.CreateTipUI()
    panel = CreateFrame("Frame", nil, UIParent, template)
    panel:SetFrameStrata("DIALOG")
    panel:EnableMouse(true)
    panel:SetResizable(true)
    if panel.SetResizeBounds then panel:SetResizeBounds(365, 240, 820, 850)
    elseif panel.SetMinResize then panel:SetMinResize(365, 240) end
    local settings = ns.DB().settings
    panel:SetSize(settings.width or 430, settings.height or 395)
    ns.RestoreWindowPosition(panel, "panel", "CENTER", 140, 40)
    style(panel, 0.055, 0.059, 0.055, 0.97)
    panel:Hide()
    local handle = CreateFrame("Frame", nil, panel)
    handle:SetPoint("TOPLEFT", 1, -1)
    handle:SetPoint("TOPRIGHT", -36, -1)
    handle:SetHeight(33)
    movable(panel, handle, "panel")
    local title = textLabel(handle, "GameFontNormalLarge", ns.title)
    title:SetPoint("LEFT", 12, 0)
    local close = button(panel, "X", 24, 22, function() panel:Hide() end)
    close:SetPoint("TOPRIGHT", -8, -6)
    local names = {{"now", "Now", 42}, {"professions","Professions",80}, {"alts","Alts",39},
        {"fishing","Fishing",55}, {"catalog","All fish",56}}
    local prev
    for _, entry in ipairs(names) do
        local name = entry[1]
        local b = button(panel, entry[2], entry[3], 23, function()
            selectTab(name)
        end)
        if prev then b:SetPoint("LEFT", prev, "RIGHT", 4, 0) else b:SetPoint("TOPLEFT", 12, -36) end
        tabs[name], prev = b, b
    end

    scroll = CreateFrame("ScrollFrame", nil, panel, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 14, -71)
    scroll:SetPoint("BOTTOMRIGHT", -32, 48)
    content = CreateFrame("Frame", nil, scroll)
    content:SetSize(330, 1)
    scroll:SetScrollChild(content)
    picker=button(panel,"All professions",150,23,function()
        if choices:IsShown() then choices:Hide() else choices:Show() end
    end)
    picker:SetPoint("TOPLEFT",12,-65)
    picker:Hide()
    planButton=button(panel,"Plan on this character",151,23,function()
        local selected=ns.DB().settings.professionFilter
        local record=ns.CurrentRecord()
        if not record or not selected then return end
        if learnedCraft(selected) then ns.ToggleCraftFocus(ns.state,selected);refresh();return end
        record.plannedProfessions=record.plannedProfessions or {}
        record.plannedProfessions[selected]=not record.plannedProfessions[selected] or nil
        refresh()
    end)
    planButton:SetPoint("LEFT",picker,"RIGHT",5,0)
    planButton:Hide()
    fishingLocationCheck=CreateFrame("CheckButton",nil,panel,"UICheckButtonTemplate")
    fishingLocationCheck:SetSize(25,25)
    fishingLocationCheck:SetPoint("TOPLEFT",12,-64)
    fishingLocationCheck.label=textLabel(fishingLocationCheck,"GameFontHighlightSmall","Where should I fish?")
    fishingLocationCheck.label:SetPoint("LEFT",fishingLocationCheck,"RIGHT",2,0)
    fishingLocationCheck:SetHitRectInsets(0,-(fishingLocationCheck.label:GetStringWidth()+6),0,0)
    fishingLocationCheck:SetScript("OnClick",function(self)
        if ns.FeatureEnabled("fishing") then
            ns.SetFeatureEnabled("fishingLocation",self:GetChecked() and true or false)
        end
    end)
    fishingLocationCheck:Hide()
    alternativeButton = button(panel, "", 170, 22, function()
        ns.CycleHybridFood(ns.state)
    end)
    alternativeButton:SetPoint("LEFT", fishingLocationCheck.label, "RIGHT", 10, 0)
    alternativeButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Click to cycle the alternative food recommendation.")
        GameTooltip:Show()
    end)
    alternativeButton:SetScript("OnLeave", function() GameTooltip:Hide() end)
    alternativeButton:Hide()
    choices=CreateFrame("Frame",nil,panel,template)
    choices:SetSize(284,180)
    choices:SetPoint("TOPLEFT",picker,"BOTTOMLEFT",0,-2)
    choices:SetFrameStrata("FULLSCREEN_DIALOG")
    choices:EnableMouse(true)
    style(choices,0.07,0.075,0.067,1)
    local filters={"All professions"}
    for _,prof in ipairs(ns.PanelProfessions or {}) do filters[#filters+1]=prof end
    for i,label in ipairs(filters) do
        local prof=label
        local choice=button(choices,label,133,22,function()
            ns.DB().settings.professionFilter=prof~="All professions" and prof or nil
            selectTab("professions")
        end)
        choice:SetPoint("TOPLEFT",6+((i-1)%2)*139,-5-math.floor((i-1)/2)*25)
    end
    choices:Hide()
    guideControls=ns.CreateGuideControls(panel,button,style,template,selectTab,refresh)
    panel:SetScript("OnHide",function() choices:Hide();guideControls.close() end)
    routeButton = button(panel, "Route: Automatic", 159, 23, cycleRoute)
    routeButton:SetPoint("BOTTOMLEFT", 12, 10)
    snoozeButton = button(panel, "Snooze 10m", 81, 23, snooze)
    snoozeButton:SetPoint("LEFT", routeButton, "RIGHT", 5, 0)

    local grip = CreateFrame("Button", nil, panel)
    grip:SetSize(18, 18)
    grip:SetPoint("BOTTOMRIGHT", -2, 2)
    grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    grip:SetScript("OnMouseDown", function(_, which)
        if which == "LeftButton" then panel:StartSizing("BOTTOMRIGHT") end
    end)
    grip:SetScript("OnMouseUp", function()
        panel:StopMovingOrSizing()
        settings.width, settings.height = panel:GetWidth(), panel:GetHeight()
        ns.SaveWindowPosition(panel, "panel")
        refresh()
    end)
    panel:SetScript("OnSizeChanged", function() if panel:IsShown() then refresh() end end)
end

local function scan()
    refreshPending = false
    if not initialised then return end
    ns.Collect()
    refresh()
end

local function queueScan()
    if refreshPending then return end
    refreshPending = true
    if C_Timer and C_Timer.After then
        C_Timer.After(0.25, scan)
    else
        scan()
    end
end

local function start()
    if initialised then return end
    ns.Collect()
    makeFrames()
    initialised = true
    refresh()
end

frame:SetScript("OnEvent", function(_, event, eventArg)
    if event == "PLAYER_SPECIALIZATION_CHANGED" and eventArg and eventArg ~= "player" then return end
    if event=="NEW_RECIPE_LEARNED" then ns.ObserveRecipeLearned(eventArg) end
    if event == "PLAYER_LOGIN" or event == "QUEST_QUERY_COMPLETE" or event == "QUEST_TURNED_IN" then
        ns.DungeonQuestHistory(event, eventArg)
    end
    if event == "PLAYER_LOGIN" then start()
    elseif event == "PLAYER_LOGOUT" then
        if initialised then ns.Collect() end
    elseif initialised then queueScan() end
end)
for _, event in ipairs({
    "PLAYER_LOGIN", "PLAYER_LOGOUT", "PLAYER_ENTERING_WORLD", "ZONE_CHANGED",
    "ZONE_CHANGED_INDOORS", "ZONE_CHANGED_NEW_AREA", "BAG_UPDATE_DELAYED",
    "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "ACHIEVEMENT_EARNED",
    "CHARACTER_POINTS_CHANGED", "PLAYER_TALENT_UPDATE", "ACTIVE_TALENT_GROUP_CHANGED",
    "PLAYER_SPECIALIZATION_CHANGED", "TRAIT_CONFIG_UPDATED",
    "QUEST_LOG_UPDATE", "QUEST_ACCEPTED", "QUEST_REMOVED", "QUEST_TURNED_IN", "QUEST_QUERY_COMPLETE",
    "GOSSIP_SHOW", "GOSSIP_CLOSED",
    "BAG_UPDATE", "SKILL_LINES_CHANGED", "TRADE_SKILL_SHOW", "TRADE_SKILL_UPDATE",
    "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_DATA_SOURCE_CHANGED", "CRAFT_SHOW", "CRAFT_UPDATE",
    "NEW_RECIPE_LEARNED", "PLAYER_LEVEL_UP", "MERCHANT_CLOSED", "BANKFRAME_OPENED", "BANKFRAME_CLOSED",
    "PLAYERBANKSLOTS_CHANGED", "PLAYERBANKBAGSLOTS_CHANGED",
}) do
    pcall(frame.RegisterEvent, frame, event)
end

frame:SetScript("OnUpdate", function(_, elapsed)
    if not initialised then return end
    lastPositionCheck = lastPositionCheck + elapsed
    if lastPositionCheck < 5 then return end
    lastPositionCheck = 0
    ns.RefreshPosition()
    refresh()
end)

local advisorTabs = {now="now", professions="professions", alts="alts", roster="alts", fishing="fishing", skip="skip"}
SLASH_WHILEYOUREHERE1 = "/wyh"
SlashCmdList.WHILEYOUREHERE = function(input)
    if not initialised then start() end
    local command, args = (input or ""):match("^%s*(%S*)%s*(.-)%s*$")
    command = command:lower()
    if command == "" or command == "settings" then
        ns.OpenTipOptions()
    elseif advisorTabs[command] then
        ns.OpenFullAdvisor(advisorTabs[command])
    elseif command == "price" then
        ns.MarketCommand(args)
    elseif command == "fish" then
        ns.FishingCommand(args)
    else
        print(ns.title.." - /wyh opens settings. Tabs: /wyh now, /wyh professions, /wyh alts, /wyh fishing, /wyh skip.")
        print("Fishing controls: /wyh fish on|off|reset. Prices: /wyh price <item ID or link> <unit price> or /wyh price market faction|neutral|auto.")
    end
end

if IsLoggedIn and IsLoggedIn() and C_Timer and C_Timer.After then
    C_Timer.After(0, start)
end
