local _, ns = ...

local panel, scroll, content, routeButton, snoozeButton, picker, choices, planButton, nextStepsButton, materialsButton
local fishingLocationCheck, alternativeButton, guideControls
local crafts = {Engineering=true,Blacksmithing=true,Tailoring=true,Leatherworking=true,Enchanting=true,Alchemy=true}
local function learnedCraft(selected)
    local s=ns.state
    return s and s.mode=="normal" and selected and crafts[selected] and s.skills and s.skills[selected]
end
local tab = "now"
local tabs, cards = {}, {}
local currentAdvice = {}
local refreshPending, initialised, rendering = false, false, false
local lastContent
local lastPositionCheck = 0
local frame = CreateFrame("Frame")
local backdrop = {
    bgFile = "Interface\\Buttons\\WHITE8X8",
    edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1,
}
local template = BackdropTemplateMixin and "BackdropTemplate" or nil
local routeOrder = { "auto", "camp", "boat", "leavebarrens" }
local routeLabels = { auto = "Automatic", camp = "Camp Mojache", boat = "Boat crossing", leavebarrens = "Leaving the Barrens" }
local button = ns.CreateGuideButton

local function inProfessions()
    return tab=="professions" or tab=="materials"
end

local function style(f, r, g, b, alpha)
    if not f.SetBackdrop then return end
    f:SetBackdrop(backdrop)
    f:SetBackdropColor(r, g, b, alpha or 1)
    f:SetBackdropBorderColor(.49, .39, .245, .95)
end

local function textLabel(parent, font, text)
    local label = parent:CreateFontString(nil, "OVERLAY", font)
    label:SetText(text)
    label:SetJustifyH("LEFT")
    label:SetJustifyV("TOP")
    return label
end

local function divider(parent,y)
    local line=parent:CreateTexture(nil,"BORDER")
    if y<0 then
        line:SetPoint("TOPLEFT",12,y)
        line:SetPoint("TOPRIGHT",-12,y)
    else
        line:SetPoint("BOTTOMLEFT",12,y)
        line:SetPoint("BOTTOMRIGHT",-12,y)
    end
    line:SetHeight(1)
    line:SetColorTexture(.53,.41,.245,.5)
end

local function movable(f, handle, key)
    f:SetMovable(true)
    f:SetClampedToScreen(true)
    handle:EnableMouse(true)
    handle:RegisterForDrag("LeftButton")
    handle:SetScript("OnDragStart", function() f:StartMoving() end)
    handle:SetScript("OnDragStop", function()
        f:StopMovingOrSizing()
        ns.SaveWindowPosition(f, key)
    end)
end

local function waypointTarget(item)
    if (item.key or ""):match("^dungeon:pickup:") then return end
    local t = item.target
    if type(t) ~= "table" or not t.mapID or type(t.x) ~= "number" or type(t.y) ~= "number" then return end
    local vendor=ns.VendorNavigationTarget(item)
    if vendor and ns.AdvisorMap.key(vendor)==ns.AdvisorMap.key(t) then return end
    if not C_Map or not C_Map.SetUserWaypoint or not UiMapPoint or not UiMapPoint.CreateFromCoordinates then return end
    if C_Map.CanSetUserWaypointOnMap and not C_Map.CanSetUserWaypointOnMap(t.mapID) then return end
    return t
end

local function placePin(self)
    local t = self.target
    if not t then return end
    local ok = pcall(C_Map.SetUserWaypoint, UiMapPoint.CreateFromCoordinates(t.mapID, t.x, t.y))
    if ok and C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
        pcall(C_SuperTrack.SetSuperTrackedUserWaypoint, true)
    end
end

local function draw(items)
    local width = math.max(150, scroll:GetWidth() - 5)
    local signature = {tab, tostring(math.floor(width)), tostring(#items)}
    local groups,byRow=ns.PickupGroups(items)
    for _, item in ipairs(items) do
        signature[#signature + 1] = (item.title or "") .. "\n" .. (item.body or "")
        local giver=byRow[item]
        if giver then
            local map=ns.AdvisorMap
            signature[#signature+1]=table.concat({item.key,giver,tostring(map.getIsMarked(item.target)),
                tostring(map.isTarget(item.target)),tostring(map.waypointAvailable(item.target))},"|")
        else
            local vendor=ns.VendorNavigationTarget(item)
            if vendor then
                local map=ns.AdvisorMap
                signature[#signature+1]=map.key(vendor).."|"..tostring(map.isTarget(vendor,"vendor"))
            end
        end
        local target = waypointTarget(item)
        if target then signature[#signature + 1] = target.mapID .. ":" .. target.x .. ":" .. target.y end
    end
    local key = table.concat(signature, "\t")
    if key == lastContent then return end
    lastContent = key
    content:SetWidth(width)
    local y = 0
    if #items == 0 then
        items = {{title = "All caught up", body = tab == "fishing" and "No fish in the guide found in your bags. Open All fish to look up a recipe." or "There are no suggestions for this view yet."}}
    end
    for i, item in ipairs(items) do
        local card = cards[i]
        if not card then
            card = CreateFrame("Frame", nil, content)
            card.wash=card:CreateTexture(nil,"BACKGROUND")
            card.wash:SetAllPoints(card)
            card.edge=card:CreateTexture(nil,"ARTWORK")
            card.edge:SetPoint("TOPLEFT",0,-1)
            card.edge:SetPoint("BOTTOMLEFT",0,1)
            card.edge:SetWidth(2)
            card.title = textLabel(card, "GameFontNormal", "")
            card.title:SetTextColor(1,.845,.57)
            card.title:SetWordWrap(true)
            card.title:SetPoint("TOPLEFT",11,-9)
            card.body = textLabel(card, "GameFontHighlight", "")
            card.body:SetTextColor(.92,.90,.84)
            card.body:SetWordWrap(true)
            card.body:SetPoint("TOPLEFT", card.title, "BOTTOMLEFT", 0, -6)
            card.pin = ns.CreateGuideButton(card, "Pin", 36, 20, placePin)
            card.pin:SetPoint("TOPRIGHT",-8,-7)
            ns.AdvisorTooltip(card.pin,"Pin","Set and track this location on your world map.")
            ns.CreatePickupControls(card,function() ns.RequestRefresh() end)
            cards[i] = card
        end
        card:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -y)
        card:SetWidth(width)
        if i==1 then
            card.wash:SetColorTexture(.145,.144,.108,.75)
            card.edge:SetColorTexture(.72,.52,.26,.90)
        else
            card.wash:SetColorTexture(.10,.115,.102,.83)
            card.edge:SetColorTexture(.64,.49,.28,.42)
        end
        local target = waypointTarget(item)
        card.pin.target = target
        if target then card.pin:Show() else card.pin:Hide() end
        card.title:SetWidth(width - (target and 59 or 22))
        card.title:SetText(item.title or "")
        card.body:SetWidth(width - 22)
        card.body:SetText(item.body or "")
        local height = 9 + math.max(18,card.title:GetStringHeight()) + 6 + card.body:GetStringHeight() + 9
        local giver=byRow[item]
        if ns.UpdatePickupControls(card,item,giver,groups[giver],height-3,11) then
            height=height+28
        end
        card:SetHeight(height)
        card:Show()
        y = y + height + 7
    end
    for i = #items + 1, #cards do cards[i]:Hide() end
    content:SetHeight(math.max(1, y-7))
    scroll:UpdateScrollChildRect()
    if scroll:GetVerticalScroll() > scroll:GetVerticalScrollRange() then
        scroll:SetVerticalScroll(scroll:GetVerticalScrollRange())
    end
end

local function refresh()
    if not initialised or rendering then return end
    rendering = true
    local record = ns.CurrentRecord()
    if record then
        record.seenAlerts = record.seenAlerts or {}
        currentAdvice = ns.GetAdvice("now") or {}
        ns.RefreshTips(currentAdvice)
        if panel:IsShown() then
            routeButton.label:SetText("Route: " .. (routeLabels[record.destination] or routeLabels.auto))
            snoozeButton.label:SetText((ns.DB().settings.snoozeUntil or 0) > time() and "Unsnooze" or "Snooze 10m")
            guideControls.update(tab)
            local professions=inProfessions()
            nextStepsButton:SetShown(professions)
            materialsButton:SetShown(professions)
            ns.SetGuideButtonSelected(nextStepsButton,tab=="professions")
            ns.SetGuideButtonSelected(materialsButton,tab=="materials")
            if professions then
                local selected=ns.DB().settings.professionFilter
                picker.label:SetText(selected or "All professions")
                picker:Show()
                if selected and tab=="professions" then
                    local planned=record.plannedProfessions and record.plannedProfessions[selected]
                    if learnedCraft(selected) then
                        planButton.label:SetText(ns.CraftIsFocus(ns.state,selected) and "Release materials" or "Reserve materials")
                    else
                        planButton.label:SetText(planned and "Remove from my plan" or "Plan on this character")
                    end
                    planButton:SetShown(not learnedCraft(selected) or ns.CraftFocusGoal(ns.state,selected)~=nil)
                else planButton:Hide() end
            else
                picker:Hide()
                choices:Hide()
                planButton:Hide()
            end
            if tab=="fishing" then
                local enabled=ns.FeatureEnabled("fishing")
                local locationEnabled = ns.FeatureEnabled("fishingLocation")
                fishingLocationCheck:SetChecked(locationEnabled)
                fishingLocationCheck:SetEnabled(enabled)
                fishingLocationCheck.label:SetAlpha(enabled and 1 or 0.55)
                fishingLocationCheck:Show()
                local skills = ns.state and ns.state.skills or {}
                local alternatives = enabled and locationEnabled and skills.Fishing and skills.Cooking
                    and ns.HybridFoodAlternatives(ns.state)
                if alternatives and #alternatives >= 2 then
                    alternativeButton.label:SetText("Alternative: " .. alternatives[1].label)
                    local available = panel:GetWidth() - 61 - fishingLocationCheck.label:GetStringWidth()
                    alternativeButton:SetWidth(math.min(170, available))
                    alternativeButton:Show()
                else
                    alternativeButton:Hide()
                end
            else
                fishingLocationCheck:Hide()
                alternativeButton:Hide()
            end
            for name,b in pairs(tabs) do
                ns.SetGuideButtonSelected(b,name==tab or (professions and name=="professions") or (tab=="skip" and name=="now"))
            end
            draw(tab == "now" and currentAdvice or (ns.GetAdvice(tab) or {}))
        end
    end
    rendering = false
end

local function selectTab(name)
    tab=name
    ns.DB().settings.advisorTab=name
    choices:Hide()
    guideControls.close()
    scroll:ClearAllPoints()
    local extraRow=tab=="alts" or tab=="skip" or tab=="now"
    local scrollTop=inProfessions() and -125 or tab=="fishing" and -121 or (extraRow and -96 or -71)
    scroll:SetPoint("TOPLEFT",12,scrollTop)
    scroll:SetPoint("BOTTOMRIGHT",-32,47)
    scroll:SetVerticalScroll(0)
    refresh()
end

function ns.FullAdvisorShown()
    return panel and panel:IsShown()
end

function ns.OpenFullAdvisor(name)
    panel:Show()
    local selected=name or ns.DB().settings.advisorTab
    selectTab((tabs[selected] or selected=="skip" or selected=="materials") and selected or "now")
end

local renderPending = false
function ns.RequestRefresh()
    if renderPending or not initialised then return end
    renderPending = true
    local function run()
        renderPending = false
        refresh()
    end
    if C_Timer and C_Timer.After then C_Timer.After(0.15, run) else run() end
end

local function cycleRoute()
    local r = ns.CurrentRecord()
    if not r then return end
    local current = r.destination or "auto"
    local nextRoute = "auto"
    for i, name in ipairs(routeOrder) do
        if name == current then
            nextRoute=routeOrder[i % #routeOrder + 1]
            if nextRoute=="camp" and ns.AdvisorFaction(ns.state)~="Horde" then nextRoute="boat" end
            break
        end
    end
    if nextRoute == "auto" then r.destination = nil else r.destination = nextRoute end
    ns.RefreshPosition()
    refresh()
end

local function snooze()
    local settings = ns.DB().settings
    if (settings.snoozeUntil or 0) > time() then
        settings.snoozeUntil = nil
    else
        settings.snoozeUntil = time() + 600
    end
    refresh()
end

local function makeFrames()
    ns.CreateTipUI()
    panel = CreateFrame("Frame", nil, UIParent, template)
    panel:SetFrameStrata("DIALOG")
    panel:EnableMouse(true)
    panel:SetResizable(true)
    if panel.SetResizeBounds then panel:SetResizeBounds(365, 240, 820, 850)
    elseif panel.SetMinResize then panel:SetMinResize(365, 240) end
    local settings = ns.DB().settings
    panel:SetSize(settings.width or 430, settings.height or 395)
    ns.RestoreWindowPosition(panel, "panel", "CENTER", 140, 40)
    style(panel,.055,.066,.059,.98)
    panel:Hide()
    divider(panel,-31)
    divider(panel,41)
    local handle = CreateFrame("Frame", nil, panel)
    handle:SetPoint("TOPLEFT", 1, -1)
    handle:SetPoint("TOPRIGHT", -36, -1)
    handle:SetHeight(33)
    movable(panel, handle, "panel")
    local compass=handle:CreateTexture(nil,"ARTWORK")
    compass:SetTexture("Interface\\AddOns\\WhileYoureHere\\Icon")
    compass:SetSize(19,19)
    compass:SetPoint("LEFT",11,0)
    local title = textLabel(handle, "GameFontNormalLarge", ns.title)
    title:SetTextColor(1,.82,.49)
    title:SetPoint("LEFT",compass,"RIGHT",7,0)
    local close = button(panel, "X", 24, 22, function() panel:Hide() end)
    close:SetPoint("TOPRIGHT", -8, -6)
    ns.AdvisorTooltip(close,"Close Guide","Close the Guide. Click the rose compass to open it again.")
    local names = {
        {"now","Now",43,"See suggestions for your current location and activity."},
        {"professions","Professions",88,"Check your next skill-up or open Materials Needed to plan your next crafting milestone."},
        {"alts","Alts",41,"Compare recorded professions and Legacy Point goals across your characters."},
        {"fishing","Fishing",58,"Compare fishing spots, catches and foods for your build."},
        {"catalog","All fish",57,"Look up fish, Cooking recipes and recipe vendors."},
    }
    local prev
    for _, entry in ipairs(names) do
        local name = entry[1]
        local b = button(panel, entry[2], entry[3], 23, function()
            selectTab(name)
        end)
        if prev then b:SetPoint("LEFT", prev, "RIGHT", 4, 0) else b:SetPoint("TOPLEFT", 12, -36) end
        ns.AdvisorTooltip(b,entry[2],entry[4])
        tabs[name], prev = b, b
    end

    scroll = CreateFrame("ScrollFrame", nil, panel, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 14, -71)
    scroll:SetPoint("BOTTOMRIGHT", -32, 48)
    content = CreateFrame("Frame", nil, scroll)
    content:SetSize(330, 1)
    scroll:SetScrollChild(content)
    picker=button(panel,"All professions",150,23,function()
        if choices:IsShown() then choices:Hide() else choices:Show() end
    end)
    picker:SetPoint("TOPLEFT",12,-65)
    ns.AdvisorTooltip(picker,"Filter professions","Choose a profession or show all professions in this view.")
    picker:Hide()
    planButton=button(panel,"Plan on this character",151,23,function()
        local selected=ns.DB().settings.professionFilter
        local record=ns.CurrentRecord()
        if not record or not selected then return end
        if learnedCraft(selected) then ns.ToggleCraftFocus(ns.state,selected);refresh();return end
        record.plannedProfessions=record.plannedProfessions or {}
        record.plannedProfessions[selected]=not record.plannedProfessions[selected] or nil
        refresh()
    end)
    planButton:SetPoint("LEFT",picker,"RIGHT",5,0)
    ns.AdvisorTooltip(planButton,function() return planButton.label:GetText() end,function()
        local selected=ns.DB().settings.professionFilter
        if learnedCraft(selected) then
            if ns.CraftIsFocus(ns.state,selected) then
                return "Release this craft's priority on materials in recommendations for your characters."
            end
            return "Give this craft priority on recorded materials for its next unclaimed Legacy Point."
        end
        return "Add or remove this profession from this character's plan so the Guide can suggest training it."
    end)
    planButton:Hide()
    nextStepsButton=button(panel,"Next steps",89,22,function() selectTab("professions") end)
    nextStepsButton:SetPoint("TOPLEFT",12,-94)
    ns.AdvisorTooltip(nextStepsButton,"Next steps","See the next recipe, trainer or skill-up for your current rank.")
    nextStepsButton:Hide()
    materialsButton=button(panel,"Materials Needed",113,22,function() selectTab("materials") end)
    materialsButton:SetPoint("LEFT",nextStepsButton,"RIGHT",5,0)
    ns.AdvisorTooltip(materialsButton,"Materials Needed","Estimate what to use, craft or buy for your next crafting milestone.")
    materialsButton:Hide()
    fishingLocationCheck=CreateFrame("CheckButton",nil,panel,"UICheckButtonTemplate")
    fishingLocationCheck:SetSize(25,25)
    fishingLocationCheck:SetPoint("TOPLEFT",12,-64)
    fishingLocationCheck.label=textLabel(fishingLocationCheck,"GameFontHighlightSmall","Where should I fish?")
    fishingLocationCheck.label:SetPoint("LEFT",fishingLocationCheck,"RIGHT",2,0)
    fishingLocationCheck:SetHitRectInsets(0,-(fishingLocationCheck.label:GetStringWidth()+6),0,0)
    fishingLocationCheck:SetScript("OnClick",function(self)
        if ns.FeatureEnabled("fishing") then
            ns.SetFeatureEnabled("fishingLocation",self:GetChecked() and true or false)
        end
    end)
    ns.AdvisorTooltip(fishingLocationCheck,"Where should I fish?","Show recommended waters for your selected fishing goal.")
    fishingLocationCheck:Hide()
    alternativeButton = button(panel, "", 170, 22, function()
        ns.CycleHybridFood(ns.state)
    end)
    alternativeButton:SetPoint("LEFT", fishingLocationCheck.label, "RIGHT", 10, 0)
    ns.AdvisorTooltip(alternativeButton,"Alternative food","Switch to the alternative food recommendation for your character.")
    alternativeButton:Hide()
    choices=CreateFrame("Frame",nil,panel,template)
    choices:SetSize(284,180)
    choices:SetPoint("TOPLEFT",picker,"BOTTOMLEFT",0,-2)
    choices:SetFrameStrata("FULLSCREEN_DIALOG")
    choices:SetClampedToScreen(true)
    choices:EnableMouse(true)
    style(choices,0.07,0.075,0.067,1)
    local filters={"All professions"}
    for _,prof in ipairs(ns.PanelProfessions or {}) do filters[#filters+1]=prof end
    for i,label in ipairs(filters) do
        local prof=label
        local choice=button(choices,label,133,22,function()
            ns.DB().settings.professionFilter=prof~="All professions" and prof or nil
            selectTab(tab)
        end)
        choice:SetPoint("TOPLEFT",6+((i-1)%2)*139,-5-math.floor((i-1)/2)*25)
    end
    choices:Hide()
    guideControls=ns.CreateGuideControls(panel,button,style,template,selectTab,refresh)
    panel:SetScript("OnHide",function() choices:Hide();guideControls.close() end)
    routeButton = button(panel, "Route: Automatic", 159, 23, cycleRoute)
    routeButton:SetPoint("BOTTOMLEFT", 12, 10)
    ns.AdvisorTooltip(routeButton,function() return routeButton.label:GetText() end,function()
        local record=ns.CurrentRecord()
        if record and record.destination then
            return "Use the selected travel context to tailor suggestions. Click to cycle through the choices or return to Automatic."
        end
        return "Use your location and active RestedXP waypoint, if available, to tailor travel and profession tips. Click to cycle through manual route choices."
    end)
    snoozeButton = button(panel, "Snooze 10m", 81, 23, snooze)
    snoozeButton:SetPoint("LEFT", routeButton, "RIGHT", 5, 0)
    ns.AdvisorTooltip(snoozeButton,function() return snoozeButton.label:GetText() end,function()
        if (ns.DB().settings.snoozeUntil or 0)>time() then
            return "Resume alert pop-ups and the compass glow now."
        end
        return "Pause alert pop-ups and the compass glow for 10 minutes. Tips and the Guide can still be opened."
    end)

    local grip = CreateFrame("Button", nil, panel)
    grip:SetSize(18, 18)
    grip:SetPoint("BOTTOMRIGHT", -2, 2)
    grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    ns.AdvisorTooltip(grip,"Resize Guide","Drag to resize this window.")
    grip:SetScript("OnMouseDown", function(_, which)
        if which == "LeftButton" then panel:StartSizing("BOTTOMRIGHT") end
    end)
    grip:SetScript("OnMouseUp", function()
        panel:StopMovingOrSizing()
        settings.width, settings.height = panel:GetWidth(), panel:GetHeight()
        ns.SaveWindowPosition(panel, "panel")
        refresh()
    end)
    panel:SetScript("OnSizeChanged", function() if panel:IsShown() then refresh() end end)
end

local function scan()
    refreshPending = false
    if not initialised then return end
    ns.Collect()
    refresh()
end

local function queueScan()
    if refreshPending then return end
    refreshPending = true
    if C_Timer and C_Timer.After then
        C_Timer.After(0.25, scan)
    else
        scan()
    end
end

local function start()
    if initialised then return end
    ns.Collect()
    makeFrames()
    initialised = true
    refresh()
end

frame:SetScript("OnEvent", function(_, event, eventArg)
    if event == "PLAYER_SPECIALIZATION_CHANGED" and eventArg and eventArg ~= "player" then return end
    if event=="NEW_RECIPE_LEARNED" then ns.ObserveRecipeLearned(eventArg) end
    if event == "PLAYER_LOGIN" or event == "QUEST_QUERY_COMPLETE" or event == "QUEST_TURNED_IN" then
        ns.DungeonQuestHistory(event, eventArg)
    end
    if event == "PLAYER_LOGIN" then start()
    elseif event == "PLAYER_LOGOUT" then
        if initialised then ns.Collect() end
    elseif initialised then queueScan() end
end)
for _, event in ipairs({
    "PLAYER_LOGIN", "PLAYER_LOGOUT", "PLAYER_ENTERING_WORLD", "ZONE_CHANGED",
    "ZONE_CHANGED_INDOORS", "ZONE_CHANGED_NEW_AREA", "BAG_UPDATE_DELAYED",
    "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "ACHIEVEMENT_EARNED",
    "CHARACTER_POINTS_CHANGED", "PLAYER_TALENT_UPDATE", "ACTIVE_TALENT_GROUP_CHANGED",
    "PLAYER_SPECIALIZATION_CHANGED", "TRAIT_CONFIG_UPDATED",
    "QUEST_LOG_UPDATE", "QUEST_ACCEPTED", "QUEST_REMOVED", "QUEST_TURNED_IN", "QUEST_QUERY_COMPLETE",
    "GOSSIP_SHOW", "GOSSIP_CLOSED",
    "BAG_UPDATE", "SKILL_LINES_CHANGED", "TRADE_SKILL_SHOW", "TRADE_SKILL_UPDATE",
    "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_DATA_SOURCE_CHANGED", "CRAFT_SHOW", "CRAFT_UPDATE",
    "NEW_RECIPE_LEARNED", "PLAYER_LEVEL_UP", "MERCHANT_CLOSED", "BANKFRAME_OPENED", "BANKFRAME_CLOSED",
    "PLAYERBANKSLOTS_CHANGED", "PLAYERBANKBAGSLOTS_CHANGED",
}) do
    pcall(frame.RegisterEvent, frame, event)
end

frame:SetScript("OnUpdate", function(_, elapsed)
    if not initialised then return end
    lastPositionCheck = lastPositionCheck + elapsed
    if lastPositionCheck < 5 then return end
    lastPositionCheck = 0
    ns.RefreshPosition()
    refresh()
end)

local advisorTabs = {now="now", professions="professions", materials="materials", alts="alts", roster="alts", fishing="fishing", skip="skip"}
SLASH_WHILEYOUREHERE1 = "/wyh"
SlashCmdList.WHILEYOUREHERE = function(input)
    if not initialised then start() end
    local command, args = (input or ""):match("^%s*(%S*)%s*(.-)%s*$")
    command = command:lower()
    if command == "" or command == "settings" then
        ns.OpenTipOptions()
    elseif advisorTabs[command] then
        ns.OpenFullAdvisor(advisorTabs[command])
    elseif command == "price" then
        ns.MarketCommand(args)
    elseif command == "fish" then
        ns.FishingCommand(args)
    else
        print(ns.title.." - /wyh opens settings. Tabs: /wyh now, /wyh professions, /wyh materials, /wyh alts, /wyh fishing, /wyh skip.")
        print("Fishing controls: /wyh fish on|off|reset. Prices: /wyh price <item ID or link> <unit price> or /wyh price market faction|neutral|auto.")
    end
end

if IsLoggedIn and IsLoggedIn() and C_Timer and C_Timer.After then
    C_Timer.After(0, start)
end
