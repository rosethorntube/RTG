local _, ns = ...

-- Native shopping observations only. This module never starts a query or reads
-- prices from opening the AH, addon startup, inventories or a cached browse list.
local capitals = {
    [1453]="Alliance", [1455]="Alliance", [1457]="Alliance",
    [1454]="Horde", [1456]="Horde", [1458]="Horde",
}
local neutral = {
    [1434]={name="Booty Bay", x=0.277, y=0.754},
    [1446]={name="Gadgetzan", x=0.520, y=0.286},
    [1452]={name="Everlook", x=0.610, y=0.377},
}

function ns.GetNativeMarketVenue()
    local id = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
    if capitals[id] then return capitals[id] end
    local town = neutral[id]
    if not town then return end
    if (GetSubZoneText and GetSubZoneText()==town.name)
        or (GetMinimapZoneText and GetMinimapZoneText()==town.name) then return "Neutral" end
    local position = C_Map.GetPlayerMapPosition and C_Map.GetPlayerMapPosition(id, "player")
    if position and position.GetXY then
        local x,y = position:GetXY()
        if x and y and math.abs(x-town.x)<0.028 and math.abs(y-town.y)<0.028 then return "Neutral" end
    end
end

local function visible(frame)
    return frame and ((frame.IsVisible and frame:IsVisible()) or (not frame.IsVisible and frame.IsShown and frame:IsShown()))
end

local function sameKey(left,right)
    if type(left)~="table" or type(right)~="table" then return false end
    return left.itemID==right.itemID and (left.itemLevel or 0)==(right.itemLevel or 0)
        and (left.itemSuffix or 0)==(right.itemSuffix or 0)
        and (left.battlePetSpeciesID or 0)==(right.battlePetSpeciesID or 0)
end

local function buyQuery(kind)
    local frame=AuctionHouseFrame
    local context=AuctionHouseSearchContext and AuctionHouseSearchContext[kind]
    local query=context and frame and frame.activeSearches and frame.activeSearches[context]
    return query and query[2]
end

local function selectedCommodity(id)
    local pane = AuctionHouseFrame and AuctionHouseFrame.CommoditiesBuyFrame
    if not visible(pane) then return false end
    local selected=(pane.GetItemID and pane:GetItemID()) or pane.itemID
    local query=buyQuery("BuyCommodities")
    return (selected or (query and query.itemID))==id
end

local function selectedItem(key)
    local pane = AuctionHouseFrame and AuctionHouseFrame.ItemBuyFrame
    if not visible(pane) then return false end
    local selected=(pane.GetItemKey and pane:GetItemKey()) or pane.itemKey or buyQuery("BuyItems")
    return sameKey(selected,key)
end

local function plainItem(id)
    if (ns.fish and ns.fish[id]) or (ns.RecipeMarketFacts and ns.RecipeMarketFacts[id])
        or id == 6358 or id == 6359 or id == 16072 or id == 16083 then return true end
    local getInfo = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
    if getInfo then
        local _,_,_,_,_,classID = getInfo(id)
        -- Consumables, reagents, trade goods and recipes have no random gear suffixes.
        return classID==0 or classID==5 or classID==7 or classID==9
    end
    return false
end

local function newSample(batch,id,price,quantity,link)
    if type(id)~="number" or id<=0 or type(price)~="number" or price<=0
        or type(quantity)~="number" or quantity<1 then return end
    local identity
    if ns.MarketVariantKey then
        identity=ns.MarketVariantKey(id,link)
    elseif type(link)=="string" then
        identity=link:match("(item:[^|]+)")
    end
    local key = tostring(id).."|"..tostring(identity or "")
    local previous = batch[key]
    if previous then
        previous.price=math.min(previous.price,price)
        previous.units=previous.units+quantity
        previous.offers=previous.offers+1
    else
        batch[key]={id=id,price=price,units=quantity,offers=1,link=link}
    end
end

local maxRows=500
local function commodities(api,id,batch)
    if type(id)~="number" or not selectedCommodity(id)
        or not api.GetNumCommoditySearchResults or not api.GetCommoditySearchResultInfo then return end
    local n=api.GetNumCommoditySearchResults(id) or 0
    for i=1,math.min(n,maxRows) do
        local row=api.GetCommoditySearchResultInfo(id,i)
        if row then newSample(batch,id,row.unitPrice,row.quantity,nil) end
    end
    return "AH commodity offers"
end

local function items(api,key,batch)
    if type(key)~="table" or not selectedItem(key)
        or not api.GetNumItemSearchResults or not api.GetItemSearchResultInfo then return end
    local n=api.GetNumItemSearchResults(key) or 0
    for i=1,math.min(n,maxRows) do
        local row=api.GetItemSearchResultInfo(key,i)
        if row and (not row.itemKey or sameKey(row.itemKey,key)) and row.buyoutAmount and row.buyoutAmount>0
            and row.quantity and row.quantity>0 then
            local link=row.itemLink
            local linkedID=type(link)=="string" and tonumber(link:match("item:(%d+)"))
            if (linkedID==key.itemID) or (not link and (key.itemSuffix or 0)==0
                and (key.battlePetSpeciesID or 0)==0 and plainItem(key.itemID)) then
                newSample(batch,key.itemID,math.ceil(row.buyoutAmount/row.quantity),row.quantity,link)
            end
        end
    end
    return "AH item buyouts"
end

local function classicPage(batch)
    if not visible(AuctionFrameBrowse) or not GetNumAuctionItems or not GetAuctionItemInfo then return end
    local n=GetNumAuctionItems("list") or 0
    for i=1,math.min(n,maxRows) do
        local _,_,units,_,_,_,_,_,_,buyout,_,_,_,_,_,status,id=GetAuctionItemInfo("list",i)
        if units and units>0 and buyout and buyout>0 and (status==nil or status==0) then
            local link=GetAuctionItemLink and GetAuctionItemLink("list",i)
            local linkedID=type(link)=="string" and tonumber(link:match("item:(%d+)"))
            id=id or linkedID
            if id and (linkedID==id or (not link and plainItem(id))) then
                newSample(batch,id,math.ceil(buyout/units),units,link)
            end
        end
    end
    return "AH browse page buyouts"
end

local venue, previous
local observer=CreateFrame("Frame")
observer:SetScript("OnEvent",function(_,event,arg)
    if event=="AUCTION_HOUSE_SHOW" then
        venue,previous=ns.GetNativeMarketVenue(),{}
        return
    elseif event=="AUCTION_HOUSE_CLOSED" or event=="PLAYER_LEAVING_WORLD" then
        venue,previous=nil,nil
        return
    end
    if not venue or not ns.StoreMarketQuote or ns.GetNativeMarketVenue()~=venue then return end
    local api=C_AuctionHouse
    local batch,source={}
    if event=="COMMODITY_SEARCH_RESULTS_UPDATED" or event=="COMMODITY_SEARCH_RESULTS_ADDED" then
        if api then source=commodities(api,arg,batch) end
    elseif event=="ITEM_SEARCH_RESULTS_UPDATED" or event=="ITEM_SEARCH_RESULTS_ADDED" then
        if api then source=items(api,arg,batch) end
    elseif event=="AUCTION_ITEM_LIST_UPDATE" and not (api and api.GetNumItemSearchResults) then
        source=classicPage(batch)
    end
    if not source then return end
    local stamp=(GetServerTime and GetServerTime()) or time()
    for key,v in pairs(batch) do
        local old=previous[key]
        if not old or old.price~=v.price or old.units~=v.units or old.offers~=v.offers then
            ns.StoreMarketQuote(v.id,v.price,source,v.link,stamp,venue,v.units,v.offers)
            previous[key]=v
        end
    end
end)
for _,event in ipairs({
    "AUCTION_HOUSE_SHOW","AUCTION_HOUSE_CLOSED","PLAYER_LEAVING_WORLD","AUCTION_ITEM_LIST_UPDATE",
    "COMMODITY_SEARCH_RESULTS_UPDATED","COMMODITY_SEARCH_RESULTS_ADDED",
    "ITEM_SEARCH_RESULTS_UPDATED","ITEM_SEARCH_RESULTS_ADDED",
}) do
    pcall(observer.RegisterEvent,observer,event)
end
