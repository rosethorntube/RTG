local _, ns = ...
local requested = {}

-- Return value 14 is bind type. Value 11 is how much a merchant PAYS for
-- the item, and must never be used as the merchant's price to buy a recipe.
-- https://warcraft.wiki.gg/wiki/API_C_Item.GetItemInfo
local function clientTradeability(id)
    local info = (C_Item and C_Item.GetItemInfo) or GetItemInfo
    if not info then return end
    local name, _, _, _, _, _, _, _, _, _, _, _, _, binding = info(id)
    if name then
        requested[id] = nil
        if type(binding) == "number" then
            return binding == 0 or binding == 2 or binding == 3 -- unbound, BoE, BoU
        end
        -- Older clients may return a cached name without a binding field.
    elseif C_Item and C_Item.RequestLoadItemDataByID then
        local now = GetTime and GetTime() or 0
        if not requested[id] or now - requested[id] >= 30 then
            requested[id] = now
            C_Item.RequestLoadItemDataByID(id)
        end
        -- The existing guide refresh picks up the result, including when
        -- multiple rows have asked for the same item.
    end
end

local function copperAmount(n)
    if type(n) == "number" and n > 0 and n < math.huge then
        local whole = math.floor(n + 0.5)
        if whole > 0 then return whole end
    end
end

local function coins(n)
    local gold, silver, copper = math.floor(n / 10000), math.floor(n / 100) % 100, n % 100
    local units = {}
    if gold > 0 then units[#units+1] = gold .. "g" end
    if silver > 0 then units[#units+1] = silver .. "s" end
    if copper > 0 then units[#units+1] = copper .. "c" end
    return table.concat(units, " ")
end

-- Binding is independent of the character's market or inventory, so it can
-- also support an offline alt's row without quoting the logged-in realm.
function ns.RecipeAHTradeable(id)
    if not (type(id) == "number" and id > 0 and id < math.huge and id == math.floor(id)) then return end
    local facts = ns.RecipeMarketFacts and ns.RecipeMarketFacts[id]
    if facts and facts.tradeable == false then return false end
    local tradeable = clientTradeability(id)
    if tradeable == nil and facts then tradeable = facts.tradeable end
    return tradeable
end

-- The item is the scroll/book, not the spell it teaches or its crafted result.
-- Quotes are cached *unit purchase* observations. No seller's cut applies.
function ns.RecipeShoppingHint(state, id, vendorBaseCopper)
    if not state or not ns.RecipeAHTradeable(id) then return end
    if ns.RecipeItemHeld and ns.RecipeItemHeld(state, id) then return end
    local facts = ns.RecipeMarketFacts and ns.RecipeMarketFacts[id]

    local base = copperAmount(vendorBaseCopper) or copperAmount(facts and facts.price)
    local price, age, source
    if ns.MarketQuote then price, age, source = ns.MarketQuote(id, nil, true) end
    price = copperAmount(price)
    if (source ~= "Auctionator" and source ~= "native") or not price then
        return base and ("Base vendor " .. coins(base) .. ". Check AH listings.") or "Check AH listings."
    end
    local text = "AH estimate " .. coins(price)
    local ageLabel
    if type(age) == "number" and age >= 7 and age < math.huge then
        ageLabel = math.floor(age) .. "d old"
    end
    if base and price ~= base then
        local difference = price > base and (coins(price - base) .. " extra") or ("save " .. coins(base - price))
        if ageLabel then difference = difference .. ", " .. ageLabel end
        local note = ns.DetourHint and ns.DetourHint(state,id,price-base,age)
        return text .. " (" .. difference .. "). Base vendor " .. coins(base) .. "." .. (note and (" "..note) or "")
    end
    if ageLabel then text = text .. " (" .. ageLabel .. ")" end
    return base and (text .. ", same as vendor base.") or (text .. ".")
end

function ns.WithRecipeShoppingHint(state, id, text, vendorBaseCopper)
    local hint = ns.RecipeShoppingHint(state, id, vendorBaseCopper)
    return hint and (text .. " " .. hint) or text
end
