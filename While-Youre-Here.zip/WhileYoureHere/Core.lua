local _, ns = ...

local skills = {}
local byID = {}
for name, def in pairs(ns.ProfessionDefinitions) do skills[name]=def.id; byID[def.id]=name end

local function call(fn, ...)
    if type(fn) ~= "function" then return end
    local ok, value = pcall(fn, ...)
    if ok then return value end
end

local function timestamp()
    return call(GetServerTime) or call(time) or 0
end

local function migrateSharedPreferences(settings, characters)
    if settings.sharedPreferencesVersion then return end
    local latestMarket, latestSeen, latestKey
    local now = timestamp()
    local snoozeUntil = now
    for key, character in pairs(characters) do
        local market = character.saleMarket
        if market == "faction" or market == "neutral" then
            local seen = tonumber(character.seenAt) or 0
            if not latestSeen or seen > latestSeen or (seen == latestSeen and key < latestKey) then
                latestMarket, latestSeen, latestKey = market, seen, key
            end
        end
        local deadline = tonumber(character.snoozeUntil)
        if deadline and deadline > snoozeUntil then snoozeUntil = deadline end
    end
    if settings.saleMarket == nil then settings.saleMarket = latestMarket or "auto" end
    if settings.snoozeUntil == nil and snoozeUntil > now then settings.snoozeUntil = snoozeUntil end
    settings.sharedPreferencesVersion = 1
end

function ns.DB()
    -- Upgrades can copy the old account file under the new addon's filename.
    -- Preserve an existing current-format database if both globals are present.
    if type(WhileYoureHereDB) ~= "table" then
        WhileYoureHereDB = type(RosethornAdvisorDB) == "table" and RosethornAdvisorDB or {}
    end
    if RosethornAdvisorDB ~= nil then
        local isLoaded = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
        if not isLoaded or not isLoaded("RosethornAdvisor") then RosethornAdvisorDB = nil end
    end
    local db = WhileYoureHereDB
    db.characters = db.characters or {}
    db.history = db.history or {}
    db.settings = db.settings or {}
    migrateSharedPreferences(db.settings, db.characters)
    return db
end

function ns.RestoreWindowPosition(f, key, point, x, y)
    local saved = ns.DB().settings[key]
    f:ClearAllPoints()
    if type(saved) == "table" and saved.point and saved.relativePoint then
        f:SetPoint(saved.point, UIParent, saved.relativePoint, saved.x or 0, saved.y or 0)
    else
        f:SetPoint(point, UIParent, point, x, y)
    end
end

function ns.SaveWindowPosition(f, key)
    local point, _, relativePoint, x, y = f:GetPoint(1)
    if point then
        ns.DB().settings[key] = {point=point, relativePoint=relativePoint, x=x, y=y}
    end
    if f.SetUserPlaced then f:SetUserPlaced(false) end
end

function ns.CurrentRecord()
    local state = ns.state
    return state and ns.DB().characters[state.key]
end

local function skillsNow()
    local result = {}
    local localNames={}
    for name,def in pairs(ns.ProfessionDefinitions or {}) do
        local spell=(C_Spell and call(C_Spell.GetSpellName,def.spell)) or call(GetSpellInfo,def.spell)
        if spell then localNames[spell]=name end
    end
    local function record(name, rank, cap, modifier, temp)
        if name and type(rank) == "number" and rank > 0 and type(cap) == "number" and cap >= rank then
            result[name] = {rank=rank, cap=cap, modifier=tonumber(modifier) or 0, temp=tonumber(temp) or 0}
        end
    end
    for name, id in pairs(skills) do
        local info = C_SkillInfo and call(C_SkillInfo.GetSkillLineInfoByID, id)
        if type(info) == "table" then
            if info.name then localNames[info.name]=name end
            record(name, info.rank or info.skillRank or info.currentLevel, info.maxRank or info.skillMaxRank or info.maxLevel, info.modifier, info.tempPoints)
        end
    end
    if GetProfessions and GetProfessionInfo then
        local slots = {pcall(GetProfessions)}
        for i = 2, 7 do
            if slots[i] then
                local ok,label, _, rank, cap, _, _, id, modifier = pcall(GetProfessionInfo,slots[i])
                local name = byID[id] or localNames[label] or (skills[label] and label)
                if ok and name and not result[name] then record(name, rank, cap, modifier) end
            end
        end
    end
    if GetNumSkillLines and GetSkillLineInfo then
        for i = 1, GetNumSkillLines() do
            local label, header, _, rank, temp, modifier, cap = GetSkillLineInfo(i)
            local name=localNames[label] or label
            if not header and skills[name] and not result[name] then record(name, rank, cap, modifier, temp) end
        end
    end
    return result
end

local function bagsNow()
    if ns.ScanRosterContainers then
        local enums=Enum and Enum.BagIndex or {}
        local top=enums.CharacterBankTab_1 and (enums.ReagentBag or 5) or (NUM_BAG_SLOTS or 4)
        local items,greens,capacity,mailable=ns.ScanRosterContainers(0,top,false)
        if items then return items,capacity>0,greens,mailable end
    end
    local counts = {}
    local containers = C_Container
    local bagSize = (containers and containers.GetContainerNumSlots) or GetContainerNumSlots
    if bagSize and ((containers and containers.GetContainerItemInfo) or GetContainerItemInfo) then
        for bag = 0, (NUM_TOTAL_EQUIPPED_BAG_SLOTS or NUM_BAG_SLOTS or 4) do
            for slot = 1, bagSize(bag) or 0 do
                local id, n
                if containers and containers.GetContainerItemInfo then
                    local info = containers.GetContainerItemInfo(bag, slot)
                    if info then id, n = info.itemID, info.stackCount end
                else
                    local _, stack, _, _, _, _, link, _, _, itemID = GetContainerItemInfo(bag, slot)
                    id, n = itemID or (link and tonumber(link:match("item:(%d+)"))), stack
                end
                if id then counts[id] = (counts[id] or 0) + (n or 1) end
            end
        end
    else
        local getCount = (C_Item and C_Item.GetItemCount) or GetItemCount
        local function query(id) counts[id] = call(getCount, id, false) or 0 end
        for id, fish in pairs(ns.fish) do query(id); query(fish.recipeItem) end
        for _, id in ipairs({6358, 6359, 16072, 16083}) do query(id) end
    end
    return counts
end

function ns.RefreshPosition()
    local s = ns.state
    if not s then return end
    s.mapID = C_Map and call(C_Map.GetBestMapForUnit, "player")
    local pos = s.mapID and call(C_Map.GetPlayerMapPosition, s.mapID, "player")
    s.x, s.y = nil, nil
    if pos and pos.GetXY then s.x, s.y = pos:GetXY() end
    s.zone = call(GetRealZoneText) or call(GetZoneText) or ""
    s.subzone = call(GetSubZoneText) or ""
    s.hour = call(GetGameTime)
    s.destination = ns.CurrentRecord().destination
end

function ns.Collect()
    local name = call(UnitName, "player")
    if not name or name == "" or name == UNKNOWNOBJECT then return end
    local realm = call(GetRealmName) or "?"
    local mode = C_GameRules and call(C_GameRules.IsHardcoreActive) and "hardcore" or "normal"
    local key = realm .. ":" .. name
    local db = ns.DB()
    local rec = db.characters[key] or {seenAlerts={}}
    db.characters[key] = rec
    rec.seenAlerts = rec.seenAlerts or {}
    local _,class
    if UnitClass then _,class=UnitClass("player") end
    local bags,full,greens,mailable=bagsNow()
    local liveLevel=call(UnitLevel,"player")
    local s = {key=key, name=name, realm=realm, mode=mode, level=(liveLevel and liveLevel>0) and liveLevel or rec.level or 0,
        faction=call(UnitFactionGroup, "player") or rec.faction, class=class or rec.class, skills=skillsNow(),
        bags=bags, bagsScanned=full}
    ns.state = s
    if ns.RefreshProfessionBuildProfile then ns.RefreshProfessionBuildProfile(s) end
    rec.name, rec.realm, rec.mode, rec.level, rec.faction = name, realm, mode, s.level, s.faction
    rec.class=s.class
    rec.seenAt = timestamp()
    -- Preserve the last good observation across temporary empty skill responses.
    if next(s.skills) then
        rec.skills,rec.skillsSeen,rec.skillSeen=s.skills,rec.seenAt,{}
        for prof in pairs(s.skills) do rec.skillSeen[prof]=rec.seenAt end
    else rec.skills=rec.skills or {} end
    if ns.SnapshotRoster then ns.SnapshotRoster(rec,s,full and bags or nil,greens,mailable) end
    local hist = db.history[mode] or {}
    db.history[mode] = hist
    for profession, value in pairs(s.skills) do
        hist[profession] = math.max(hist[profession] or 0, value.rank)
    end
    ns.ScanTrackedRecipes(s, rec)
    ns.RefreshPosition()
    return s
end

local difficultyText = {
    orange = "|cffff8040orange|r", yellow = "|cffffff00yellow|r",
    green = "|cff40c040green|r", grey = "|cffaaaaaagrey|r",
}

-- Forever Alchemy skill-up limits: bindonforever.com/item/6370 and /item/6371.
local oilFish = {
    {id=6358, name="Oily Blackmouth", recipe="Blackmouth Oil", grey=100},
    {id=6359, name="Firefin Snapper", recipe="Fire Oil", grey=170},
}

local function fishAdvice(s, add, catalogue, vendors)
    local cooking = s.skills.Cooking
    local count = 0
    for id, f in pairs(ns.fish) do
        local n = s.bags[id] or 0
        if catalogue or (n > 0 and not ns.RecipeOutlevelled(cooking, f)) then
            count = count + 1
            local rank = cooking and cooking.rank or 0
            local colour = rank >= f.grey and "grey" or rank >= f.green and "green"
                or rank >= f.yellow and "yellow" or "orange"
            local missing = s.missing and s.missing[f.spell]
            local known = not missing and ((s.known and s.known[f.spell]) or call(IsSpellKnown, f.spell))
            local canCook = cooking and rank >= f.skill
            local canGain = canCook and rank < f.grey and rank < cooking.cap
            local shop = ns.localFishVendors[s.mapID]
            if not shop or not shop.items[id] or (shop.faction and shop.faction ~= s.faction) then shop = f end
            shop = ns.AccessibleFishShop(s,id,shop)
            local near = shop and s.mapID == shop.mapID and (
                (shop.vendor == "Kelsey Yance" and s.subzone == "Booty Bay")
                or (s.x and s.y and (s.x - shop.x)^2 + (s.y - shop.y)^2 < 0.028^2))
            local held = not known and ns.RecipeItemHeld(s, f.recipeItem)
            local localStop = vendors and vendors[f.recipeItem]
            local showShop = shop and not known and not held and (catalogue or (missing and ns.FeatureEnabled("vendors") and not localStop))
            local status = known and "Recipe known" or held == "bags" and "Recipe in bags"
                or held == "bank" and "Recipe in bank" or missing and "Recipe unlearned" or "Open Cooking to check recipe"
            local lines = {}
            if canCook and (known or missing) then
                status = status .. ": Currently " .. difficultyText[colour]
            end
            lines[1] = status
            if f.buff then lines[#lines+1] = "Effect: " .. f.buff end
            if not canCook or catalogue then
                lines[#lines+1] = (catalogue and f.recipe .. " · " or "Requires ") .. "Cooking " .. f.skill
            end
            if canCook and known and rank < f.grey and rank >= cooking.cap then
                lines[#lines+1] = "Cooking capped at " .. cooking.cap
            end
            if not known and not held and not localStop and (catalogue or missing) and ns.RecipeShoppingHint then
                local auction = ns.RecipeShoppingHint(s, f.recipeItem)
                if auction then lines[#lines+1] = auction end
            end
            if showShop then
                lines[#lines+1] = ("Vendor: %s · %s (%.1f, %.1f)"):format(shop.vendor, shop.hub or shop.zone, shop.x*100, shop.y*100)
                if catalogue and shop.directions then lines[#lines+1] = shop.directions end
            end
            if catalogue and f.reagent then lines[#lines+1] = "Per craft: " .. f.reagent end
            if catalogue and f.station then lines[#lines+1] = "Requires " .. f.station end
            local priority = catalogue and (100 + f.skill) or (canCook and (near and not known and 13 or 35) or 62)
            local title = f.name .. (n > 0 and (": x " .. n) or "")
            add(title, table.concat(lines,"\n"), priority, "fish:" .. id, showShop and ns.RecipeVendorTarget(shop) or nil,
                not catalogue and showShop and canGain and near)
        end
    end
    for _, oil in ipairs(oilFish) do
        local n = s.bags[oil.id] or 0
        if n > 0 and (catalogue or not ns.RecipeOutlevelled(s.skills.Alchemy, oil)) then
            count = count + 1
            local use = "Alchemy: 2 fish + 1 Empty Vial for " .. oil.recipe .. "."
            if catalogue or ns.FeatureEnabled("materials") then use = use .. " Keep or mail to your Alchemist." end
            add(oil.name .. ": x " .. n, use, 75, "oil:" .. oil.id)
        end
    end
    return count
end

local function training(s, add, vendors)
    local cook = s.skills.Cooking
    if not cook then return end
    if cook.cap == 75 and cook.rank >= 50 then
        add("Train Journeyman Cooking", "At Cooking 50 a Cooking trainer can raise your cap from 75 to 150.", 41, "cook:journeyman", nil, cook.rank >= 70)
    elseif cook.cap == 150 and cook.rank >= 125 then
        if vendors and vendors[16072] then return end
        local held=ns.RecipeItemHeld(s,16072)
        if not held and not ns.FeatureEnabled("vendors") then return end
        local body, target = ns.ExpertBookAdvice(s,"Cooking",cook.rank)
        add("Expert Cooking book · " .. cook.rank .. "/150", body, 17, "cook:expert",
            target, cook.rank >= 140 or (target and s.mapID == target.mapID))
    elseif cook.cap == 225 and cook.rank >= 215 then
        local eligible = s.level >= 35 and cook.rank >= 225
        local body = "At level 35 and Cooking 225, take 12 Giant Eggs, 10 Zesty Clam Meat and 20 Alterac Swiss to Dirge Quikcleave in the Gadgetzan inn, Tanaris (52.6, 27.9), for Clamlette Surprise."
        add(eligible and "Unlock Artisan Cooking" or "Prepare for Artisan Cooking",body,30,"cook:artisan",{name="Dirge Quikcleave",mapID=1446,x=0.526,y=0.279},eligible)
    end
end

local milestones = {{150,10,62024},{225,20,62025},{300,35,62026}}
local function alts(s, add, nearOnly)
    local db = ns.DB()
    local high = db.history[s.mode] and db.history[s.mode].Leatherworking or 0
    if s.mode == "hardcore" then
        if nearOnly then return end
        add("Hardcore Leatherworking", "Use the Legacy pane (Y) to check Hardcore rewards. This roster records observed skills separately from standard realms.", 5, "lw:hardcore")
        return
    end
    local nextGoal, minLevel
    for _, step in ipairs(milestones) do
        local completed = false
        if GetAchievementInfo then
            local ok, _, _, _, done = pcall(GetAchievementInfo, step[3])
            completed = ok and done == true
        end
        if step[1] > high and not completed then nextGoal, minLevel = step[1], step[2]; break end
    end
    if not nextGoal then
        if nearOnly then return end
        add("Leatherworking milestones covered", "All three thresholds have been observed in this roster or marked complete by the client. Check Legacy (Y) for account credit.", 10, "lw:done")
        return
    end
    local candidates = {}
    for _, rec in pairs(db.characters) do
        local lw = rec.skills and rec.skills.Leatherworking
        if rec.mode == s.mode and lw and lw.rank < nextGoal then
            candidates[#candidates+1] = {rec=rec,lw=lw,eligible=rec.level >= minLevel}
        end
    end
    table.sort(candidates, function(a,b)
        if a.eligible ~= b.eligible then return a.eligible end
        if a.lw.rank ~= b.lw.rank then return a.lw.rank > b.lw.rank end
        return (a.rec.name .. a.rec.realm) < (b.rec.name .. b.rec.realm)
    end)
    if nearOnly then
        local best = candidates[1]
        if not best or not best.eligible or nextGoal-best.lw.rank > 10 then return end
        local owner = best.rec.name .. (best.rec.realm ~= s.realm and (" (" .. best.rec.realm .. ")") or "")
        local left = nextGoal - best.lw.rank
        local text = owner .. " last had Leatherworking " .. best.lw.rank .. "/" .. best.lw.cap ..
            ". Another " .. left .. (left == 1 and " skill-up reaches " or " skill-ups reach ") ..
            nextGoal .. ". Check Legacy (Y) for account credit before spending materials."
        add(owner .. " · Leatherworking " .. nextGoal .. " within reach", text, 31,
            "lw:near:" .. nextGoal, nil, true)
        return
    end
    local intro = "Leatherworking " .. nextGoal .. " is the next milestone to check; its Legacy point is earned once per account. Open Legacy (Y) to confirm credit from characters outside this roster."
    if #candidates == 0 then add("Leatherworking · " .. nextGoal, intro .. " Log in on your leatherworker once to record their skills.", 10, "lw:unseen"); return end
    for i, candidate in ipairs(candidates) do
        local r, lw = candidate.rec, candidate.lw
        local seen = r.seenAt and date and date("%Y-%m-%d", r.seenAt) or "date unknown"
        local detail = r.name .. " is level " .. r.level .. ", Leatherworking " .. lw.rank .. "/" .. lw.cap .. " (last seen " .. seen .. "). "
        if not candidate.eligible then detail = detail .. "Reach character level " .. minLevel .. " before pursuing " .. nextGoal .. ". "
        elseif lw.cap < nextGoal then detail = detail .. "Train the next profession rank before this target. " end
        add((i == 1 and candidate.eligible and "Closest · " or "") .. r.name .. " · Leatherworking " .. lw.rank, detail .. (i == 1 and intro or ""), 11+i, "lw:" .. r.realm .. ":" .. r.name)
    end
end

function ns.GetAdvice(tab)
    local s = ns.state
    local rows = {}
    if not s then return rows end
    local function add(title,body,priority,key,waypoint,alert,questID,mapID,vendorTarget)
        rows[#rows+1] = {title=title,body=body,priority=priority or 50,key=key or title,target=waypoint,
            alert=alert == true,questID=questID,mapID=mapID,vendorTarget=vendorTarget}
    end
    local function source(id)
        return function(...)
            add(...)
            rows[#rows].feature=id
        end
    end
    local profession=source("professions")
    local fishing=source("fishing")
    local plan=ns.FeatureEnabled("professions")
    local instance=tab=="now" and ns.CurrentInstance(s)
    local function professions(vendors)
        if plan then
            if not ns.AddEfficiencyLP then alts(s,profession,tab=="now") end
            ns.AddPlannedProfessionAdvice(s,profession,tab)
        end
        if plan or ns.FeatureEnabled("materials") then
            ns.AddProfessionAdvice(s,profession,tab,source("materials"),vendors)
        end
    end
    if tab == "skip" then
        ns.SkipAdvice(s,add)
    elseif tab == "professions" then
        if ns.ProfessionPanelAdvice then ns.ProfessionPanelAdvice(s,add) end
    elseif tab == "alts" then
        if ns.AddRosterAdvice then ns.AddRosterAdvice(s,add) end
        professions()
    elseif tab == "catalog" then
        fishAdvice(s, add, true)
    elseif instance then
        ns.AddNearbyTips(s,source("dungeons"),nil,instance)
    else
        local fish=ns.FeatureEnabled("fishing")
        if tab=="fishing" and not fish then
            add("Fishing advice is off", "Enable fishing in Settings under Tips to see suggestions here.",90,"settings:fishing")
            return rows
        end
        local vendors = tab == "now" and ns.AddNearbyTips(s,source("dungeons"),source("vendors"))
        if tab=="now" then professions(vendors) end
        local goal = ns.FishingGoal(s)
        local ready
        if fish and ns.FeatureEnabled("fishingLocation") then
            if goal=="cooking" then ready=ns.ReadyCookingStep(s)
            elseif goal=="food" then ready=ns.ReadyBuildFood(s) end
        end
        local location = fish and ns.FeatureEnabled("fishingLocation") and ns.FishingLocationAdvice(s)
        if ready and tab=="fishing" then
            if location and location.spot then
                ready=ready.."\nFor your next casts: "..location.spot.water.."."
            end
            fishing(goal=="food" and "Food in your bags" or "Cook from your bags",ready,0,"fishing:bags")
        end
        local showLocation = location and not ready and (tab == "fishing" or (tab == "now" and location.localZone and location.alert))
        if showLocation then
            local spot = location.spot
            local pin = ns.AdvisorMap.waypointAvailable(spot) and spot or nil
            local key = location.key or ("fishing-location:%s:%s"):format(
                spot and spot.mapID or s.mapID or "unknown", location.fishID or "training")
            local addLocation = source("fishingLocation")
            local body, recipeTarget = location.body, location.vendorTarget
            if tab=="fishing" and location.why and location.why~="" then body=body.."\n"..location.why end
            if tab == "fishing" and goal=="food" and s.skills and s.skills.Cooking and location.spot then
                local focus = ns.FishingFoodFocus(s)
                local nextFood
                if focus == "healing" and ns.HealingFoodLine then
                    nextFood = ns.HealingFoodLine(s, s.skills.Cooking.rank)
                elseif location.fishID and not location.matches and ns.NextFishFoodUnlock then
                    nextFood = ns.NextFishFoodUnlock(s, s.skills.Cooking.rank, focus)
                end
                if nextFood then body = body .. "\n" .. nextFood end
                if ns.HybridFishOption then
                    local alternative, alternativeTarget = ns.HybridFishOption(s, location)
                    if alternative then body = body .. "\n" .. alternative end
                    recipeTarget = recipeTarget or alternativeTarget
                end
            end
            addLocation(location.title, body, tab == "fishing" and 1 or 24, key,
                pin, location.localZone and location.alert, nil, nil, recipeTarget)
        end
        ns.AddRouteAdvice(s,function(title, body, priority, key, pin, alert, vendorTarget)
            if key=="fishing-book" and vendors and vendors[16083] then return end
            if showLocation and location.localZone and location.spot and location.spot.routeKey==key and not vendorTarget then return end
            fishing(title,body,priority,key,pin,alert,nil,nil,vendorTarget)
        end,profession,tab)
        if fish then ns.AddEconomyAdvice(s,fishing,tab,source("prices"),showLocation and location) end
        if plan then training(s,profession,vendors) end
        local count = fish and fishAdvice(s,fishing,false,vendors)
        if count == 0 and tab == "fishing" and not location then
            fishing("No recipe suggestions from your bags", "Open All fish to look up a recipe.",90,"fish:empty")
        elseif #rows==0 and plan then
            profession("Your profession plan","Open Professions to choose the skills you want on this character. Log in on your alts to record their skills and supplies.",90,"roster:welcome")
        end
    end
    table.sort(rows,function(a,b)
        if a.priority ~= b.priority then return a.priority < b.priority end
        return a.title < b.title
    end)
    return rows
end

