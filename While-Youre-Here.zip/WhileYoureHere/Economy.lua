local _, ns = ...

-- Open-water skill targets. Zones with exceptional waters use named subzones.
-- Wowhead Forever, Fishing Profession Overview, "Fishing Requirements by Zone".
local plainWater = {
    [1411]=25, [1412]=25, [1420]=25, [1438]=25, [1426]=25, [1429]=25,
    [1413]=75, [1421]=75, [1439]=75, [1432]=75, [1436]=75,
    [1454]=75, [1456]=75, [1458]=75, [1453]=75, [1455]=75, [1457]=75,
    [1440]=150, [1424]=150, [1442]=150, [1431]=150, [1433]=150, [1437]=150,
    [1416]=225, [1417]=225, [1443]=225, [1445]=225, [1435]=225, [1441]=225,
    [1448]=300, [1425]=300, [1450]=300, [1446]=300, [1449]=300, [1422]=300,
    [1428]=425, [1430]=425, [1423]=425, [1451]=425, [1452]=425,
}
local namedWater = {
    [1434]={["Booty Bay"]=225, ["Grom'gol Base Camp"]=225, ["The Savage Coast"]=225, ["Jaguero Isle"]=300},
    [1444]={["Camp Mojache"]=300, ["Wildwind Lake"]=300, ["Verdantis River"]=300,
        ["Feathermoon Stronghold"]=300, ["The Forgotten Coast"]=300, ["Jademir Lake"]=425},
    [1447]={["Bay of Storms"]=425, ["Hetaera's Clutch"]=425, ["Scalebeard's Cave"]=425},
}
function ns.WaterThreshold(state)
    if not state then return end
    if IsInInstance and IsInInstance() then return end
    local names = namedWater[state.mapID]
    return names and names[state.subzone] or plainWater[state.mapID]
end

local function waterNow()
    local sub = GetSubZoneText and GetSubZoneText() or ""
    local zone = GetRealZoneText and GetRealZoneText() or ""
    local map = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
    return {mapID=map, subzone=sub, zone=zone}, sub ~= "" and sub or zone
end

local session, pendingLoot, fishingChannel, castForLoot, toast
local previousCastGUIDs={}
local function characterKey()
    if ns.state and ns.state.key then return ns.state.key end
    local name=UnitName and UnitName("player")
    return name and ((GetRealmName and GetRealmName() or "")..":"..name) or nil
end
local function archive()
    if not session then return end
    local key=characterKey()
    local seconds=session.last-session.start
    if key and (seconds>0 or session.casts>0) then
        local db=ns.DB()
        db.fishingTrips=db.fishingTrips or {}
        local history=db.fishingTrips[key] or {}
        history[#history+1]={key=session.key,water=session.water,seconds=seconds,items=session.items,
            casts=session.casts,castCoverage=session.castCoverage and session.casts>0,waterSamples=session.waterSamples}
        if #history>160 then table.remove(history,1) end
        db.fishingTrips[key]=history
    end
    previousCastGUIDs=session.seenCastGUIDs
    if ns.BreakWaterSample then ns.BreakWaterSample() end
    session,castForLoot,fishingChannel=nil,nil,nil
end
function ns.GetFishingWaterTrips(state)
    if not state or state.key ~= characterKey() then return end
    local trips = ns.DB().fishingTrips
    return trips and trips[state.key], session
end
local function touch()
    local now = GetTime()
    local state, label = waterNow()
    local key = tostring(state.mapID) .. "/" .. label
    if not session or session.key ~= key or now-session.last >= 120 then
        archive()
        session = {key=key, water=label, start=now, last=now, items={}, casts=0,
            castCoverage=true, seenCastGUIDs={}}
    end
    session.last = now
    return state
end

-- The loot tracker may keep separate stacks for different item variants.
function ns.CaughtFishHere(state, rawItemID)
    if not session or not state or not state.mapID or GetTime() - session.last >= 120 then
        return false
    end
    local label = state.subzone
    if not label or label == "" then label = state.zone end
    if not label or label == "" or session.key ~= tostring(state.mapID) .. "/" .. label then
        return false
    end
    for _, stack in pairs(session.items) do
        if stack.id == rawItemID and stack.count > 0 then return true end
    end
    return false
end

local function refresh()
    if ns.RequestRefresh then ns.RequestRefresh() end
end

local function estimate(trip,seconds,cache)
    local result = {seconds=seconds, water=trip.water, quantity=0, priced=0,
        unpriced=0, copper=0, allComparable=true, items={}}
    for key, stack in pairs(trip.items) do
        local id=stack.id or key
        local sale=cache[key]
        if not sale then
            local unit,method,info=ns.CatchSaleValue(id,stack.link)
            sale={unit=unit,method=method,info=info}
            cache[key]=sale
        end
        local info=sale.info
        local row = {id=id,link=stack.link,name=stack.name or ("Item "..tostring(id)),quantity=stack.count,
            saleMethod=sale.method,saleInfo=info}
        result.quantity = result.quantity + stack.count
        if sale.unit~=nil then
            row.copper=sale.unit*stack.count
            result.priced=result.priced+stack.count
            result.copper=result.copper+row.copper
        else
            result.unpriced=result.unpriced+stack.count
        end
        if sale.unit==nil or not info.comparable then result.allComparable=false end
        result.items[#result.items+1]=row
    end
    table.sort(result.items,function(a,b)
        if (a.copper or -1)==(b.copper or -1) then return tostring(a.id)<tostring(b.id) end
        return (a.copper or -1)>(b.copper or -1)
    end)
    if seconds > 0 then
        result.catchesPerHour = result.quantity * 3600 / seconds
        if result.priced > 0 then
            result.pricedCopperPerHour = result.copper * 3600 / seconds
            -- Alerts and historical spot comparisons keep their five-minute minimum.
            if seconds >= 300 then result.perHour = result.pricedCopperPerHour end
        end
    end
    return result
end
local function perCast(result,casts)
    if casts>0 and result.unpriced==0 then return result.copper/casts end
end
function ns.GetFishingEstimate()
    if not session then return end
    local finish=session.last
    if fishingChannel then
        local now=GetTime()
        if now-finish<120 then finish=math.max(finish,now) end
    end
    local r=estimate(session,finish-session.start,{})
    r.casts=session.casts
    r.castCoverage=session.castCoverage and session.casts>0
    if r.castCoverage then r.perCast=perCast(r,r.casts) end
    return r
end

-- Compare waters at today's same market quotes. Sum elapsed time and quantities
-- before dividing, so a short lucky visit never gets an equal vote with a long one.
function ns.GetFishingSpots()
    local spots,rows,cache={},{},{}
    local function sumItems(total,items)
        for tag,item in pairs(items) do
            local summed=total[tag] or {name=item.name,id=item.id,link=item.link,count=0}
            summed.count=summed.count+item.count
            total[tag]=summed
        end
    end
    local function include(trip,seconds)
        local spot=spots[trip.key] or {water=trip.water,seconds=0,visits=0,items={},
            casts=0,castSeconds=0,castVisits=0,castItems={}}
        spots[trip.key]=spot
        spot.seconds=spot.seconds+seconds
        spot.visits=spot.visits+1
        sumItems(spot.items,trip.items)
        -- Older histories and partially observed visits have no reliable cast denominator.
        if trip.castCoverage and trip.casts and trip.casts>0 then
            spot.casts=spot.casts+trip.casts
            spot.castSeconds=spot.castSeconds+seconds
            spot.castVisits=spot.castVisits+1
            sumItems(spot.castItems,trip.items)
        end
    end
    local history=ns.DB().fishingTrips
    local key=characterKey()
    for _,trip in ipairs((history and key and history[key]) or {}) do include(trip,trip.seconds) end
    if session then include(session,session.last-session.start) end
    for _,spot in pairs(spots) do
        local r=estimate(spot,spot.seconds,cache)
        r.visits=spot.visits
        r.comparable=r.seconds>=900 and r.quantity>=10 and r.allComparable
        local castSample=estimate({water=spot.water,items=spot.castItems},spot.castSeconds,cache)
        r.casts,r.castSeconds,r.castQuantity,r.castVisits=spot.casts,spot.castSeconds,castSample.quantity,spot.castVisits
        r.castItems=castSample.items
        r.perCast=perCast(castSample,r.casts)
        r.castComparable=r.casts>=20 and r.castSeconds>=900 and r.castQuantity>=10 and r.perCast~=nil
            and castSample.allComparable
        rows[#rows+1]=r
    end
    table.sort(rows,function(a,b)
        if a.comparable~=b.comparable then return a.comparable end
        if a.comparable and a.perHour~=b.perHour then return a.perHour>b.perHour end
        if a.seconds~=b.seconds then return a.seconds>b.seconds end
        return a.water<b.water
    end)
    return rows
end

local function coin(copper)
    local n = math.floor(copper+0.5)
    if n>=10000 then return ("%dg %ds %dc"):format(math.floor(n/10000),math.floor(n/100)%100,n%100) end
    if n>=100 then return ("%ds %dc"):format(math.floor(n/100),n%100) end
    return n.."c"
end
-- Show gross AH unit prices as in the tooltip. The choice of venue and all
-- analytical totals still use the proceeds after the AH cut.
local function compactCoin(n)
    local silver=math.floor(n/100)
    local copper=n%100
    if silver==0 then return copper.."c" end
    if copper==0 then return silver.."s" end
    return silver.."s "..copper.."c"
end

local function sessionGoldRate(r)
    if r.seconds <= 0 then return "—" end
    if r.quantity == 0 then return "0g" end
    if not r.pricedCopperPerHour then return "— (no prices)" end
    local gold = r.pricedCopperPerHour / 10000
    local text = gold < 0.01 and "<0.01g" or ("~%.2fg"):format(gold)
    if r.unpriced > 0 then
        text = text .. (" (%d/%d priced)"):format(r.priced, r.quantity)
    end
    return text
end

local function details(r)
    local duration=("%d:%02d"):format(math.floor(r.seconds/60),math.floor(r.seconds%60))
    local rate=r.catchesPerHour and ("%.0f"):format(r.catchesPerHour) or "—"
    local lines = {"Time fishing: " .. duration,
        "Catches per hour: " .. rate .. "  ·  Gold per hour: " .. sessionGoldRate(r)}
    for _,item in ipairs(r.items) do
        local entry=item.name.." "..item.quantity.."x"
        if item.saleMethod then
            local isAuction=item.saleMethod=="auction"
            local unit=math.floor((isAuction and item.saleInfo.ah or item.saleInfo.vendor)+0.5)
            local channel=isAuction and "AH" or "Vendor"
            entry=entry.." "..compactCoin(unit).." ("..channel..") = "..compactCoin(unit*item.quantity)
        else
            entry=entry.." (price unavailable)"
        end
        lines[#lines+1]=entry
    end
    return table.concat(lines,"\n")
end

local function fresh(age) return type(age)=="number" and age>=0 and age<=7 end
local function needsLocalQuote(sale)
    return not sale.ah or sale.source=="Auctionator" or not fresh(sale.age)
end
local function compareBaggedFish(state,add)
    if not state or not state.bags or not ns.CookingMarketOptions then return end
    local best, rawBest, watch
    local watchCount=0
    local cooking=state.skills and state.skills.Cooking
    for id,count in pairs(state.bags) do
        local fish=ns.fish and ns.fish[id]
        if fish and count>0 and not ns.RecipeOutlevelled(cooking,fish) then
            local opt=ns.CookingMarketOptions(id,state)
            if opt then
                local raw,cooked=opt.rawSale,opt.cookedSale
                local verifyRaw=needsLocalQuote(raw)
                local verifyCooked=opt.executable and needsLocalQuote(cooked)
                if verifyRaw or verifyCooked then
                    watchCount=watchCount+1
                    if not watch or count>watch.count then
                        watch={count=count,name=verifyRaw and fish.name or opt.recipe}
                    end
                end
                local good=opt.executable and opt.netGain and raw.comparable and cooked.comparable
                for _,ing in pairs(opt.ingredientCosts or {}) do
                    if ing.source=="Auctionator" or (ing.source~="vendor" and not fresh(ing.ageDays)) then good=false end
                end
                if good then
                    local gain=opt.netGain
                    local entry={recipe=opt.recipe,rawName=fish.name,count=count,gain=gain,stackGain=gain*count,
                        station=opt.station,needs=opt.ingredientsNeeded,rawMethod=raw.method,cookedMethod=cooked.method}
                    if gain>0 and (not best or entry.stackGain>best.stackGain) then best=entry end
                    if gain<=0 and (not rawBest or entry.stackGain<rawBest.stackGain) then rawBest=entry end
                end
            end
        end
    end
    if watch then
        local text="For a cooking profit comparison, confirm "..watch.name.." at your sale AH."
        if watchCount>1 then text=text.." "..watchCount.." fish types need a fresh local price." end
        add("What to price next",text,42,"fishing-price-next",nil,false)
    end
    local function saleOutlet(method)
        return method=="auction" and "the AH after its cut" or "a vendor"
    end
    if best then
        local text=best.recipe.." adds an estimated "..coin(best.gain).." per raw fish, "..coin(best.stackGain)..
            " for the "..best.count.." in your bags after ingredients. Sell the food to "..saleOutlet(best.cookedMethod).."."
        if best.needs then text=text.." Pick up "..best.needs.."." end
        if best.station=="Iron Oven" then text=text.." Use an Iron Oven." end
        add("Cook "..best.rawName.." for sale",text,27,"fishing-cook-sale",nil,false)
    end
    if rawBest then
        local text="Selling "..rawBest.rawName.." to "..saleOutlet(rawBest.rawMethod).." returns "..coin(-rawBest.gain)..
            " more per fish than making "..rawBest.recipe.." after ingredients."
        if cooking and cooking.rank<cooking.cap then text=text.." Cooking may still give a skill-up." end
        add("Keep "..rawBest.rawName.." raw for sale",text,31,"fishing-raw-sale",nil,false)
    end
end

function ns.AddEconomyAdvice(state,fishAdd,tab,priceAdd,location)
    if not ns.FeatureEnabled("fishing") or (tab ~= "now" and tab ~= "fishing") then return end
    local prices=ns.FeatureEnabled("prices")
    local add=priceAdd or fishAdd
    if tab=="fishing" and prices then
        compareBaggedFish(state,add)
        local spots=ns.GetFishingSpots()
        if ns.AddCookingSpotAdvice then ns.AddCookingSpotAdvice(state,add) end
        if #spots>0 then
            local summary={}
            for index,spot in ipairs(spots) do
                if index>5 then break end
                local value=spot.quantity.." items recorded"
                if spot.perHour and spot.unpriced==0 then
                    value=coin(spot.perHour).."/hr"..(spot.comparable and "" or " (unranked estimate)")
                end
                if spot.casts>0 and spot.perCast then
                    value=value..", "..coin(spot.perCast).."/cast"..(spot.castComparable and "" or " (unranked)")
                end
                summary[#summary+1]=string.format("%s: %s (%dm, %d visits).",spot.water,value,math.floor(spot.seconds/60),spot.visits)
            end
            local marketKey,market=ns.MarketKey()
            if marketKey then table.insert(summary,1,market) end
            summary[#summary+1]="Area totals include schools, open water and one-off catches."
            add("Fishing history by area",table.concat(summary,"\n"),72,"fishing-waters",nil,false)
        end
    end
    if not session or (tab=="now" and GetTime()-session.last>=120) then return end
    local target = ns.WaterThreshold(state)
    local _, here = waterNow()
    local targetShown = location and location.localZone and location.spot and location.spot.noEscape == target
    if target and not targetShown and session.water==here and GetTime()-session.last<120 then
        fishAdd("Open-water Fishing target",here..": at "..target..
            " effective Fishing, fish stop getting away. Your pole, lure and other Fishing bonuses count.",62,
            "water-target-"..tostring(state.mapID).."-"..target,nil,true)
    end
    if not prices then return end
    local r=ns.GetFishingEstimate()
    add("Fishing session: "..r.water,details(r),28,"fishing-economy:"..r.water,nil,r.perHour~=nil)
end

local fishingIDs={[7620]=true,[7731]=true,[7732]=true,[18248]=true,[131474]=true}
local function spellName(id)
    if not id then return end
    if C_Spell and C_Spell.GetSpellName then return C_Spell.GetSpellName(id) end
    if GetSpellInfo then return GetSpellInfo(id) end
end
local function isFishing(id)
    if fishingIDs[id] then return true end
    local name=spellName(id)
    return name and name==spellName(7620)
end

local function snapshotLoot()
    if not IsFishingLoot or not IsFishingLoot() then pendingLoot=nil; return end
    if not pendingLoot then
        pendingLoot={}
        if castForLoot and GetTime()-castForLoot.started<60 then
            pendingLoot.observedTrip, pendingLoot.sample = castForLoot.trip, castForLoot.sample
        end
        castForLoot=nil
    end
    for slot=1,GetNumLootItems() do
        if pendingLoot[slot]==nil then
            local link=GetLootSlotLink(slot)
            local id=link and tonumber(link:match("item:(%d+)"))
            if id then
                local _,name,count=GetLootSlotInfo(slot)
                pendingLoot[slot]={id=id,link=link,name=name or ("Item "..id),count=tonumber(count) or 1}
            end
        end
    end
end
local tracker=CreateFrame("Frame")
for _,event in ipairs({"UNIT_SPELLCAST_CHANNEL_START","UNIT_SPELLCAST_CHANNEL_STOP","LOOT_READY","LOOT_OPENED",
        "LOOT_SLOT_CLEARED","LOOT_CLOSED","PLAYER_ENTERING_WORLD","PLAYER_LOGOUT","PLAYER_REGEN_DISABLED",
        "ZONE_CHANGED","ZONE_CHANGED_NEW_AREA","ZONE_CHANGED_INDOORS"}) do
    tracker:RegisterEvent(event)
end
tracker:SetScript("OnEvent",function(frame,event,arg,castGUID,id)
    if not ns.FeatureEnabled("fishing") then return end
    if event=="UNIT_SPELLCAST_CHANNEL_START" and arg=="player" then
        if isFishing(id) then
            local identified=type(castGUID)=="string" and castGUID~=""
            if identified and (previousCastGUIDs[castGUID] or (session and session.seenCastGUIDs[castGUID])) then return end
            local state=touch()
            if identified then
                session.seenCastGUIDs[castGUID]=true
                session.casts=session.casts+1
                castForLoot={trip=session,started=GetTime()}
                if ns.ObserveWaterCast then
                    castForLoot.sample=ns.ObserveWaterCast(session,state,castForLoot.started)
                end
            else
                session.castCoverage=false
                castForLoot=nil
                if ns.BreakWaterSample then ns.BreakWaterSample() end
            end
            pendingLoot=nil
            fishingChannel=castGUID or true
            refresh()


        else
            fishingChannel,castForLoot=nil,nil
        end
    elseif event=="UNIT_SPELLCAST_CHANNEL_STOP" and arg=="player" and fishingChannel and
        (not castGUID or fishingChannel==true or castGUID==fishingChannel) then
        fishingChannel=false
        touch()
        if castForLoot and ns.FinishWaterCast then ns.FinishWaterCast(session,castForLoot.sample,GetTime()) end
        refresh()
    elseif event=="LOOT_READY" or event=="LOOT_OPENED" then snapshotLoot()
    elseif event=="LOOT_SLOT_CLEARED" then
        local item=pendingLoot and pendingLoot[arg]
        if item then
            pendingLoot[arg]=false
            local state=touch()
            if pendingLoot.observedTrip~=session then session.castCoverage=false end
            local variant=ns.MarketVariantKey and ns.MarketVariantKey(item.id,item.link)
            local key=variant and (tostring(item.id).."/"..tostring(variant)) or item.id
            local stack=session.items[key] or {id=item.id,link=item.link,name=item.name,count=0}
            stack.count=stack.count+item.count
            session.items[key]=stack
            if pendingLoot.observedTrip==session and ns.ObserveWaterItem then
                ns.ObserveWaterItem(session,pendingLoot.sample,key,item,GetTime())
            elseif ns.BreakWaterSample then
                ns.BreakWaterSample()
            end

            refresh()
        end
    elseif event=="LOOT_CLOSED" then pendingLoot=nil
    elseif event=="ZONE_CHANGED" or event=="ZONE_CHANGED_NEW_AREA" or event=="ZONE_CHANGED_INDOORS" then
        if ns.CurrentFishingWaterSelection then ns.CurrentFishingWaterSelection(waterNow()) end
    elseif event=="PLAYER_ENTERING_WORLD" or event=="PLAYER_LOGOUT" then
        pendingLoot=nil; fishingChannel=false; archive()
        if ns.ClearFishingWaterSelection then ns.ClearFishingWaterSelection() end

    end
end)

function ns.PauseFishingTracking()
    archive()
    if ns.ClearFishingWaterSelection then ns.ClearFishingWaterSelection() end
    pendingLoot, fishingChannel, castForLoot=nil,nil,nil
end
function ns.ResetFishingSession()
    ns.PauseFishingTracking()
    refresh()
end
function ns.FishingCommand(input)
    local cmd=(input or ""):lower():match("^%s*(.-)%s*$")
    if cmd=="off" or cmd=="on" then
        ns.SetFeatureEnabled("fishing",cmd=="on")
        print(ns.title.." - Fishing advice "..cmd..".")
    elseif cmd=="reset" then
        ns.ResetFishingSession()
    elseif not ns.FeatureEnabled("fishing") then
        print(ns.title.." - Fishing advice is off. Type /wyh fish on to enable it.")
    elseif not ns.FeatureEnabled("prices") then
        print(session and (session.water.." - "..session.casts.." observed casts.") or (ns.title.." - Cast to start a fishing session."))
    else
        local r=ns.GetFishingEstimate()
        print(r and details(r) or (ns.title.." - Cast to start a fishing session."))
    end
end
