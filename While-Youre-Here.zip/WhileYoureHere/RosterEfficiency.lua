local _, ns = ...

-- Item identities for the English route labels in CraftNextData. The catalogue
-- supplies verified recipe quantities. In-game bags are indexed by item ID.
local names = {
    [2447]="Peacebloom", [765]="Silverleaf", [785]="Mageroyal", [2449]="Earthroot",
    [2450]="Briarthorn", [3820]="Stranglekelp", [3356]="Kingsblood", [3821]="Goldthorn",
    [3358]="Khadgar's Whisker", [8836]="Arthas' Tears", [8838]="Sungrass", [8839]="Blindweed",
    [13466]="Plaguebloom", [730]="Murloc Eye", [8831]="Purple Lotus", [3383]="Elixir of Wisdom",
    [3371]="Empty Vial", [3372]="Leaded Vial", [8925]="Crystal Vial",
    [2840]="Copper Bar", [2841]="Bronze Bar", [2842]="Silver Bar", [3575]="Iron Bar",
    [3859]="Steel Bar", [3860]="Mithril Bar", [12359]="Thorium Bar", [12360]="Arcanite Bar",
    [6037]="Truesilver Bar", [249726]="Azerothium Bar", [2835]="Rough Stone", [2836]="Coarse Stone",
    [2838]="Heavy Stone", [7912]="Solid Stone", [12365]="Dense Stone",
    [3478]="Coarse Grinding Stone", [3486]="Heavy Grinding Stone", [7966]="Solid Grinding Stone",
    [12644]="Dense Grinding Stone", [3466]="Strong Flux", [2880]="Weak Flux",
    [7082]="Essence of Air", [1206]="Moss Agate",
    [1210]="Shadowgem", [7910]="Star Ruby", [12799]="Large Opal",
    [7971]="Black Pearl", [13926]="Golden Pearl", [5500]="Iridescent Pearl",
    [4357]="Rough Blasting Powder", [4359]="Handful of Copper Bolts", [4364]="Coarse Blasting Powder",
    [4371]="Bronze Tube", [4375]="Whirring Bronze Gizmo", [4382]="Bronze Framework",
    [4377]="Heavy Blasting Powder", [10505]="Solid Blasting Powder", [10560]="Unstable Trigger",
    [10561]="Mithril Casing", [7071]="Iron Buckle",
    [2934]="Ruined Leather Scraps", [2318]="Light Leather", [2319]="Medium Leather",
    [4234]="Heavy Leather", [4304]="Thick Leather", [8170]="Rugged Leather", [783]="Light Hide",
    [4232]="Medium Hide", [4235]="Heavy Hide", [4231]="Cured Light Hide", [4233]="Cured Medium Hide",
    [4236]="Cured Heavy Hide", [4289]="Salt", [4246]="Fine Leather Belt", [2320]="Coarse Thread",
    [2321]="Fine Thread", [4291]="Silken Thread", [8343]="Heavy Silken Thread", [14341]="Rune Thread",
    [2589]="Linen Cloth", [2592]="Wool Cloth", [4306]="Silk Cloth", [4338]="Mageweave Cloth",
    [14047]="Runecloth", [2996]="Bolt of Linen Cloth", [2997]="Bolt of Woolen Cloth",
    [4305]="Bolt of Silk Cloth", [4339]="Bolt of Mageweave", [14048]="Bolt of Runecloth",
    [14227]="Ironweb Spider Silk", [2325]="Black Dye", [2604]="Red Dye", [2605]="Green Dye", [4340]="Gray Dye",
    [10940]="Strange Dust", [10938]="Lesser Magic Essence", [10998]="Lesser Astral Essence",
    [11082]="Greater Astral Essence", [11083]="Soul Dust", [11135]="Greater Mystic Essence",
    [11137]="Vision Dust", [11176]="Dream Dust", [16204]="Illusion Dust", [16203]="Greater Eternal Essence",
    [14343]="Small Brilliant Shard", [14344]="Large Brilliant Shard", [247786]="Mote of Magic",
    [6217]="Copper Rod", [6338]="Silver Rod", [11128]="Golden Rod", [11144]="Truesilver Rod",
    [16206]="Arcanite Rod", [4470]="Simple Wood",
}
local ids, ingredients = {}, {}
for id,name in pairs(names) do ids[name]=id end
function ns.EfficiencyMaterialName(id) return names[id] end
function ns.EfficiencyIngredients(profession,recipe)
    if not recipe or type(recipe.materials)~="string" or recipe.materials=="" then return nil,false end
    local cached=ingredients[recipe]
    if not cached then
        local byID,complete={},true
        for raw in recipe.materials:gmatch("[^,]+") do
            local amount,name=raw:match("^%s*(%d+)%s+(.+)%s*$")
            local id=ids[name]
            if id then byID[id]=(byID[id] or 0)+tonumber(amount) else complete=false end
        end
        cached={byID,complete}
        ingredients[recipe]=cached
    end
    return cached[1],cached[2]
end

-- Undiscounted vendor purchases. Vials are sold in packs of five.
-- wowfah.com/npc/glyx-brewright-2848 ; wow-forever.gg/vendors/
-- zephras.com/forever/enUS/profession-guide/197/
local vendor={
    [2320]={10,1}, [2321]={100,1}, [4291]={500,1}, [8343]={2000,1},
    [14341]={5000,1}, [2325]={1000,1}, [4340]={350,1}, [2604]={50,1},
    [3371]={20,5}, [3372]={200,5}, [8925]={2500,5}, [247786]={10,1},
}

-- questing.wiki/wow-forever/legacy/ includes launch and alternate criterion IDs.
local crafts={
    Alchemy={62012,63996}, Blacksmithing={62015,63999}, Enchanting={62018,64002},
    Engineering={62021,64005}, Leatherworking={62024,64008}, Tailoring={62028,64011},
}
local classes={
    WARRIOR={61499,61500,61501,63969}, DRUID={61502,61503,61504,63972},
    HUNTER={61989,61992,61993,63975}, MAGE={61994,61995,61996,63978},
    PALADIN={61997,61998,61999,63981}, PRIEST={62000,62001,62002,63984},
    ROGUE={62003,62004,62005,63987}, SHAMAN={62006,62007,62008,63990}, WARLOCK={62009,62010,62011,63993},
}
local tiers,levels,minLevel={150,225,300},{25,45,60},{10,20,35}
local function earned(id)
    if not GetAchievementInfo then return false end
    local ok,_,_,_,done=pcall(GetAchievementInfo,id)
    return ok and done==true
end
local function getCraftGoal(s,profession,rows)
    local history=ns.DB().history[s.mode] or {}
    -- Hardcore challenge completions also apply to standard rulesets.
    local hc=s.mode=="normal" and ns.DB().history.hardcore or {}
    local high=math.max(history[profession] or 0,hc and hc[profession] or 0)
    local ach=crafts[profession]
    if not ach then return end
    for _,r in ipairs(rows) do
        local applies=r.mode==s.mode or (s.mode=="normal" and r.mode=="hardcore")
        local sk=applies and r.skills and r.skills[profession]
        if sk then high=math.max(high,sk.rank) end
    end
    for i,target in ipairs(tiers) do
        if high<target and not earned(ach[1]+i-1) and not earned(ach[2]+i-1) then return target,minLevel[i] end
    end
end

local function prefs(s)
    local settings=ns.DB().settings
    settings.efficiencyGoals=settings.efficiencyGoals or {}
    local byMode=settings.efficiencyGoals
    byMode[s.mode]=byMode[s.mode] or {}
    return byMode[s.mode]
end
function ns.IsLevellingMain(s)
    return s and prefs(s).main==s.key or false
end
function ns.CraftFocusGoal(s,profession)
    if not s or s.mode~="normal" or not crafts[profession] or not (s.skills and s.skills[profession]) then return end
    return getCraftGoal(s,profession,ns.GetRosterRows())
end
function ns.SetLevellingMain(s)
    if not s or not s.key then return end
    local p=prefs(s)
    if p.main==s.key then p.main=nil else p.main=s.key end
    if ns.RequestRefresh then ns.RequestRefresh() end
end
function ns.CraftIsFocus(s,profession)
    if not s or not profession or s.mode~="normal" then return false end
    local f=prefs(s).focus
    return f and f.key==s.key and f.prof==profession and s.skills and s.skills[profession]
        and f.goal==getCraftGoal(s,profession,ns.GetRosterRows()) or false
end
function ns.ToggleCraftFocus(s,profession)
    if not s or s.mode~="normal" or not crafts[profession] or not (s.skills and s.skills[profession]) then return end
    local p=prefs(s)
    if ns.CraftIsFocus(s,profession) then p.focus=nil
    else
        local goal=getCraftGoal(s,profession,ns.GetRosterRows())
        if goal then p.focus={key=s.key,prof=profession,goal=goal} end
    end
    if ns.RequestRefresh then ns.RequestRefresh() end
end

function ns.CanShareCraftStock(a,b)
    if not a or not b or not a.faction or a.faction~=b.faction or a.mode~=b.mode then return false end
    if a.mailScope and b.mailScope then return a.mailScope==b.mailScope end
    return a.realm and a.realm~="" and a.realm~="?" and a.realm==b.realm or false
end

local function route(s,r,prof,skill,goal,level)
    local p={owner=r,prof=prof,skill=skill,goal=goal,level=level,left=goal-skill.rank,
        need={},missing={},held={},complete=true,ready=r.level and r.level>=level and skill.cap>=goal}
    local produced={}
    local rank=skill.rank
    while rank<goal do
        local recipe,stop=ns.CraftRouteRecipe(prof,rank,r)
        if not recipe or not stop or stop<=rank then p.complete=false; break end
        if rank==skill.rank then p.next=recipe end
        local count=math.min(goal,stop)-rank
        local materials,complete=ns.EfficiencyIngredients(prof,recipe)
        if not complete then p.complete=false end
        for id,n in pairs(materials or {}) do
            local required=n*count
            local used=math.min(required,produced[id] or 0)
            produced[id]=(produced[id] or 0)-used
            p.need[id]=(p.need[id] or 0)+required-used
        end
        -- One retained unit per craft is conservative for variable-yield recipes.
        local product=ids[recipe.name]
        if product then produced[product]=(produced[product] or 0)+count end
        local known=r.known and r.known[recipe.spell]
        if r.key==s.key and ns.NextRecipeStatus then known=ns.NextRecipeStatus(s,recipe.spell)=="known" end
        if not known and recipe.source~="ability" then
            p.unseenRecipe=p.unseenRecipe or recipe.name
            if recipe.item then
                local bags=(r.key==s.key and s.bagsScanned and s.bags) or r.bagMaterials or {}
                if (bags[recipe.item] or 0)>0 then
                    p.book=p.book or ("Read the "..recipe.name.." recipe in bags.")
                elseif ((r.bankMaterials or {})[recipe.item] or 0)>0 then
                    p.book=p.book or ("Collect the "..recipe.name.." recipe from the recorded bank.")
                else p.unlock=p.unlock or recipe end
            elseif recipe.source=="quest" then p.unlock=p.unlock or recipe end
        end
        rank=rank+count
    end
    return p
end

local function recordedStock(s,r,place,id,mail)
    if place=="bag" and r.key==s.key and s.bagsScanned and not mail then return (s.bags or {})[id] or 0 end
    local all=r[place.."Materials"] or {}
    if not mail then return all[id] or 0 end
    local transferable=r[place.."Mailable"]
    if transferable then return transferable[id] or 0 end
    -- Old snapshots only prove that an item ID existed. A belt can be soulbound.
    return id~=4246 and names[id] and (all[id] or 0) or 0
end

local function assign(s,p,rows,reserved)
    local order={p.owner}
    for _,r in ipairs(rows) do
        if r.key~=p.owner.key and ns.CanShareCraftStock(r,p.owner) then order[#order+1]=r end
    end
    p.fromAlts,p.fromBank,p.locations=0,0,{}
    for id,total in pairs(p.need) do
        local left=total
        for _,donor in ipairs(order) do
            local other=donor.key~=p.owner.key
            for _,place in ipairs({"bag","bank"}) do
                local stockKey=donor.key.."|"..place
                local used=reserved and reserved[stockKey] and reserved[stockKey][id] or 0
                local available=math.max(0,recordedStock(s,donor,place,id,other)-used)
                local take=math.min(left,available)
                if take>0 then
                    local stock=p.held[stockKey] or {}
                    p.held[stockKey]=stock
                    stock[id]=take
                    left=left-take
                    if other or place=="bank" then
                        local loc=p.locations[stockKey] or {name=donor.name,place=place,stamp=donor[place.."Seen"],total=0}
                        p.locations[stockKey]=loc
                        loc.total=loc.total+take
                    end
                    if other then p.fromAlts=p.fromAlts+take end
                    if place=="bank" then p.fromBank=p.fromBank+take end
                end
            end
            if left==0 then break end
        end
        if left>0 then p.missing[id]=left end
    end
end

local function pricePlan(s,p,quotes)
    local sameMarket=p.owner.key==s.key or ns.CanShareCraftStock(s,p.owner)
    local scope=sameMarket and ns.MarketKey and ns.MarketKey(s.faction)
    local useAH=scope and scope==ns.MarketKey()
    local cost,value,missingTotal=0,0,0
    local pricedCost,pricedValue=p.complete,p.complete
    for id,total in pairs(p.need) do
        if total>0 then
            local ah
            if useAH and ns.MarketQuote then
                if quotes[id]==nil then
                    local price,age=ns.MarketQuote(id)
                    quotes[id]=type(price)=="number" and price>0 and type(age)=="number" and age<=7 and price or false
                end
                ah=quotes[id]
            end
            local shop=vendor[id]
            local unit=ah or nil
            if shop then unit=math.min(unit or math.huge,shop[1]/shop[2]) end
            local missing=p.missing[id] or 0
            local owned=total-missing
            if owned>0 then
                if unit then value=value+owned*unit else pricedValue=false end
            end
            if missing>0 then
                missingTotal=missingTotal+missing
                local paid=ah and missing*ah or nil
                if shop then paid=math.min(paid or math.huge,math.ceil(missing/shop[2])*shop[1]) end
                if paid then cost=cost+paid else pricedCost=false end
            end
        end
    end
    p.cash=pricedCost and cost or nil
    p.stockValue=pricedValue and value or nil
    p.missingCount=missingTotal
end

local function classChoices(s,rows,history,main)
    local highs,choices={},{}
    for class,level in pairs(history.classLevels or {}) do highs[class]=level end
    local hc=ns.DB().history.hardcore or {}
    if s.mode=="normal" then
        for class,level in pairs(hc.classLevels or {}) do highs[class]=math.max(highs[class] or 0,level) end
    end
    for _,r in ipairs(rows) do
        if (r.mode==s.mode or (s.mode=="normal" and r.mode=="hardcore")) and classes[r.class] and r.level then
            highs[r.class]=math.max(highs[r.class] or 0,r.level)
        end
    end
    for class,high in pairs(highs) do
        local a=classes[class]
        if a then
            for i,goal in ipairs(levels) do
                if high<goal and not earned(a[i]) and not earned(a[4]+i-1) then
                    for _,r in ipairs(rows) do
                        if r.mode==s.mode and r.class==class and (r.level or 0)>0 and r.level<goal then
                            choices[#choices+1]={owner=r,goal=goal,left=goal-r.level}
                        end
                    end
                    break
                end
            end
        end
    end
    table.sort(choices,function(a,b)
        if a.left~=b.left then return a.left<b.left end
        if (a.owner.key==main)~=(b.owner.key==main) then return a.owner.key==main end
        return a.owner.key<b.owner.key
    end)
    return choices
end

-- Rank accessible goals before gated goals. When both purchase estimates are
-- complete, prioritise the smaller cash outlay. Unknown prices remain unknown.
local function compare(a,b)
    if a.focus~=b.focus then return a.focus end
    if a.gate~=b.gate then return a.gate<b.gate end
    if a.complete~=b.complete then return a.complete end
    if (a.cash~=nil)~=(b.cash~=nil) then return a.cash~=nil end
    if a.cash and a.cash~=b.cash then return a.cash<b.cash end
    if a.left~=b.left then return a.left<b.left end
    if a.stockValue and b.stockValue and a.stockValue~=b.stockValue then return a.stockValue<b.stockValue end
    if (a.stockValue~=nil)~=(b.stockValue~=nil) then return a.stockValue~=nil end
    if a.main~=b.main then return a.main end
    if a.prof~=b.prof then return a.prof<b.prof end
    return a.owner.key<b.owner.key
end

function ns.EfficiencyLPPlans(s,rows)
    if not s or s.mode~="normal" then return {},{} end
    rows=rows or ns.GetRosterRows()
    local saved=prefs(s)
    local focus,plans,quotes=nil,{},{}
    for prof in pairs(crafts) do
        local goal,level=getCraftGoal(s,prof,rows)
        if goal then
            for _,r in ipairs(rows) do
                local skill=r.mode==s.mode and r.skills and r.skills[prof]
                if r.key==s.key then skill=s.skills and s.skills[prof] end
                if skill and type(skill.rank)=="number" and type(skill.cap)=="number" and skill.rank<goal then
                    local p=route(s,r,prof,skill,goal,level)
                    p.main=saved.main==r.key
                    p.focus=saved.focus and saved.focus.key==r.key and saved.focus.prof==prof and saved.focus.goal==goal or false
                    if p.focus then focus=p end
                    if (r.level or 0)<level then p.gate=3
                    elseif skill.cap<goal then p.gate=2
                    elseif p.unlock then p.gate=1 else p.gate=0 end
                    plans[#plans+1]=p
                end
            end
        end
    end
    if focus then assign(s,focus,rows) end
    for _,p in ipairs(plans) do
        if p~=focus then assign(s,p,rows,focus and focus.held) end
        pricePlan(s,p,quotes)
    end
    table.sort(plans,compare)
    local unique,seen={},{}
    for _,p in ipairs(plans) do
        if not seen[p.prof] then unique[#unique+1]=p; seen[p.prof]=true end
    end
    return unique,classChoices(s,rows,ns.DB().history[s.mode] or {},saved.main),focus
end

local function coins(n)
    n=math.floor(n+0.5)
    if n<100 then return n.."c" end
    if n<10000 then return math.floor(n/100).."s "..(n%100).."c" end
    return math.floor(n/10000).."g "..(math.floor(n/100)%100).."s"
end
local function shortList(materials,limit)
    local ordered={}
    for id,n in pairs(materials) do if n>0 then ordered[#ordered+1]={id=id,n=n} end end
    table.sort(ordered,function(a,b)
        if a.n~=b.n then return a.n>b.n end
        return a.id<b.id
    end)
    local list={}
    for i=1,math.min(limit,#ordered) do
        local row=ordered[i]
        list[#list+1]=row.n.." "..names[row.id]
    end
    if #ordered>limit then list[#list+1]="+"..(#ordered-limit).." more types" end
    return table.concat(list,", ")
end
local function describe(s,p)
    local lines={p.skill.rank.."/"..p.skill.cap.." · "..p.left.." skill-up"..(p.left==1 and "" or "s").." for 1 LP."}
    if (p.owner.level or 0)<p.level then lines[#lines+1]="Requires character level "..p.level.."."
    elseif p.skill.cap<p.goal then lines[#lines+1]="Train the next rank to reach "..p.goal.."." end
    if p.unlock then lines[#lines+1]="Check access to "..p.unlock.name.." ("..(p.unlock.source=="quest" and "quest" or "recipe")..")."
    elseif p.book then lines[#lines+1]=p.book
    elseif p.unseenRecipe then lines[#lines+1]="Confirm or learn "..p.unseenRecipe.."." end
    if p.cash~=nil then lines[#lines+1]="Estimated purchases "..coins(p.cash).."."
    elseif p.complete then lines[#lines+1]="Missing recent prices for purchases."
    else lines[#lines+1]="Partial route estimate." end
    if p.stockValue and p.stockValue>0 then lines[#lines+1]="Owned materials used, about "..coins(p.stockValue).." to replace."
    elseif not p.stockValue and (p.missingCount==0 or next(p.held)) then lines[#lines+1]="Owned materials have an incomplete valuation." end
    local short=shortList(p.missing,3)
    if short~="" then lines[#lines+1]="Short on record: "..short.."." end
    local locations={}
    for key,loc in pairs(p.locations) do
        local when=loc.stamp and date and (", "..date("%d %b",loc.stamp)) or ""
        locations[#locations+1]={key=key,n=loc.total,where=loc.name.." ("..(loc.place=="bank" and "bank" or "bags")..when..")"}
    end
    table.sort(locations,function(a,b)
        if a.n~=b.n then return a.n>b.n end
        return a.key<b.key
    end)
    if #locations>0 then
        local loc=locations[1]
        lines[#lines+1]="Collect "..shortList(p.held[loc.key],2).." from "..loc.where.."."
        if #locations>1 then lines[#lines+1]=(#locations-1).." other recorded stock location(s)." end
    end
    if p.owner.key~=s.key and p.owner.seen and date then lines[#lines+1]="Last seen "..date("%d %b",p.owner.seen).."." end
    return table.concat(lines," ")
end

function ns.AddEfficiencyLP(s,add,tab,rows)
    if s.mode~="normal" then return end
    local plans,classesLeft,focus=ns.EfficiencyLPPlans(s,rows)
    local first=plans[1]
    if tab=="now" then
        if first and first.ready and first.left<=10 and first.next and not first.unseenRecipe then
            add(first.owner.name.." · "..first.prof.." "..first.goal,describe(s,first).." See Alts for the comparison.",
                24,"craft-goal:"..first.prof..":"..first.goal,nil,true)
        end
        return focus
    end
    local c=classesLeft[1]
    if c then
        local main=ns.IsLevellingMain(c.owner) and " Also advances your main towards 60." or ""
        add(c.owner.name.." · level "..c.goal.." for 1 LP",c.owner.level.." now. "..c.left.." character level"..(c.left==1 and "" or "s")
            .." to the closest recorded class milestone."..main,3,"class-goal:"..c.owner.key..":"..c.goal)
    end
    if not first then return end
    local note="One craft per skill-up, with components reused. Yellow and green crafts can take more. Material prices use base vendor packs or AH quotes up to 7 days old. Training, tools, recipes and postage are extra."
    if focus then note=note.." Materials assigned to "..focus.owner.name.."'s "..focus.prof.." goal are excluded from other estimates."
    else note=note.." Compare one goal at a time. A shared stack can fund one choice." end
    add("Compare crafting Legacy Points",note.." Eligible crafts with complete purchase prices are ordered by estimated spend, then skill-ups. Check account credit in Legacy (Y).",4,"craft-compare")
    for i,p in ipairs(plans) do
        local prefix=p.focus and "Prioritised · " or ""
        add(prefix..p.owner.name.." · "..p.prof.." "..p.goal,describe(s,p),5+i/100,"craft-goal:"..p.prof..":"..p.goal)
    end
end

