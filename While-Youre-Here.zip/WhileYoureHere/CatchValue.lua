local _, ns = ...
local pending = {}

-- GetItemInfo reports merchant proceeds for one item, even when the bag tooltip
-- shows the total for a stack. A nil return means item data is not loaded yet.
local function vendorPrice(id, link)
    local lookup = (C_Item and C_Item.GetItemInfo) or GetItemInfo
    if not lookup then return end
    local item = type(link) == "string" and tonumber(link:match("item:(%d+)")) == id and link or id
    local copper = select(11, lookup(item))
    if type(copper) == "number" and copper >= 0 then
        pending[id] = nil
        return copper
    end

    local now = GetTime()
    if not pending[id] or now - pending[id] >= 30 then
        pending[id] = now
        if C_Item and C_Item.RequestLoadItemDataByID then
            C_Item.RequestLoadItemDataByID(id)
        end
    end
end

local itemEvents = CreateFrame("Frame")
itemEvents:RegisterEvent("GET_ITEM_INFO_RECEIVED")
pcall(itemEvents.RegisterEvent, itemEvents, "ITEM_DATA_LOAD_RESULT")
itemEvents:SetScript("OnEvent", function(_, _, id, success)
    if success and pending[id] then
        pending[id] = nil
        if ns.RequestRefresh then ns.RequestRefresh() end
    end
end)

-- Value of a successful sale, in copper per item. Apply the cut only to the
-- auction route. Keep sub-copper estimates until the stack or rate is displayed.
function ns.CatchSaleValue(id, link)
    local vendor = vendorPrice(id, link)
    local ah, age, source, offers = ns.MarketQuote(id, link)
    local _, _, fee = ns.MarketKey()
    local assumedFee = false
    if not fee then
        local choice = ns.DB().settings.saleMarket
        assumedFee = choice ~= "faction" and choice ~= "neutral"
        fee = choice == "faction" and 0.05 or 0.15
    end
    local netAH = ah and ah * (1 - fee)
    local value, method
    if vendor and vendor > 0 and (not netAH or vendor >= netAH) then
        value, method = vendor, "vendor"
    elseif netAH then
        value, method = netAH, "auction"
    end
    local localQuote = source == "manual" or source == "native"
    local comparable = ah ~= nil and localQuote and age ~= nil and age >= 0 and age <= 7
        and not assumedFee and vendor ~= nil
    local info = {
        value=value, method=method, vendor=vendor, vendorPending=vendor==nil,
        ah=ah, netAH=netAH, age=age, source=source, offers=offers, fee=fee, assumedFee=assumedFee,
        floorOnly=method=="vendor" and ah==nil, approximate=ah~=nil and not comparable,
        comparable=comparable,
    }
    return value, method, info
end
