local _, ns = ...

-- Sources: https://www.wowhead.com/forever/guide/professions/cooking/overview-leveling
-- https://zephras.com/forever/enUS/profession/185/ (ingredients and skill colours).
-- The spell and recipe-item pages on Wowhead Forever give the buff and recorded drop.
ns.HealingTeas = {
    {name="Peace Tea", spell=1249957, recipe=249879, itemID=249865, skill=25, yellow=30, green=37, grey=45,
        level=1, power=2, drink=159, herb=2447, materials="1 Refreshing Spring Water and 2 Peacebloom",
        mob="Frostmane Seer", zone="Dun Morogh", mapID=1426, huntLevel=8},
    {name="Royal Tea", spell=1249958, recipe=249880, itemID=249866, skill=100, yellow=105, green=115, grey=125,
        level=5, power=7, drink=1179, herb=785, materials="1 Ice Cold Milk and 2 Mageroyal",
        mob="Windshear Geomancer", zone="Stonetalon Mountains", mapID=1442, huntLevel=21},
    {name="Root Tea", spell=1249959, recipe=249881, itemID=249867, skill=125, yellow=155, green=170, grey=185,
        level=15, power=11, drink=1205, herb=3357, materials="1 Melon Juice and 2 Liferoot",
        mob="Torn Fin Oracle", zone="Hillsbrad Foothills", mapID=1424, huntLevel=30},
    {name="Triage Tea", spell=1249960, recipe=249882, itemID=249868, skill=180, yellow=195, green=215, grey=235,
        level=25, power=22, drink=1708, herb=3818, materials="1 Sweet Nectar and 2 Fadeleaf",
        mob="Woodpaw Mystic", zone="Feralas", mapID=1444, huntLevel=42},
    {name="Sunny Tea", spell=1249961, recipe=249883, itemID=249869, skill=200, yellow=220, green=235, grey=250,
        level=35, power=33, drink=1645, herb=8838, materials="1 Moonberry Juice and 2 Sungrass",
        mob="Marsh Oracle", zone="Swamp of Sorrows", mapID=1435, huntLevel=44},
    {name="Sage's Tea", spell=1249962, recipe=249884, itemID=249870, skill=250, yellow=260, green=275, grey=290,
        level=45, power=44, drink=8766, herb=13465, materials="1 Morning Glory Dew and 2 Mountain Silversage",
        mob="Deadwind Ogre Mage", zone="Deadwind Pass", mapID=1430, huntLevel=55},
}

local function option(s, tea, grey, explicitFood)
    local bags = s.bags or {}
    local status = ns.NextRecipeStatus(s, tea.spell)
    if grey and status ~= "known" then return end
    local held = status ~= "known" and ns.RecipeItemHeld(s, tea.recipe)
    local ready = math.min(bags[tea.drink] or 0, math.floor((bags[tea.herb] or 0) / 2))
    local source, priority
    if status == "known" then
        priority = ready > 0 and 6 or 3
    elseif held then
        source = held == "bags" and "Read the recipe in your bags." or "Collect the recipe from your bank."
        priority = ready > 0 and 5 or 2
    elseif status == "missing" and (explicitFood or (s.mapID == tea.mapID and s.level >= tea.huntLevel)) then
        source = "The recipe drops from " .. tea.mob .. " in " .. tea.zone .. "."
        if s.level < tea.huntLevel then source = source .. " The mobs are about level " .. tea.huntLevel .. "." end
        priority = 1
    elseif status == "unknown" and (ready > 0 or explicitFood) then
        source = "Open Cooking to check " .. tea.name .. "."
        priority = 1
    else
        return
    end
    return {
        name=tea.name, spell=tea.spell, itemID=tea.itemID, skill=tea.skill, yellow=tea.yellow,
        green=tea.green, grey=tea.grey, buff="+" .. tea.power .. " Healing Power", materials=tea.materials,
        ready=ready, status=status, held=held, source=source, isGrey=grey,
    }, priority
end

function ns.HealingFoodOption(s, rank, explicitFood)
    local cooking = s.skills and s.skills.Cooking
    rank = rank or (cooking and cooking.rank)
    if not rank or not s.level then return end
    local best, bestPriority
    -- Stronger buffs break ties when two known recipes can both skill up.
    for i = #ns.HealingTeas, 1, -1 do
        local tea = ns.HealingTeas[i]
        local grey = rank >= tea.grey
        if s.level >= tea.level and rank >= tea.skill and (not grey or explicitFood) then
            local result, priority = option(s, tea, grey, explicitFood)
            if result and (not bestPriority or priority > bestPriority or
                    (priority == bestPriority and best.isGrey and not grey)) then
                best, bestPriority = result, priority
            end
        end
    end
    return best
end
