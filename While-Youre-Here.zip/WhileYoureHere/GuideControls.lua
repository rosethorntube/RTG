local _, ns = ...
-- A bounded list fits a small guide window even when the zone catalogue grows.
function ns.CreateGuideControls(panel, button, style, template, selectTab, refresh)
    local menu=CreateFrame("Frame",nil,panel,template)
    menu:SetFrameStrata("FULLSCREEN_DIALOG")
    menu:SetClampedToScreen(true)
    menu:EnableMouse(true)
    style(menu,.07,.075,.067,1)
    local page, options, picked, anchor = 1, {}, nil, nil
    local entries={}
    local function repaint()
        local first=(page-1)*7
        for i,b in ipairs(entries) do
            local item=options[first+i]
            if item then b.label:SetText(item.name); b:Show() else b:Hide() end
        end
        local pages=math.max(1,math.ceil(#options/7))
        local paged=pages>1
        menu.prev:SetShown(paged)
        menu.next:SetShown(paged)
        menu.prev:SetEnabled(page>1)
        menu.next:SetEnabled(page<pages)
        menu:SetHeight(9+math.min(7,#options)*24+(paged and 25 or 0))
    end
    for i=1,7 do
        local index=i
        local b=button(menu,"",248,22,function()
            local item=options[(page-1)*7+index]
            menu:Hide()
            if item then picked(item); refresh() end
        end)
        b:SetPoint("TOPLEFT",4,-4-(i-1)*24)
        b.label:SetWidth(240)
        b.label:SetWordWrap(false)
        entries[i]=b
    end
    menu.prev=button(menu,"Previous",119,22,function() page=math.max(1,page-1);repaint() end)
    menu.next=button(menu,"Next",119,22,function() page=math.min(math.ceil(#options/7),page+1);repaint() end)
    menu.prev:SetPoint("BOTTOMLEFT",4,4);menu.next:SetPoint("BOTTOMRIGHT",-4,4)
    menu:SetWidth(256)
    menu:Hide()
    local function choose(b, items, action)
        if menu:IsShown() and anchor==b then menu:Hide();return end
        page,options,picked,anchor=1,items,action,b
        menu:ClearAllPoints()
        menu:SetPoint("TOPLEFT",b,"BOTTOMLEFT",0,-1)
        repaint();menu:Show()
    end
    local controls={}
    local function control(key,label,width,x,y,action)
        local b=button(panel,label,width,22,action)
        b:SetPoint("TOPLEFT",x,y)
        b:Hide()
        controls[key]=b
        return b
    end
    local goalLabels={cooking="Cooking skill",food="Food for my build",gold="Gold"}
    local goals={{name="Cooking skill",id="cooking"},{name="Food for my build",id="food"},{name="Gold",id="gold"}}
    control("goal","",155,12,-91,function(b)
        choose(b,goals,function(item) ns.SetFishingGoal(ns.state,item.id) end)
    end)
    control("water","Log water...",140,172,-91,function(b)
        local items={{name="Stop labelling casts"}}
        local current=ns.CurrentFishingWaterSelection(ns.state)
        for _,spot in ipairs(ns.FishingWaterChoices(ns.state)) do
            items[#items+1]={name=(spot==current and "* " or "")..spot.water,spot=spot}
        end
        choose(b,items,function(item) ns.SelectFishingWaterSample(ns.state,item.spot) end)
    end)
    control("review","Before you skip ahead",163,12,-65,function() selectTab("skip") end)
    control("zone","",155,12,-65,function(b)
        local items={{name="Use current zone"}}
        for _,z in ipairs(ns.SkipZones(ns.state)) do items[#items+1]=z end
        choose(b,items,function(item) ns.SetSkipZone(item.mapID) end)
    end)
    control("dungeon","",162,172,-65,function(b)
        local items={{name="All dungeons"}}
        for _,entry in ipairs(ns.SkipDungeons(ns.state)) do
            local name=type(entry)=="string" and entry or entry.name
            items[#items+1]={name=name,id=name}
        end
        choose(b,items,function(item) ns.SetSkipDungeon(item.id) end)
    end)
    control("main","",180,12,-65,function() ns.SetLevellingMain(ns.state); refresh() end)
    for _,b in pairs(controls) do
        b.label:SetWidth(b:GetWidth()-6);b.label:SetWordWrap(false);b.label:SetJustifyH("CENTER")
    end
    return {
        close=function() menu:Hide() end,
        update=function(tab)
            local s=ns.state
            local fish=tab=="fishing" and ns.FeatureEnabled("fishing")
            controls.goal:SetShown(fish and ns.FeatureEnabled("fishingLocation") or false)
            controls.water:SetShown(fish or false)
            controls.review:SetShown(tab=="now" and ns.FeatureEnabled("dungeons"))
            controls.zone:SetShown(tab=="skip")
            controls.dungeon:SetShown(tab=="skip")
            controls.main:SetShown(tab=="alts" and ns.FeatureEnabled("professions"))
            if fish then
                controls.goal.label:SetText("Goal: "..goalLabels[ns.FishingGoal(s)])
                controls.water.label:SetText(ns.CurrentFishingWaterSelection(s) and "Change logged water" or "Log water...")
                controls.water:SetEnabled(#ns.FishingWaterChoices(s)>0)
            elseif tab=="skip" then
                local z=ns.SkipZone(s)
                controls.zone.label:SetText(z and z.name or "Choose zone")
                controls.dungeon.label:SetText(ns.SkipDungeon() or "All dungeons")
            elseif tab=="alts" then
                controls.main.label:SetText(ns.IsLevellingMain(s) and "Clear main to 60" or "Set as main to 60")
            end
        end
    }
end

