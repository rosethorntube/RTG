local _, ns = ...

ns.AdvisorFeatures = {
    {id="dungeons", label="Find dungeon prequests and quest givers"},
    {id="vendors", label="Spot nearby recipes and training books"},
    {id="professions", label="Plan professions and earn Legacy Points"},
    {id="materials", label="Send spare materials to the right alt"},
    {id="fishing", label="Find fishing stops and recipes for your catch"},
    {id="fishingLocation", label="Where should I fish?"},
    {id="prices", label="Compare fishing spots and auction prices"},
}

local oldCategory = {
    dungeons="Dungeons", vendors="Vendors", professions="Professions",
    materials="Professions", fishing="Fishing", prices="Fishing",
}
local function isFeature(id)
    return oldCategory[id] ~= nil or id == "fishingLocation"
end
local function featureSettings()
    local db = ns.DB()
    local settings = db.settings
    if not settings.adviceFeatures then
        local legacy = settings.tips and settings.tips.enabled or {}
        local features = {}
        for _, entry in ipairs(ns.AdvisorFeatures) do
            local category = oldCategory[entry.id]
            local enabled = legacy[category]
            if category == "Fishing" and enabled == nil then enabled = db.fishingPopup end
            features[entry.id] = enabled ~= false
        end
        settings.adviceFeatures = features
    end
    return settings.adviceFeatures
end

function ns.FeatureEnabled(id)
    return isFeature(id) and featureSettings()[id] ~= false
end

function ns.SetFeatureEnabled(id, enabled)
    if not isFeature(id) or type(enabled) ~= "boolean" then return end
    featureSettings()[id] = enabled
    if id=="fishing" and not enabled and ns.PauseFishingTracking then ns.PauseFishingTracking() end
    if ns.RefreshFeatureControls then ns.RefreshFeatureControls() end
    if ns.RequestRefresh then ns.RequestRefresh() end
end
