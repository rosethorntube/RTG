local _, ns = ...

-- Keyed by the main ingredient. Quantities in ingredients exclude that input.
-- Costs depend on the player's market. Roasted Kodo Meat yields two per craft.
ns.otherCooking = {
    [769] = {
        name = "Chunk of Boar Meat", recipe = "Roasted Boar Meat", spell = 2540,
        outputItem = 2681, outputPerCraft = 1, mainPerCraft = 1,
        skill = 1, yellow = 45, green = 65, grey = 85,
        ingredients = {},
        source = "https://www.wowhead.com/forever/spell=2540",
    },
    [5467] = {
        name = "Kodo Meat", recipe = "Roasted Kodo Meat", spell = 6414,
        outputItem = 5474, outputPerCraft = 2, mainPerCraft = 1,
        skill = 35, yellow = 75, green = 95, grey = 115,
        ingredients = {[2678] = 1},
        source = "https://www.foreverdb.app/en/forever/spells/6414/roasted-kodo-meat",
    },
    [5503] = {
        name = "Clam Meat", recipe = "Boiled Clams", spell = 6499,
        outputItem = 5525, outputPerCraft = 1, mainPerCraft = 1,
        skill = 50, yellow = 90, green = 110, grey = 130,
        ingredients = {[159] = 1},
        source = "https://zephras.com/forever/enUS/spell/6499/",
    },
    [3730] = {
        name = "Big Bear Meat", recipe = "Big Bear Steak", spell = 3397,
        outputItem = 3726, outputPerCraft = 1, mainPerCraft = 1,
        skill = 110, yellow = 150, green = 170, grey = 190,
        ingredients = {[2692] = 1},
        source = "https://www.foreverdb.app/en/forever/spells/3397/big-bear-steak",
    },
    [3685] = {
        name = "Raptor Egg", recipe = "Curiously Tasty Omelet", spell = 3376,
        outputItem = 3665, outputPerCraft = 1, mainPerCraft = 1,
        skill = 130, yellow = 170, green = 190, grey = 210,
        ingredients = {[2692] = 1},
        source = "https://www.foreverdb.app/en/forever/spells/3376/curiously-tasty-omelet",
    },
    [12184] = {
        name = "Raptor Flesh", recipe = "Roast Raptor", spell = 15855,
        outputItem = 12210, outputPerCraft = 1, mainPerCraft = 1,
        skill = 175, yellow = 215, green = 235, grey = 255,
        ingredients = {[2692] = 1},
        source = "https://bindonforever.com/spell/15855",
    },
    [12208] = {
        name = "Tender Wolf Meat", recipe = "Tender Wolf Steak", spell = 22480,
        outputItem = 18045, outputPerCraft = 1, mainPerCraft = 1,
        skill = 225, yellow = 265, green = 285, grey = 305,
        ingredients = {[3713] = 1},
        source = "https://wowforever.ninja/professions/cooking/22480-tender-wolf-steak/",
    },
    [20424] = {
        name = "Sandworm Meat", recipe = "Smoked Desert Dumplings", spell = 24801,
        outputItem = 20452, outputPerCraft = 1, mainPerCraft = 1,
        skill = 285, yellow = 325, green = 345, grey = 365,
        ingredients = {[3713] = 1}, station = "Iron Oven",
        source = "https://db.icy-veins.com/wow-forever/items/20452",
    },
}
