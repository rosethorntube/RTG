local _, ns = ...

-- Each label matches the existing profession route. Ingredients are for one craft.
-- Spell IDs and guide route: https://wowforever.fit/professions/
-- Skill colours and reagents: https://forevermastery.com/en/professions/
-- Changed Forever training ranks: https://www.stillsixty.com/recipe/
-- availableAt is a verified rank or the start of the existing guide step.
-- Alternate elixirs and equipment: https://www.wowhead.com/forever/
-- The remaining recipe-source and vendor records are kept in RecipeStopData.lua.
local catalogue

local function add(label, name, spell, availableAt, grey, materials, source, item, outputCount)
    catalogue[label] = {name=name, spell=spell, availableAt=availableAt, grey=grey,
        materials=materials, source=source, item=item, outputCount=outputCount}
end

-- Index the plan by profession and its existing step label.
local byProfession = {}
ns.CraftNextData = byProfession

catalogue = {}
byProfession.Alchemy = catalogue
add("Minor Force", "Elixir of Minor Force", 1245250, 1, 15, "1 Silverleaf, 1 Empty Vial", "starter")
add("Minor Defense", "Elixir of Minor Defense", 7183, 1, 95, "1 Silverleaf, 1 Peacebloom, 1 Empty Vial", "starter")
add("Minor Mana", "Minor Mana Potion", 2331, 55, 105, "1 Mageroyal, 1 Peacebloom, 1 Empty Vial", "trainer")
add("Minor Fortitude", "Elixir of Minor Fortitude", 2334, 50, 120, "2 Earthroot, 1 Peacebloom, 1 Empty Vial", "trainer")
add("Wisdom", "Elixir of Wisdom", 3171, 90, 160, "1 Mageroyal, 2 Briarthorn, 1 Empty Vial", "trainer")
add("Lesser Mana", "Lesser Mana Potion", 3173, 120, 185, "1 Mageroyal, 1 Stranglekelp, 1 Empty Vial", "trainer")
add("Mana", "Mana Potion", 3452, 160, 220, "1 Stranglekelp, 1 Kingsblood, 1 Leaded Vial", "trainer")
add("Agility", "Elixir of Agility", 11449, 185, 245, "1 Stranglekelp, 1 Goldthorn, 1 Leaded Vial", "trainer")
add("Greater Mana", "Greater Mana Potion", 11448, 205, 260, "1 Khadgar's Whisker, 1 Goldthorn, 1 Leaded Vial", "trainer")
add("Draught of Detect Undead", "Draught of Detect Undead", 11460, 240, 285, "1 Arthas' Tears, 1 Crystal Vial", "trainer")
add("Superior Mana", "Superior Mana Potion", 17553, 260, 315, "2 Sungrass, 2 Blindweed, 1 Crystal Vial", "pattern", 13477)
add("Major Discolored Healing Potion", "Major Discolored Healing Potion", 1231583, 270, 330, "1 Crystal Vial, 1 Plaguebloom, 1 Murloc Eye", "quest")
add("Minor Arcane Elixir", "Minor Arcane Elixir", 1245246, 1, 15, "1 Peacebloom, 1 Empty Vial", "starter")
add("Elixir of Minor Strength", "Elixir of Minor Strength", 2329, 15, 95, "1 Earthroot, 1 Silverleaf, 1 Empty Vial", "trainer")

catalogue = {}
byProfession.Blacksmithing = catalogue
add("Rough Sharpening", "Rough Sharpening Stone", 2660, 1, 55, "1 Rough Stone", "starter")
add("Rough Grinding", "Rough Grinding Stone", 3320, 25, 85, "2 Rough Stone", "trainer")
add("Copper Chain Belt", "Copper Chain Belt", 2661, 30, 110, "6 Copper Bar", "trainer")
add("Coarse Grinding", "Coarse Grinding Stone", 3326, 50, 90, "2 Coarse Stone", "trainer")
add("Runed Copper Belt", "Runed Copper Belt", 2666, 45, 125, "10 Copper Bar", "trainer")
add("Heavy Sharpening", "Heavy Sharpening Stone", 2674, 100, 115, "1 Heavy Stone", "trainer")
-- Forever's grinding stones remain usable as components after turning grey.
-- Current training ranks: wowforever.ninja/professions/blacksmithing/ and foreverdb.app.
add("Heavy Grinding Stone", "Heavy Grinding Stone", 3337, 100, 125, "3 Heavy Stone", "trainer")
add("Solid Grinding Stone", "Solid Grinding Stone", 9920, 175, 185, "4 Solid Stone", "trainer")
add("Dense Grinding Stone", "Dense Grinding Stone", 16639, 225, 235, "4 Dense Stone", "trainer")
add("Rough Bronze Leggings", "Rough Bronze Leggings", 2668, 80, 150, "6 Bronze Bar", "trainer")
add("Iron Buckle", "Iron Buckle", 8768, 125, 130, "1 Iron Bar", "trainer", nil, 2)
add("Bronze Warhammer", "Bronze Warhammer", 9985, 125, 185, "8 Bronze Bar, 1 Strong Flux, 1 Medium Leather", "trainer")
add("Patterned Bronze Bracers", "Patterned Bronze Bracers", 2672, 95, 155, "5 Bronze Bar, 2 Coarse Grinding Stone", "trainer")
add("Green Iron Bracers", "Green Iron Bracers", 3501, 140, 190, "6 Iron Bar, 1 Green Dye", "trainer")
add("Green Iron Leggings", "Green Iron Leggings", 3506, 130, 180, "8 Iron Bar, 1 Heavy Grinding Stone, 1 Green Dye", "trainer")
add("Heavy Mithril Gauntlet", "Heavy Mithril Gauntlet", 9928, 180, 220, "6 Mithril Bar, 4 Mageweave Cloth", "trainer")
add("Golden Scale Bracers", "Golden Scale Bracers", 7223, 160, 210, "5 Steel Bar, 2 Heavy Grinding Stone", "trainer")
add("Mithril Plate Pants", "Mithril Plate Pants", 9931, 180, 225, "12 Mithril Bar", "trainer")
add("Heavy Mithril Breastplate", "Heavy Mithril Breastplate", 9959, 205, 245, "16 Mithril Bar", "trainer")
add("Dense Weightstone", "Dense Weightstone", 16640, 225, 235, "1 Dense Stone", "trainer")
add("Mithril Coif", "Mithril Coif", 9961, 235, 245, "10 Mithril Bar, 6 Mageweave Cloth", "trainer")
add("Heavy Mithril Boots", "Heavy Mithril Boots", 9968, 210, 250, "14 Mithril Bar, 4 Thick Leather", "trainer")
add("Big Black Mace", "Big Black Mace", 10001, 246, 255, "16 Mithril Bar, 1 Black Pearl, 4 Shadowgem, 1 Solid Grinding Stone, 2 Thick Leather", "trainer")
add("Arcanite Skeleton Key", "Arcanite Skeleton Key", 19669, 250, 260, "1 Arcanite Bar, 1 Dense Grinding Stone", "trainer")
add("Ebon Shiv", "Ebon Shiv", 10013, 230, 280, "12 Mithril Bar, 6 Truesilver Bar, 2 Star Ruby, 1 Solid Grinding Stone, 2 Thick Leather", "pattern", 8030)
add("Bold Dirk", "Bold Dirk", 1252365, 270, 310, "30 Thorium Bar, 4 Essence of Air, 10 Azerothium Bar, 4 Rugged Leather", "pattern", 251468)
add("Ornate Thorium Handaxe", "Ornate Thorium Handaxe", 16969, 275, 300, "20 Thorium Bar, 2 Large Opal, 2 Dense Grinding Stone, 4 Rugged Leather", "pattern", 12819)

catalogue = {}
byProfession.Enchanting = catalogue
add("Runed Copper Rod", "Runed Copper Rod", 7421, 1, 10, "1 Copper Rod, 1 Mote of Magic", "starter")
add("disenchant greens", "Disenchant", 13262, 2, 20, "", "ability")
add("Lesser Magic Wand", "Lesser Magic Wand", 14293, 20, 115, "1 Simple Wood, 1 Lesser Magic Essence", "trainer")
add("Chest–Minor Absorption", "Enchant Chest - Minor Absorption", 7426, 79, 130, "1 Lesser Magic Essence", "trainer")
add("Bracer–Minor Stamina", "Enchant Bracer - Minor Stamina", 7457, 50, 140, "2 Strange Dust", "trainer")
add("Runed Silver Rod", "Runed Silver Rod", 7795, 100, 170, "1 Silver Rod, 3 Strange Dust, 4 Lesser Magic Essence, 1 Shadowgem", "trainer")
add("Greater Magic Wand", "Greater Magic Wand", 14807, 101, 150, "1 Simple Wood, 2 Lesser Magic Essence", "trainer")
add("Cloak–Minor Agility", "Enchant Cloak - Minor Agility", 13419, 110, 175, "1 Lesser Astral Essence", "pattern", 11039)
add("Bracer–Lesser Stamina", "Enchant Bracer - Lesser Stamina", 13501, 130, 195, "1 Soul Dust", "trainer")
add("Runed Golden Rod", "Runed Golden Rod", 13628, 155, 215, "1 Golden Rod, 1 Iridescent Pearl, 1 Greater Astral Essence, 1 Soul Dust", "trainer")
add("Bracer–Lesser Strength", "Enchant Bracer - Lesser Strength", 13536, 156, 205, "1 Soul Dust", "pattern", 11101)
add("Bracer–Strength", "Enchant Bracer - Strength", 13661, 180, 240, "1 Vision Dust", "trainer")
add("Runed Truesilver Rod", "Runed Truesilver Rod", 13702, 200, 260, "1 Truesilver Rod, 1 Black Pearl, 1 Greater Mystic Essence, 1 Vision Dust", "trainer")
add("Cloak–Greater Defense", "Enchant Cloak - Greater Defense", 13746, 205, 265, "1 Vision Dust", "trainer")
add("Gloves–Agility", "Enchant Gloves - Agility", 13815, 210, 270, "1 Vision Dust", "trainer")
add("Boots–Stamina", "Enchant Boots - Stamina", 13836, 230, 275, "2 Vision Dust", "trainer")
add("Chest–Superior Stamina", "Enchant Chest - Superior Stamina", 13858, 235, 280, "3 Vision Dust", "trainer")
add("Lesser Mana Oil", "Lesser Mana Oil", 25127, 250, 280, "1 Dream Dust, 1 Purple Lotus, 1 Crystal Vial", "pattern", 20754)
add("Shield–Greater Stamina", "Enchant Shield - Greater Stamina", 20017, 265, 325, "6 Dream Dust", "pattern", 16217)
add("Runed Arcanite Rod", "Runed Arcanite Rod", 20051, 294, 350, "1 Arcanite Rod, 1 Golden Pearl, 10 Illusion Dust, 4 Greater Eternal Essence, 4 Small Brilliant Shard, 2 Large Brilliant Shard", "pattern", 16243)
add("Cloak–Superior Defense", "Enchant Cloak - Superior Defense", 20015, 295, 345, "8 Illusion Dust", "pattern", 16224)

catalogue = {}
byProfession.Engineering = catalogue
add("Rough Blasting Powder", "Rough Blasting Powder", 3918, 1, 40, "1 Rough Stone", "starter")
add("Copper Bolts", "Handful of Copper Bolts", 3922, 30, 60, "1 Copper Bar", "trainer")
add("Arclight Spanner", "Arclight Spanner", 7430, 50, 90, "6 Copper Bar", "trainer")
add("Rough Copper Bomb", "Rough Copper Bomb", 3923, 51, 90, "1 Copper Bar, 1 Handful of Copper Bolts, 2 Rough Blasting Powder, 1 Linen Cloth", "trainer")
add("Coarse Blasting Powder", "Coarse Blasting Powder", 3929, 75, 95, "1 Coarse Stone", "trainer")
add("Coarse Dynamite", "Coarse Dynamite", 3931, 90, 105, "3 Coarse Blasting Powder, 1 Linen Cloth", "trainer")
add("Silver Contact", "Silver Contact", 3973, 90, 140, "1 Silver Bar", "trainer", nil, 5)
add("Bronze Tube", "Bronze Tube", 3938, 105, 155, "2 Bronze Bar, 1 Weak Flux", "trainer")
add("Standard Scope", "Standard Scope", 3978, 110, 160, "1 Bronze Tube, 1 Moss Agate", "trainer")
add("Whirring Bronze Gizmo", "Whirring Bronze Gizmo", 3942, 135, 175, "2 Bronze Bar, 1 Wool Cloth", "trainer")
add("Bronze Framework", "Bronze Framework", 3953, 150, 195, "2 Bronze Bar, 1 Medium Leather, 1 Wool Cloth", "trainer")
add("Heavy Blasting Powder", "Heavy Blasting Powder", 3945, 125, 145, "1 Heavy Stone", "trainer", nil, 2)
add("Explosive Sheep", "Explosive Sheep", 3955, 160, 200, "1 Bronze Framework, 1 Whirring Bronze Gizmo, 2 Heavy Blasting Powder, 2 Wool Cloth", "trainer")
add("Solid Blasting Powder", "Solid Blasting Powder", 12585, 175, 195, "2 Solid Stone", "trainer")
add("Gyromatic Micro-Adjustor", "Gyromatic Micro-Adjustor", 12590, 194, 215, "4 Steel Bar", "trainer")
add("Mithril Tube", "Mithril Tube", 12589, 195, 235, "3 Mithril Bar", "trainer")
add("Unstable Trigger", "Unstable Trigger", 12591, 200, 240, "1 Mithril Bar, 1 Mageweave Cloth, 1 Solid Blasting Powder", "trainer")
add("Mithril Casing", "Mithril Casing", 12599, 215, 255, "3 Mithril Bar", "trainer")
add("Hi-Explosive Bomb", "Hi-Explosive Bomb", 12619, 238, 275, "2 Mithril Casing, 1 Unstable Trigger, 2 Solid Blasting Powder", "trainer")
add("Dense Blasting Powder", "Dense Blasting Powder", 19788, 250, 260, "2 Dense Stone", "trainer")
add("Thorium Widget", "Thorium Widget", 19791, 260, 300, "3 Thorium Bar, 1 Runecloth", "pattern", 16042)
add("Thorium Tube", "Thorium Tube", 19795, 285, 315, "6 Thorium Bar", "pattern", 16047)

catalogue = {}
byProfession.Leatherworking = catalogue
add("Light Leather", "Light Leather", 2881, 1, 40, "3 Ruined Leather Scraps", "starter")
add("Cured Light Hide", "Cured Light Hide", 3816, 30, 70, "1 Light Hide, 1 Salt", "trainer")
add("Embossed Leather Gloves", "Embossed Leather Gloves", 3756, 40, 100, "3 Light Leather, 2 Coarse Thread", "trainer")
add("Medium Leather", "Medium Leather", 20648, 75, 85, "4 Light Leather", "trainer")
add("Cured Medium Hide", "Cured Medium Hide", 3817, 75, 105, "1 Medium Hide, 1 Salt", "trainer")
add("Fine Leather Belt", "Fine Leather Belt", 3763, 55, 115, "6 Light Leather, 2 Coarse Thread", "trainer")
add("Light Leather Pants", "Light Leather Pants", 9068, 70, 130, "10 Light Leather, 1 Cured Light Hide, 1 Fine Thread", "trainer")
add("Dark Leather Belt", "Dark Leather Belt", 3766, 100, 150, "1 Fine Leather Belt, 1 Cured Medium Hide, 2 Fine Thread, 1 Gray Dye", "trainer")
add("Heavy Leather", "Heavy Leather", 20649, 125, 135, "5 Medium Leather", "trainer")
add("Cured Heavy Hide", "Cured Heavy Hide", 3818, 125, 145, "1 Heavy Hide, 3 Salt", "trainer")
add("Hillman’s Leather Gloves", "Hillman's Leather Gloves", 3764, 143, 170, "14 Medium Leather, 4 Fine Thread", "trainer")
add("Barbaric Shoulders", "Barbaric Shoulders", 7151, 155, 190, "8 Heavy Leather, 1 Cured Heavy Hide, 2 Fine Thread", "trainer")
add("Guardian Gloves", "Guardian Gloves", 7156, 170, 205, "4 Heavy Leather, 1 Cured Heavy Hide, 1 Silken Thread", "trainer")
add("Barbaric Harness", "Barbaric Harness", 6661, 185, 205, "14 Heavy Leather, 2 Fine Thread, 1 Iron Buckle", "trainer")
add("Nightscape Headband", "Nightscape Headband", 10507, 180, 220, "5 Thick Leather, 2 Silken Thread", "trainer")
add("Nightscape Pants", "Nightscape Pants", 10548, 210, 245, "14 Thick Leather, 4 Silken Thread", "trainer")
add("Wicked Leather Gauntlets", "Wicked Leather Gauntlets", 19049, 235, 275, "8 Rugged Leather, 1 Black Dye, 1 Rune Thread", "pattern", 15725)
add("Runic Leather Headband", "Runic Leather Headband", 19082, 265, 305, "14 Rugged Leather, 10 Runecloth, 1 Rune Thread", "pattern", 15756)

catalogue = {}
byProfession.Tailoring = catalogue
add("Linen Bolts", "Bolt of Linen Cloth", 2963, 1, 50, "2 Linen Cloth", "starter")
add("Linen Belt", "Linen Belt", 8776, 10, 85, "1 Bolt of Linen Cloth, 1 Coarse Thread", "trainer")
add("Wool Bolts", "Bolt of Woolen Cloth", 2964, 55, 85, "3 Wool Cloth", "trainer")
add("Woolen Cape", "Woolen Cape", 2402, 55, 115, "1 Bolt of Woolen Cloth, 1 Fine Thread", "trainer")
add("Double-stitched Woolen Shoulders", "Double-stitched Woolen Shoulders", 3848, 85, 145, "3 Bolt of Woolen Cloth, 2 Fine Thread", "trainer")
add("Silk Bolts", "Bolt of Silk Cloth", 3839, 100, 120, "4 Silk Cloth", "trainer")
add("Gloves of Meditation", "Gloves of Meditation", 3852, 105, 155, "4 Bolt of Woolen Cloth, 3 Fine Thread, 1 Elixir of Wisdom", "trainer")
add("Mageweave Bolts", "Bolt of Mageweave", 3865, 140, 150, "5 Mageweave Cloth", "trainer")
add("Crimson Silk Vest", "Crimson Silk Vest", 8791, 150, 190, "4 Bolt of Silk Cloth, 2 Red Dye, 2 Fine Thread", "trainer")
add("Crimson Silk Pantaloons", "Crimson Silk Pantaloons", 8799, 160, 200, "4 Bolt of Silk Cloth, 2 Red Dye, 2 Silken Thread", "trainer")
add("Black Mageweave Leggings", "Black Mageweave Leggings", 12049, 170, 215, "2 Bolt of Mageweave, 3 Silken Thread", "trainer")
add("Black Mageweave Shoulders", "Black Mageweave Shoulders", 12074, 190, 235, "3 Bolt of Mageweave, 2 Heavy Silken Thread", "trainer")
add("Runecloth Bolts", "Bolt of Runecloth", 18401, 205, 215, "5 Runecloth", "trainer")
add("Runecloth Belt", "Runecloth Belt", 18402, 210, 255, "3 Bolt of Runecloth, 1 Rune Thread", "trainer")
add("Runecloth Gloves", "Runecloth Gloves", 18417, 240, 275, "4 Bolt of Runecloth, 4 Rugged Leather, 1 Rune Thread", "pattern", 14481)
add("Runecloth Cuffs", "Runecloth Cuffs", 1257487, 250, 295, "5 Bolt of Runecloth, 1 Ironweb Spider Silk, 1 Rune Thread", "pattern", 254124)
add("Runecloth Shoulders", "Runecloth Shoulders", 18449, 280, 305, "7 Bolt of Runecloth, 2 Ironweb Spider Silk, 4 Rugged Leather, 1 Rune Thread", "drop", 14504)

function ns.TrackCraftNextRecipes(track)
    for profession, recipes in pairs(byProfession) do
        for _, recipe in pairs(recipes) do track(profession, recipe.spell) end
    end
end
