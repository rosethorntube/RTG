local _, ns = ...

-- The fish lists contain recipe ingredients, not complete loot tables. Separate
-- rows distinguish schools, open water and named areas with different catches.
-- minimum and noEscape are effective Fishing including gear and lures.
-- level is a suggested floor for travelling there, not an entry requirement.
-- Skill bands: https://www.wowhead.com/forever/guide/professions/fishing/overview-leveling
-- Named waters and thresholds: https://foreverfishing.co/fishing/
-- Horde route and reported catches: https://www.wow-professions.com/forever/fishing-and-cooking-leveling-guide
ns.FishingWaters = {
    -- https://foreverfishing.co/fishing/elwynn-forest/
    -- https://foreverfishing.co/fishing/dun-morogh/
    -- https://foreverfishing.co/fishing/teldrassil/
    -- https://foreverfishing.co/fishing/westfall/
    {
        faction = "Alliance", mapID = 1429, water = "Crystal Lake by Goldshire, Elwynn Forest",
        continent = "EK", level = 5, minimum = 1, noEscape = 25, fish = {6291,6289},
    },
    {
        faction = "Alliance", mapID = 1426, water = "Iceflow Lake, Dun Morogh",
        continent = "EK", level = 5, minimum = 1, noEscape = 25, fish = {6291,6289},
    },
    {
        faction = "Alliance", mapID = 1438, water = "Lake Al'Ameth, Teldrassil",
        continent = "Kalimdor", level = 5, minimum = 1, noEscape = 25, fish = {6291,6289},
    },
    {
        faction = "Alliance", mapID = 1436, water = "Stendel's Pond, Westfall",
        continent = "EK", level = 12, minimum = 1, noEscape = 75, fish = {6291,6289,6308},
    },
    {
        faction = "Alliance", mapID = 1436, water = "Longshore on the Westfall coast",
        continent = "EK", level = 12, minimum = 1, noEscape = 75, fish = {6303,6361},
    },


    -- Starter waters and capital cities have different skill targets.
    -- https://foreverfishing.co/fishing/mulgore/
    -- https://foreverfishing.co/fishing/durotar/
    -- https://foreverfishing.co/fishing/tirisfal-glades/
    {
        faction = "Horde", mapID = 1412, water = "Stonebull Lake at Bloodhoof Village, Mulgore",
        continent = "Kalimdor", level = 5, minimum = 1, noEscape = 25,
        fish = {6291, 6289},
    },
    {
        faction = "Horde", mapID = 1411, water = "the coast south of Sen'jin Village, Durotar",
        continent = "Kalimdor", level = 5, minimum = 1, noEscape = 25,
        fish = {6303},
    },
    {
        faction = "Horde", mapID = 1411, water = "the Durotar bank of the Southfury River",
        continent = "Kalimdor", level = 10, minimum = 1, noEscape = 25,
        fish = {6291, 6289},
    },
    {
        faction = "Horde", mapID = 1420, water = "Brightwater Lake east of Brill, Tirisfal Glades",
        continent = "EK", level = 5, minimum = 1, noEscape = 25,
        fish = {6291, 6289},
    },
    -- https://foreverfishing.co/fishing/thunder-bluff/
    -- https://foreverfishing.co/fishing/orgrimmar/
    -- https://foreverfishing.co/fishing/undercity/
    {
        faction = "Horde", mapID = 1456, water = "the pond by the auction house in Thunder Bluff",
        continent = "Kalimdor", level = 5, minimum = 1, noEscape = 75,
        fish = {6291, 6289, 6308},
    },
    {
        faction = "Horde", mapID = 1454, water = "the Valley of Honor pond in Orgrimmar",
        continent = "Kalimdor", level = 5, minimum = 1, noEscape = 75,
        fish = {6291, 6289, 6308},
    },
    {
        faction = "Horde", mapID = 1458, water = "the canals in Undercity",
        continent = "EK", level = 5, minimum = 1, noEscape = 75,
        fish = {6291, 6289, 6308},
    },
    -- https://foreverfishing.co/fishing/the-barrens/
    -- https://foreverfishing.co/fishing/silverpine-forest/
    {
        port = "Ratchet", mapID = 1413, water = "the boat dock in Ratchet, the Barrens",
        continent = "Kalimdor", level = 12, minimum = 1, noEscape = 75,
        fish = {6303, 6361},
    },
    {
        faction = "Horde", mapID = 1413, water = "the Forgotten Pools west of the Crossroads, the Barrens",
        continent = "Kalimdor", level = 14, minimum = 1, noEscape = 75,
        fish = {6291, 6289, 6308},
    },
    {
        faction = "Horde", mapID = 1421, water = "the coast at North Tide's Run, Silverpine Forest",
        continent = "EK", level = 14, minimum = 1, noEscape = 75,
        fish = {6303, 6361},
    },
    -- https://foreverfishing.co/fishing/stonetalon-mountains/
    -- https://forevergoldcraft.com/guides/fishing/pools
    -- https://foreverfishing.co/fishing/ashenvale/
    -- https://foreverfishing.co/fishing/hillsbrad-foothills/
    {
        mapID = 1442, water = "Mirkfallon Lake in the Stonetalon Mountains",
        continent = "Kalimdor", level = 24, minimum = 55, noEscape = 150,
        fish = {6308, 6289},
    },
    {
        mapID = 1442, water = "Sagefish Schools at Mirkfallon Lake, Stonetalon Mountains",
        continent = "Kalimdor", level = 24, minimum = 55, noEscape = 150,
        pool = true, fish = {21071},
    },
    {
        mapID = 1440, water = "the Southfury River in eastern Ashenvale",
        continent = "Kalimdor", level = 24, minimum = 55, noEscape = 150,
        fish = {6308, 6289},
    },
    {
        faction = "Horde", mapID = 1424, water = "the river near Tarren Mill, Hillsbrad Foothills",
        continent = "EK", level = 22, minimum = 55, noEscape = 150,
        fish = {6308, 6289},
    },
    {
        faction = "Horde", mapID = 1424, water = "Sagefish Schools in the Hillsbrad river near Tarren Mill",
        continent = "EK", level = 22, minimum = 55, noEscape = 150,
        pool = true, fish = {21071},
    },
    {
        mapID = 1424, water = "the Eastern Strand coast, Hillsbrad Foothills",
        continent = "EK", level = 30, minimum = 55, noEscape = 150,
        fish = {6361},
    },
    -- https://foreverfishing.co/fishing/alterac-mountains/
    -- https://foreverfishing.co/fishing/arathi-highlands/
    {
        mapID = 1416, water = "the Alterac Mountains shore of Lordamere Lake",
        continent = "EK", level = 32, minimum = 130, noEscape = 225,
        fish = {8365, 6308},
    },
    {
        mapID = 1416, water = "Greater Sagefish Schools on the Alterac shore of Lordamere Lake",
        continent = "EK", level = 32, minimum = 130, noEscape = 225,
        pool = true, fish = {21153},
    },
    {
        mapID = 1417, water = "the water beneath Thandol Span, Arathi Highlands",
        continent = "EK", level = 32, minimum = 130, noEscape = 225,
        fish = {8365, 6308},
    },
    -- https://foreverfishing.co/fishing/stranglethorn-vale/
    -- https://foreverdroprate.com/fishing/234 (reported Booty Bay catches)
    -- https://foreverdroprate.com/fishing/215 (reported Lake Nazferiti catches)
    {
        port = "Booty Bay", mapID = 1434, water = "the boat pier in Booty Bay, Stranglethorn Vale",
        continent = "EK", level = 30, minimum = 130, noEscape = 225,
        fish = {6362, 4603},
    },
    {
        mapID = 1434, water = "Lake Nazferiti inland from Grom'gol, Stranglethorn Vale",
        continent = "EK", level = 33, minimum = 130, noEscape = 225,
        fish = {8365, 6308},
    },
    {
        mapID = 1434, water = "Greater Sagefish Schools at Lake Nazferiti, Stranglethorn Vale",
        continent = "EK", level = 33, minimum = 130, noEscape = 225,
        pool = true, fish = {21153},
    },
    -- https://foreverfishing.co/fishing/dustwallow-marsh/
    {
        faction = "Horde", mapID = 1445, water = "the inland swamp near Brackenwall Village, Dustwallow Marsh",
        continent = "Kalimdor", level = 36, minimum = 130, noEscape = 225,
        fish = {8365, 6308},
    },
    -- https://foreverfishing.co/fishing/feralas/
    -- https://www.mmojugg.com/news/wow-forever-nightfin-sunscale-fishing.html
    -- https://foreverfishing.co/fishing/the-hinterlands/
    -- https://foreverfishing.co/fishing/tanaris/
    {
        faction = "Horde", mapID = 1444, water = "Wildwind Lake just south of Camp Mojache, Feralas",
        routeKey = "camp-fishing",
        continent = "Kalimdor", level = 42, minimum = 205, noEscape = 300,
        fish = {8365, 13758, 13759, 13760},
    },
    {
        mapID = 1425, water = "Valorwind Lake in the Hinterlands",
        continent = "EK", level = 46, minimum = 205, noEscape = 300,
        fish = {8365, 13758, 13759, 13760},
    },
    {
        mapID = 1446, water = "Wavestrider Beach south of Steamwheedle Port, Tanaris",
        continent = "Kalimdor", level = 43, minimum = 205, noEscape = 300,
        fish = {6362, 4603, 13754},
    },
    -- https://halsudsworth.com/zones/azshara/
    -- https://wow-forever.gg/db/items/13893-large-raw-mightfish/
    -- https://foreverfishing.co/fishing/eastern-plaguelands/
    -- https://foreverfishing.co/fishing/winterspring/
    {
        mapID = 1447, water = "the offshore Bay of Storms, Azshara",
        continent = "Kalimdor", level = 55, minimum = 330, noEscape = 425,
        fish = {13893, 4603},
    },
    {
        mapID = 1423, water = "the Eastern Plaguelands bank of the Thondroril River",
        continent = "EK", level = 55, minimum = 330, noEscape = 425,
        fish = {13889, 13759, 13760, 13758},
    },
    {
        mapID = 1452, water = "Frostfire Hot Springs in Winterspring",
        continent = "Kalimdor", level = 56, minimum = 330, noEscape = 425,
        fish = {13889, 13759, 13760, 13758},
    },
}
