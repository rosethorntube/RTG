local _, ns = ...

local function freshPrice(id)
    if not ns.MarketQuote then return end
    local price, age, source = ns.MarketQuote(id)
    if price and price > 0 and age and age >= 0 and age <= 7 and (source == "native" or source == "manual") then
        return price
    end
end

local function costs(recipe)
    local sum=0
    for id, n in pairs(recipe.ingredients or {}) do
        local market=freshPrice(id)
        local vendor=ns.CookingVendorUnitCost and ns.CookingVendorUnitCost(id)
        local best=market and vendor and math.min(market,vendor) or market or vendor
        if not best then return end
        sum=sum+n*best
    end
    return sum
end

local function knownRecipe(state, spell)
    if state.missing and state.missing[spell] then return false end
    if state.known and state.known[spell] then return true end
    if IsSpellKnown then
        local ok, result=pcall(IsSpellKnown,spell)
        return ok and result==true
    end
    return false
end

local function hasOven(recipe)
    if recipe.station~="Iron Oven" then return true end
    local api=C_TradeSkillUI and C_TradeSkillUI.GetRecipeRequirements
    if not api then return false end
    local ok, rows=pcall(api,recipe.spell)
    if not ok or type(rows)~="table" then return false end
    local focus=(Enum and Enum.RecipeRequirementType and Enum.RecipeRequirementType.SpellFocus) or 0
    local found=false
    for _, row in ipairs(rows) do
        if row.type==focus then
            if row.met~=true then return false end
            found=true
        end
    end
    return found
end
ns.CookingStationReady = hasOven

local function measuredWaters(state)
    local rows = {}
    local faction = ns.AdvisorFaction and ns.AdvisorFaction(state) or state.faction
    for _, water in ipairs(ns.FishingWaters or {}) do
        local localMap = state.mapID == water.mapID
        local accessible = (not water.faction or water.faction == faction)
            and (localMap or (state.level and state.level >= water.level))
        local sample = accessible and ns.FishingWaterSample and ns.FishingWaterSample(state, water)
        if sample and sample.comparable then
            local row = {water=water.water, seconds=sample.seconds, quantity=sample.quantity,
                items={}, comparable=sample.goldComparable, perHour=sample.netCopperPerHour}
            for _, item in pairs(sample.variants) do
                row.items[#row.items+1] = {id=item.id, quantity=item.count, copper=item.recurringCopper}
            end
            rows[#rows+1] = row
        end
    end
    return rows
end

local function better(left,right)
    if not right then return true end
    for _, field in ipairs({"orangePerHour","yellowPerHour","greenPerHour","validSeconds"}) do
        if left[field]~=right[field] then return left[field]>right[field] end
    end
    return left.water<right.water
end

local function copper(amount)
    local n=math.floor(amount+0.5)
    return ("%dg %02ds %02dc"):format(math.floor(n/10000), math.floor(n/100)%100, n%100)
end

-- Start with the proceeds of selling everything. Retaining one recipe's worth
-- spends its foregone net sale proceeds plus its seasoning and supplies a craft.
-- Under a fixed cash budget, ascending cost maximises affordable orange crafts.
local function retainOrSell(d, salePerHour, cheapest)
    if d.unpricedOrange or not cheapest then return end
    local available=salePerHour
    local kept, opportunity, seasoning=0,0,0
    d.keptNames,d.soldNames={},{}
    table.sort(d.orangeFish,function(a,b)
        if a.retainCost~=b.retainCost then return a.retainCost<b.retainCost end
        return a.name<b.name
    end)
    for _,fish in ipairs(d.orangeFish) do
        local count=0
        if fish.retainCost<=cheapest.unitCost then
            count=math.min(fish.rate,available/fish.retainCost)
        end
        if count>0.000001 then
            kept=kept+count
            opportunity=opportunity+count*fish.saleCost
            seasoning=seasoning+count*fish.extra
            available=math.max(0,available-count*fish.retainCost)
            d.keptNames[#d.keptNames+1]=fish.name
        end
        if count<fish.rate-0.000001 then d.soldNames[#d.soldNames+1]=fish.name end
    end
    d.keptPerHour=kept
    d.netSalePerHour=math.max(0,salePerHour-opportunity)
    d.seasoningPerHour=seasoning
    d.extraPurchasesPerHour=available/cheapest.unitCost
    d.fundedPerHour=kept+d.extraPurchasesPerHour
end


-- The table reports crafts from observed fish, never an assumed yellow/green
-- success probability. A food-output proc does not give extra crafting attempts.
function ns.GetCookingSpotPlan(state, spots)
    local plan={recommendation="insufficient", maxOrange=0}
    local cooking=state.skills and state.skills.Cooking
    if not cooking then plan.reason="untrained"; return plan end
    if cooking.rank>=cooking.cap then plan.reason="capped"; return plan end
    local fishing=state.skills.Fishing
    if not fishing then plan.reason="fishing"; return plan end
    local rank=cooking.rank
    local valid, cheapest={},nil
    local function consider(id,r,isFish)
        if rank<r.skill or ns.RecipeOutlevelled(cooking,r) then return end
        if not knownRecipe(state,r.spell) then
            if not plan.learnable or r.recipe<plan.learnable then plan.learnable=r.recipe end
            return
        end
        if not hasOven(r) then plan.ovenRecipe=plan.ovenRecipe or r.recipe; return end
        local colour=rank<r.yellow and "orange" or rank<r.green and "yellow" or "green"
        local main=r.fishPerCraft or r.mainPerCraft or 1
        local extra=costs(r)
        if isFish then valid[id]={r=r,colour=colour,main=main,extra=extra} end
        if colour~="orange" or not extra then return end
        local raw=freshPrice(id)
        if not raw then return end
        local price=main*raw+extra
        if not cheapest or price<cheapest.unitCost or (price==cheapest.unitCost and r.recipe<cheapest.recipe) then
            cheapest={ingredient=r.name,recipe=r.recipe,unitCost=price,rawPerCraft=main,id=id,
                maxOrange=math.min(r.yellow,cooking.cap)-rank}
        end
    end
    for id,r in pairs(ns.fish) do consider(id,r,true) end
    for id,r in pairs(ns.otherCooking or {}) do consider(id,r,false) end
    plan.cheapest=cheapest
    local cash, bestMixed
    for _,spot in ipairs(spots or measuredWaters(state)) do
        if spot.seconds>=900 and spot.quantity>=10 then
            local d={water=spot.water,validSeconds=spot.seconds,orangePerHour=0,yellowPerHour=0,
                greenPerHour=0,extraPerHour=0,names={},orangeFish={},maxOrange=cooking.cap-rank}
            for _,item in ipairs(spot.items or {}) do
                local f=valid[item.id]
                if f then
                    local rate=(item.quantity/f.main)*3600/spot.seconds
                    local band=f.colour.."PerHour"
                    d[band]=d[band]+rate
                    d.names[#d.names+1]=f.r.name
                    if f.colour=="orange" then
                        d.maxOrange=math.min(d.maxOrange,f.r.yellow-rank)
                        if d.extraPerHour and f.extra then d.extraPerHour=d.extraPerHour+rate*f.extra
                        else d.extraPerHour=nil end
                        -- Fishing estimates already select the vendor payout or after-cut AH proceeds.
                        -- Buying the same ingredient uses its separate, gross purchase price above.
                        if item.copper and item.copper>0 and item.quantity>0 and f.extra then
                            local saleCost=f.main*item.copper/item.quantity
                            d.orangeFish[#d.orangeFish+1]={name=f.r.name,rate=rate,
                                saleCost=saleCost,extra=f.extra,retainCost=saleCost+f.extra}
                        else d.unpricedOrange=true end
                    end
                end
            end
            table.sort(d.names)
            if #d.names>0 and better(d,plan.direct) then plan.direct=d end
            local net=spot.perHour or (spot.copper and spot.copper*3600/spot.seconds)
            if spot.comparable and net and net>0 then
                if not cash or net>cash.copperPerHour or (net==cash.copperPerHour and spot.water<cash.water) then
                    cash={water=spot.water,validSeconds=spot.seconds,copperPerHour=net}
                end
                if d.unpricedOrange then plan.incomplete=true end
                retainOrSell(d,net,cheapest)
                if d.keptPerHour and d.keptPerHour>0 and
                    (not bestMixed or d.fundedPerHour>bestMixed.fundedPerHour or
                    (d.fundedPerHour==bestMixed.fundedPerHour and d.keptPerHour>bestMixed.keptPerHour)) then
                    bestMixed=d
                end
            else
                plan.incomplete=true
            end
        end
    end
    if cash and cheapest then
        for k,v in pairs(cheapest) do cash[k]=v end
        cash.buyablePerHour=cash.copperPerHour/cash.unitCost
        cash.cashOnlyPerHour=cash.buyablePerHour
        plan.purchase=cash
        plan.maxOrange=cheapest.maxOrange
    end
    plan.highestDirect=plan.direct
    if bestMixed and not plan.incomplete then plan.direct=bestMixed end
    local direct=plan.direct
    if direct and direct.orangePerHour>0 then
        plan.maxOrange=plan.maxOrange>0 and math.min(plan.maxOrange,direct.maxOrange) or direct.maxOrange
        if plan.purchase and not plan.incomplete then
            local beatsSale=bestMixed and bestMixed.fundedPerHour+0.000001>=cash.buyablePerHour
            plan.recommendation=beatsSale and "direct" or "buy"
        end
    end
    return plan
end

function ns.AddCookingSpotAdvice(state,add,spots)
    local p=ns.GetCookingSpotPlan(state,spots)
    if not p.direct and not p.purchase then return end
    local lines={}
    if p.direct then
        local d=p.direct
        if p.highestDirect and p.highestDirect.water~=d.water then
            lines[#lines+1]=("For orange fish alone: %s, %.1f crafts/hour."):format(p.highestDirect.water,p.highestDirect.orangePerHour)
        end
        local rates={}
        for _, colour in ipairs({"orange","yellow","green"}) do
            local rate=d[colour.."PerHour"]
            if rate>0 then rates[#rates+1]=("%.1f %s"):format(rate,colour) end
        end
        lines[#lines+1]=("%s (%d min), %s crafts/hour from %s."):format(
            d.water,math.floor(d.validSeconds/60),table.concat(rates,", "),table.concat(d.names,", "))
        if not p.incomplete and d.keptPerHour and d.keptPerHour>0 then
            lines[#lines+1]=("Keep %s for %.1f orange crafts/hour. Selling the rest and paying for seasoning could fund %.1f more."):format(
                table.concat(d.keptNames,", "),d.keptPerHour,d.extraPurchasesPerHour)
            if #d.soldNames>0 then lines[#lines+1]="Sell the surplus "..table.concat(d.soldNames,", ").."." end
        elseif not p.incomplete and d.keptPerHour==0 and d.soldNames and #d.soldNames>0 then
            lines[#lines+1]="Selling "..table.concat(d.soldNames,", ").." and saving the seasonings funds more orange crafts with cheaper ingredients."
        elseif d.extraPerHour and d.extraPerHour>0 then lines[#lines+1]="Cooking all your orange catches needs "..copper(d.extraPerHour).." in seasonings per fishing hour." end
    end
    if p.purchase then
        local b=p.purchase
        lines[#lines+1]=("%s (%d min), estimated %s/hour from recurring catches. At %s per %s craft, that funds %.1f orange crafts/hour."):format(b.water,math.floor(b.validSeconds/60),copper(b.copperPerHour),copper(b.unitCost),b.recipe,b.buyablePerHour)
        if p.direct and p.direct.orangePerHour==0 then lines[#lines+1]="Direct catches supplied yellow or green crafts in these samples." end
    elseif not p.cheapest then
        lines[#lines+1]="Check current prices for ingredients in a known orange recipe to compare buying."
    end
    if p.maxOrange>0 then lines[#lines+1]=("Recheck after %d Cooking skill-ups or when your recipe changes colour."):format(p.maxOrange) end
    if p.incomplete then lines[#lines+1]="A gold comparison needs repeat visits, recurring catches and fresh local sale prices." end
    if not p.direct then
        lines[#lines+1]="For a Cooking comparison, label your water and record 15 minutes, 20 casts and 10 items, including fish for a known skill-up recipe."
    end
    if p.ovenRecipe then lines[#lines+1]=p.ovenRecipe.." is an additional option when the client confirms an Iron Oven nearby." end
    if not p.direct and p.learnable then lines[#lines+1]="Open Cooking to confirm learned recipes; "..p.learnable.." is eligible by rank." end
    if p.purchase then lines[#lines+1]="Estimates assume available stock and buyers. Allow for travel, lures and lost deposits." end
    local title=p.recommendation=="direct" and "Cooking: keep useful fish and sell the rest" or
        p.recommendation=="buy" and "More orange crafts: fish for gold and buy ingredients" or "Cooking from your recorded catches"
    add(title,table.concat(lines,"\n"),40,"cook-spots")
end
