local _, ns = ...

local zoneNames, legacyHistory, historyRequested = {}, nil, false
local observedTurnIns = {}
local function mapInfo(id)
    if id and C_Map and C_Map.GetMapInfo then return C_Map.GetMapInfo(id) end
end

local function nameMatches(a, b)
    return a and b and a ~= "" and a == b
end

local districts = {
    [1458] = {"Trade Quarter", "The Trade Quarter", "War Quarter", "The War Quarter", "Royal Quarter",
        "The Royal Quarter", "Magic Quarter", "The Magic Quarter", "Rogues' Quarter", "The Rogues' Quarter",
        "The Apothecarium"},
    [1454] = {"Valley of Wisdom", "Valley of Spirits", "Valley of Honor", "Valley of Strength",
        "The Drag", "Cleft of Shadow"},
    [1456] = {"Elder Rise", "Spirit Rise", "Hunter Rise"},
    [1453] = {"Dwarven District", "The Dwarven District", "Mage Quarter", "The Mage Quarter", "Cathedral Square", "Old Town", "The Park", "Valley of Heroes", "Trade District", "The Trade District"},
    [1455] = {"The Forlorn Cavern", "The Great Forge", "The Military Ward", "The Mystic Ward", "Tinker Town", "Hall of Explorers"},
    [1457] = {"Craftsmen's Terrace", "The Temple Gardens", "Warrior's Terrace", "Tradesmen's Terrace"},
}
local districtMaps = {}
for id, names in pairs(districts) do
    for _, name in ipairs(names) do districtMaps[name] = id end
end

local function zoneByName(name, data)
    if not name or name == "" then return end
    if zoneNames[name] and data[zoneNames[name]] then return zoneNames[name] end
    for id, english in pairs(ns.DungeonPickupZoneNames or {}) do
        if data[id] and english == name then zoneNames[name] = id; return id end
    end
    local match
    for id in pairs(data) do
        local info = mapInfo(id)
        if info and nameMatches(info.name, name) then
            if match then return end
            match = id
        end
    end
    if match then zoneNames[name] = match end
    return match
end

-- A zone alert applies to every district. Prefer a real map or floor ancestor,
-- and only fall back to matching the game's localised zone name.
function ns.OutdoorZoneForData(s, data)
    local map = s.mapID
    local seen = {}
    while map and map ~= 0 and not seen[map] do
        if data[map] then return map end
        seen[map] = true
        local info = mapInfo(map)
        map = info and info.parentMapID
    end
    local texts = {s.zone or "", GetZoneText and GetZoneText() or "",
        GetMinimapZoneText and GetMinimapZoneText() or "", s.subzone or ""}
    for _, name in ipairs(texts) do
        local match = zoneByName(name, data)
        if match then return match end
    end
    -- Some clients briefly expose only a district name. Require agreement
    -- between every nonempty location string before treating it as a city.
    local city
    local info = mapInfo(s.mapID)
    if info and info.name then texts[#texts + 1] = info.name end
    for _, name in ipairs(texts) do
        if name ~= "" then
            local id = districtMaps[name]
            if not id or (city and city ~= id) then return end
            city = id
        end
    end
    if city and data[city] then return city end
end

-- Instance IDs are language-independent and differ from world map IDs.
-- Sources: QuestieDB support/Forever/Zones/instanceIdToAreaId.lua and
-- ForeverPlusPlus docs/forever-api.md (in-game Group Finder map IDs).
local instanceNames = {
    [33]="Shadowfang Keep", [36]="The Deadmines", [43]="Wailing Caverns", [47]="Razorfen Kraul",
    [48]="Blackfathom Deeps", [70]="Uldaman", [90]="Gnomeregan", [109]="The Temple of Atal'Hakkar",
    [129]="Razorfen Downs", [189]="Scarlet Monastery", [209]="Zul'Farrak", [229]="Blackrock Spire",
    [230]="Blackrock Depths", [289]="Scholomance", [329]="Stratholme", [349]="Maraudon",
    [389]="Ragefire Chasm", [429]="Dire Maul", [2959]="City of Dalaran", [2998]="Excavation Site: Wetlands",
    [2999]="Ruins of Lordaeron", [3065]="The Hall of Thanes", [2994]="Alcaz Prison",
    [2974]="Blackmaw Hold",
}
local function currentRows(s)
    local name, kind, instanceID
    if GetInstanceInfo then
        local actual, typeName, _, _, _, _, _, id = GetInstanceInfo()
        name, kind, instanceID = actual, typeName, id
    end
    local inside = (IsInInstance and IsInInstance()) or (kind and kind ~= "none")
    if inside then
        local instances = ns.DungeonInstancePickupData or {}
        local canonical = instanceNames[instanceID]
        if canonical and instances[canonical] then return canonical, instances[canonical] end
        local map = s.mapID
        local seen = {}
        while map and map ~= 0 and not seen[map] do
            if instances[map] then return map, instances[map] end
            seen[map] = true
            local info = mapInfo(map)
            map = info and info.parentMapID
        end
        if instances[name] then return name, instances[name] end
        return
    end
    local map = ns.OutdoorZoneForData(s, ns.DungeonPickupData)
    if map then return map, ns.DungeonPickupData[map] end
end

local function activeQuest(id)
    local log = C_QuestLog
    if log and log.IsOnQuest then
        local on = log.IsOnQuest(id)
        if on ~= nil then return on == true or on == 1 end
    end
    local getIndex = (log and log.GetLogIndexForQuestID) or GetQuestLogIndexByID
    if getIndex then return (getIndex(id) or 0) > 0 end
    if GetNumQuestLogEntries and GetQuestLogTitle then
        local count = GetNumQuestLogEntries()
        if type(count) ~= "number" then return end
        for row = 1, count do
            local _, _, _, _, _, _, _, questID = GetQuestLogTitle(row)
            if questID == id then return true end
        end
        return false
    end
end

-- Some Classic clients return quest history in response to an asynchronous
-- query. Until it is received, an empty cache cannot establish eligibility.
function ns.DungeonQuestHistory(event, questID)
    if event == "QUEST_TURNED_IN" and type(questID) == "number" then observedTurnIns[questID] = true end
    if (C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted) or IsQuestFlaggedCompleted then return end
    if C_QuestLog and C_QuestLog.GetAllCompletedQuestIDs then
        local ids = C_QuestLog.GetAllCompletedQuestIDs()
        if ids then
            legacyHistory = {}
            for _, id in ipairs(ids) do legacyHistory[id] = true end
        end
        return
    end
    if not GetQuestsCompleted then return end
    if QueryQuestsCompleted and event ~= "QUEST_QUERY_COMPLETE" then
        if event == "QUEST_TURNED_IN" or not historyRequested then
            historyRequested = true
            QueryQuestsCompleted()
        end
        return
    end
    local completed = {}
    legacyHistory = GetQuestsCompleted(completed) or completed
end

local function completedQuest(id)
    if observedTurnIns[id] then return true end
    local test = (C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted) or IsQuestFlaggedCompleted
    if test then
        local result = test(id)
        if result ~= nil then return result == true or result == 1 end
    elseif legacyHistory then
        return legacyHistory[id] == true or legacyHistory[id] == 1
    end
end

local function matches(value, choices)
    if type(choices) ~= "table" then return choices == value end
    for _, choice in ipairs(choices) do if value == choice then return true end end
    return false
end

local function meetsGate(ids, predicate, any)
    if type(ids) ~= "table" then return predicate(ids) end
    for _, id in ipairs(ids) do
        if predicate(id) == any then return any end
    end
    return not any
end

local function done(id) return completedQuest(id) == true end
local function onQuest(id) return activeQuest(id) == true end
local function offQuest(id) return activeQuest(id) == false end
local function activeOrDone(id) return onQuest(id) or done(id) end
local function availableAlternative(id) return completedQuest(id) == false and activeQuest(id) == false end

local function standingFor(id)
    if C_Reputation and C_Reputation.GetFactionDataByID then
        local info = C_Reputation.GetFactionDataByID(id)
        if info and info.reaction then return info.reaction end
    end
    if GetFactionInfoByID then return select(3, GetFactionInfoByID(id)) end
end

local function carries(s, id)
    local n = s.bags and s.bags[id]
    local getCount = (C_Item and C_Item.GetItemCount) or GetItemCount
    if n == nil and not s.bagsScanned and getCount then n = getCount(id, false) end
    return (n or 0) > 0
end

function ns.DungeonFactionAllows(q, faction)
    if faction ~= "Alliance" and faction ~= "Horde" then return false end
    return q.faction == "Both" or (q.faction or "Horde") == faction
end

local function eligible(s, q, race, raceID, offered)
    if not ns.DungeonFactionAllows(q, ns.AdvisorFaction and ns.AdvisorFaction(s) or s.faction) then return false end
    if q.offerOnly and not offered then return false end
    if q.itemID and (not offered or q.itemStart) and not carries(s, q.itemID) then return false end
    if completedQuest(q.id) ~= false or activeQuest(q.id) ~= false then return false end
    if offered and not q.itemStart then return true end
    if not q.min or s.level < q.min then return false end
    if q.after and not meetsGate(q.after, done, false) then return false end
    if q.anyAfter and not meetsGate(q.anyAfter, done, true) then return false end
    if q.active and not meetsGate(q.active, onQuest, false) then return false end
    if q.activeOrDone and not meetsGate(q.activeOrDone, activeOrDone, false) then return false end
    if q.disabledWhileActive and not meetsGate(q.disabledWhileActive, offQuest, false) then return false end
    if q.excludes and not meetsGate(q.excludes, availableAlternative, false) then return false end
    if q.class and not matches(s.class, q.class) then return false end
    if q.race and not matches(race, q.race) then return false end
    if q.raceID and not matches(raceID, q.raceID) then return false end
    if q.excludeRace and (not race or matches(race, q.excludeRace)) then return false end
    if q.ghost and (not UnitIsGhost or not UnitIsGhost("player")) then return false end
    if q.rep and (standingFor(q.rep.id) or 0) < q.rep.standing then return false end
    if q.skill then
        local skill = s.skills and s.skills[q.skill.name]
        if not skill or skill.rank < q.skill.rank then return false end
    end
    return true
end

local function liveOffers()
    local offered = {}
    if GossipFrame and GossipFrame.IsShown and not GossipFrame:IsShown() then return offered end
    if UnitGUID and not UnitGUID("npc") then return offered end
    if C_GossipInfo and C_GossipInfo.GetAvailableQuests then
        local ok, quests = pcall(C_GossipInfo.GetAvailableQuests)
        if ok and quests then
            for _, info in ipairs(quests) do
                if info.questID then offered[info.questID] = info end
            end
        end
    end
    return offered
end

-- C_PlayerInfo.GetContentDifficultyQuestForPlayer returns RelativeContentDifficulty
-- for a loaded quest. A query for uncached data must not hide a real pickup.
local difficultyKeys = {[0]="trivial", "standard", "difficult", "verydifficult", "impossible"}
local function questDifficulty(s, q, offer)
    if offer and offer.isTrivial == true then return "trivial" end
    local native = C_PlayerInfo and C_PlayerInfo.GetContentDifficultyQuestForPlayer
    if native and HaveQuestData and HaveQuestData(q.id) then
        local difficulty = difficultyKeys[native(q.id)]
        if difficulty and not (difficulty == "trivial" and offer and offer.isTrivial == false) then
            return difficulty
        end
    end
    -- Use the quest level, distinct from the minimum required to accept it.
    if not q.level or q.level <= 0 or s.level <= 0 then return end
    local gap = s.level - q.level
    if gap <= -5 then return "impossible" end
    if gap <= -3 then return "verydifficult" end
    if gap <= 2 then return "difficult" end
    if offer and offer.isTrivial == false then return "standard" end
    -- Forever's API reports the FIRST grey difference. The legacy API
    -- reports the LAST green one. The boundary is deliberately different.
    local threshold = UnitQuestTrivialLevelRange and UnitQuestTrivialLevelRange("player")
    if type(threshold) == "number" and threshold > 0 then
        return gap >= threshold and "trivial" or "standard"
    end
    local green = GetQuestGreenRange and GetQuestGreenRange()
    if type(green) ~= "number" or green < 0 then
        -- Classic fixed-level quest bands (CMaNGOS Tools/Formulas.h, GetQuestGreenRange).
        green = s.level < 40 and (4 + math.floor(s.level / 10)) or math.min(12, math.floor(s.level / 5))
    end
    return gap > green and "trivial" or "standard"
end

local function levelText(level, difficulty)
    local label = "Quest level " .. level .. "."
    local palette = QuestDifficultyColors or QuestDifficultyColor
    local colour = type(palette) == "table" and palette[difficulty]
    if not colour and GetQuestDifficultyColor then colour = GetQuestDifficultyColor(level) end
    if type(colour) == "table" and colour.r and colour.g and colour.b then
        return ("|cff%02x%02x%02x%s|r"):format(math.floor(colour.r * 255 + .5),
            math.floor(colour.g * 255 + .5), math.floor(colour.b * 255 + .5), label)
    end
    return label
end

-- The manual zone review uses the same character, history and difficulty
-- checks as the live pickup alerts. An unavailable quest history is distinct
-- from an empty one on clients that answer the query asynchronously.
function ns.DungeonReviewContext(s)
    if not historyRequested and not legacyHistory and not (C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted)
        and not IsQuestFlaggedCompleted then ns.DungeonQuestHistory() end
    local race, raceID = s.race, s.raceID
    if UnitRace then
        local _, token, id = UnitRace("player")
        race, raceID = race or token, raceID or id
    end
    local offers = liveOffers()
    local function fits(q)
        return ns.DungeonFactionAllows(q, ns.AdvisorFaction and ns.AdvisorFaction(s) or s.faction)
            and (not q.class or matches(s.class, q.class))
            and (not q.race or matches(race, q.race))
            and (not q.raceID or matches(raceID, q.raceID))
            and (not q.excludeRace or (race and not matches(race, q.excludeRace)))
            and (not q.excludes or meetsGate(q.excludes, availableAlternative, false))
    end
    return {
        done=completedQuest, active=activeQuest, fits=fits, offers=offers,
        ready=function(q) return eligible(s, q, race, raceID, offers[q.id]) end,
        grey=function(q) return questDifficulty(s, q, offers[q.id]) == "trivial" end,
        levelText=function(q) return q.level and levelText(q.level, questDifficulty(s, q, offers[q.id])) end,
        carries=function(id) return carries(s, id) end,
        standing=standingFor,
    }
end

function ns.AddDungeonPickupTips(s, add)
    s.dungeonPickupHub = nil
    local faction = ns.AdvisorFaction and ns.AdvisorFaction(s) or s.faction
    if (faction ~= "Horde" and faction ~= "Alliance") or not s.level or not ns.DungeonPickupData then return end
    if not historyRequested and not legacyHistory and not (C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted)
        and not IsQuestFlaggedCompleted then ns.DungeonQuestHistory() end
    local hub, rows = currentRows(s)
    s.dungeonPickupHub = hub
    local race, raceID = s.race, s.raceID
    if UnitRace then
        local _, token, id = UnitRace("player")
        race, raceID = race or token, raceID or id
    end
    local offered = liveOffers()
    local chosen = {}
    local function candidates(list)
        for _, q in ipairs(list or {}) do
            local offer = offered[q.id]
            if eligible(s, q, race, raceID, offer) then
                local previous = chosen[q.id]
                -- The same quest may have several givers. Prefer the local
                -- settlement, then a known waypoint or the held starting item.
                local weight = (q.itemStart and 8 or 0) + (nameMatches(s.subzone, q.area) and 4 or 0)
                    + (q.pin and 2 or 0) + (not q.check and 1 or 0)
                if not previous or weight > previous.weight then
                    local difficulty = questDifficulty(s, q, offer)
                    if difficulty ~= "trivial" then chosen[q.id] = {q=q, weight=weight, difficulty=difficulty} end
                end
            end
        end
    end
    candidates(rows)
    candidates(ns.DungeonItemPickupData)
    for _, selected in pairs(chosen) do
        local q = selected.q
        local actionable = not q.check or offered[q.id] ~= nil
        local target, coords = nil, ""
        if q.pin then
            local p = q.pin
            target = {mapID=p.mapID, x=p.x, y=p.y, name=q.giver, npcID=q.npcID, questID=q.id}
            coords = (" (%.1f, %.1f)"):format(p.x * 100, p.y * 100)
        end
        local location = q.giver or "Quest start"
        local area = q.area or (ns.DungeonPickupZoneNames and ns.DungeonPickupZoneNames[hub])
            or (type(hub) == "string" and hub)
        if area and area ~= "" and area ~= location then location = location .. ", " .. area end
        local detail = location .. coords .. ". " .. q.dungeon .. "."
        if offered[q.id] and s.level < q.min then
            detail = detail .. " Listed minimum " .. q.min .. ". Offered to you now at level " .. s.level .. "."
        else detail = detail .. " Requires level " .. q.min .. "." end
        if q.level then detail = detail .. " " .. levelText(q.level, selected.difficulty) end
        if q.note then detail = detail .. " " .. q.note end
        local title
        if not actionable then title = "Check availability: " .. q.name
        elseif q.itemStart then title = "Use " .. q.giver .. " to start " .. q.name
        else title = "Pick up " .. q.name end
        local priority = actionable and (10 + math.min(60, s.level - q.min) / 10) or 60
        if nameMatches(s.subzone, q.area) then priority = priority - 1 end
        local mapID = (target and target.mapID) or (type(hub) == "number" and hub) or s.mapID
        add(title, detail, priority, "dungeon:pickup:" .. q.id, target, actionable, q.id, mapID)
    end
end
