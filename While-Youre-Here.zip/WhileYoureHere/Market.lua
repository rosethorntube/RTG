local addonName, ns = ...
local houseOpen = false
local function now()
    return (GetServerTime and GetServerTime()) or time()
end

local function venueName(venue)
    if venue == "Horde" or venue == "Alliance" then return venue end
    if venue == "Blackwater" or venue == "Neutral" then return "Neutral" end
end

local function faction()
    return venueName(UnitFactionGroup and UnitFactionGroup("player")) or venueName(ns.state and ns.state.faction)
end

-- Forever can return a blank realm name. Auctions belong to a region and
-- ruleset; an incomplete ruleset must not become a shared "unknown" price book.
local rulesetFlags = {"RP", "PvP", "Hardcore"}
local function foreverRuleset()
    local api = C_GameRules and C_GameRules.IsGameRuleActive
    local rules = Enum and Enum.GameRule
    if not api or not rules then return end
    local active = {}
    for _, name in ipairs(rulesetFlags) do
        local rule = rules[name.."Ruleset"]
        if rule == nil then return end
        local ok, value = pcall(api,rule)
        if not ok or type(value) ~= "boolean" then return end
        if value then active[#active+1] = name end
    end
    return #active > 0 and table.concat(active,"-") or "PvE"
end

function ns.MarketKey(explicit)
    local market = venueName(explicit)
    if not market then
        local choice = ns.DB().settings.saleMarket
        if choice == "neutral" then market = "Neutral"
        elseif choice == "faction" then market = venueName(faction())
        elseif houseOpen and ns.GetNativeMarketVenue then market = venueName(ns.GetNativeMarketVenue()) end
        market = market or venueName(faction())
    end
    if not market then return end
    local cut = market == "Neutral" and 0.15 or 0.05
    local region = GetCurrentRegion and GetCurrentRegion()
    if not region or region == 0 or region == "" then region = GetCurrentRegionName and GetCurrentRegionName() end
    local mode = (ns.state and ns.state.mode) or "normal"
    local realm = GetRealmName and GetRealmName()
    if realm == nil then realm = ns.state and ns.state.realm end
    if not realm or realm == "" or realm == "?" then
        local ruleset = foreverRuleset()
        if not region or region == "" or not ruleset then
            return nil, market .. " AH (market unconfirmed)", cut
        end
        local scope = "Forever:"..ruleset
        return table.concat({tostring(region),scope,mode,market},"/"), market .. " AH (Forever "..ruleset..")", cut
    end
    return table.concat({tostring(region or ""),realm,mode,market},"/"), market .. " AH (" .. realm .. ")", cut
end

function ns.MarketLabel()
    local _, label = ns.MarketKey()
    return label or "Unknown market"
end

-- Normalise display level, player-specific loot seed, link colour, and visible name
-- away. Preserve enchants, gems, random suffix and bonus IDs when actually present.
function ns.MarketVariantKey(id, link)
    if type(link) ~= "string" or link == "" then return end
    if link:match("^v:[%d,:%-]+$") then return link end
    local raw = link:match("item:([%d:%-]+)")
    if not raw then return end
    local fields = {}
    for field in (raw..":"):gmatch("([^:]*):") do fields[#fields+1]=tonumber(field) or 0 end
    if fields[1] ~= tonumber(id) then return end
    local traits, distinct = {}, false
    for i = 2,7 do
        local v = fields[i] or 0
        traits[#traits+1] = tostring(v)
        if v ~= 0 then distinct = true end
    end
    local bonus = {}
    for i = 1,math.min(math.max(fields[13] or 0,0),64) do
        if (fields[13+i] or 0) ~= 0 then bonus[#bonus+1]=fields[13+i]; distinct=true end
    end
    if distinct then
        table.sort(bonus)
        for _, value in ipairs(bonus) do traits[#traits+1]=tostring(value) end
        return "v:"..table.concat(traits,",")
    end
end

local function numberOK(n)
    return type(n) == "number" and n > 0 and n == math.floor(n) and n <= 9007199254740991
end

local function database()
    local db = ns.DB()
    db.marketQuotes = db.marketQuotes or {}
    return db.marketQuotes
end

function ns.StoreMarketQuote(id, copper, source, variant, observedAt, venue, units, offers)
    id = tonumber(id)
    if not numberOK(id) or not numberOK(copper) or type(source) ~= "string" then return false end
    local kind = (source == "manual" and "manual") or ((source == "native" or source:match("^AH ")) and "native")
    if not kind or (venue and not venueName(venue)) then return false end
    local key = ns.MarketKey(venue)
    if not key then return false end
    local t = observedAt or now()
    if type(t) ~= "number" or t < 0 or t > now()+5 then return false end
    local markets = database()
    markets[key] = markets[key] or {}
    local item = tostring(id) .. "|" .. (ns.MarketVariantKey(id,variant) or "")
    local current = markets[key][item]
    if current and (current.at > t or (current.at == t and current.source == "native" and kind == "manual")) then return false end
    markets[key][item] = {copper=copper,at=t,source=kind,detail=source,units=units,offers=offers}
    if ns.RequestRefresh then ns.RequestRefresh() end
    return true
end

local function provider(api, key, item)
    if not api or type(api[key])~="function" then return end
    local ok, v = pcall(api[key], addonName, item)
    if ok and type(v)=="number" and v >= 0 and v < math.huge then return v end
end

local function auctionatorQuote(id, link, distinctVariant)
    local api = Auctionator and Auctionator.API and Auctionator.API.v1
    if not api then return end
    local hasLink = type(link) == "string" and tonumber(link:match("item:(%d+)")) == id
    if hasLink then
        -- Auctionator can itself generalise a link to the base item if the
        -- suffix has never been seen. Do not value distinct gear as that variant.
        if distinctVariant and type(api.IsAuctionDataExactByItemLink) == "function" then
            local ok, exact = pcall(api.IsAuctionDataExactByItemLink, addonName, link)
            if not ok or exact == false then return end
        end
        local price = provider(api,"GetAuctionPriceByItemLink",link)
        if price and price > 0 then
            return price,provider(api,"GetAuctionAgeByItemLink",link)
        end
    end
    if distinctVariant then return end
    local price = provider(api,"GetAuctionPriceByItemID",id)
    if price and price > 0 then return price,provider(api,"GetAuctionAgeByItemID",id) end
    -- Cooking calculations and old catch records may have only an item ID.
    if not hasLink then
        local getInfo = (C_Item and C_Item.GetItemInfo) or GetItemInfo
        local cachedLink = getInfo and select(2,getInfo(id))
        local plainLink = cachedLink or "item:"..id
        price = provider(api,"GetAuctionPriceByItemLink",plainLink)
        if price and price > 0 then return price,provider(api,"GetAuctionAgeByItemLink",plainLink) end
    end
end

function ns.MarketQuote(id, variant, observedOnly)
    id = tonumber(id)
    if not numberOK(id) then return end
    local key = ns.MarketKey()
    local v = ns.MarketVariantKey(id,variant)
    local book = key and database()[key]
    local row = book and book[tostring(id).."|"..(v or "")]
    if observedOnly and row and row.source == "manual" then row = nil end
    local localAge = row and math.max(0,(now()-row.at)/86400)
    if row and localAge <= 7 then return row.copper,localAge,row.source,row.offers end
    -- This is Auctionator's current tooltip estimate, not a venue-specific
    -- observation. Never write it to the native/manual price book.
    local price, age = auctionatorQuote(id,variant,v)
    if price and (not row or (age and math.floor(age) < math.floor(localAge))) then
        return price,age,"Auctionator"
    end
    if row then return row.copper,localAge,row.source,row.offers end
end

local function money(text)
    if type(text) ~= "string" then return end
    text = text:lower():gsub("^%s+",""):gsub("%s+$","")
    if text:match("^%d+$") then local value=tonumber(text); if numberOK(value) then return value end; return end
    local units = {g=10000,s=100,c=1}
    local total, previous = 0,10001
    while text ~= "" do
        local n, unit, tail = text:match("^(%d+)%s*([gsc])%s*(.*)$")
        if not n or units[unit] >= previous then return end
        total,previous = total+tonumber(n)*units[unit], units[unit]
        text=tail
    end
    if numberOK(total) then return total end
end

local function say(message)
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then DEFAULT_CHAT_FRAME:AddMessage(message)
    elseif print then print(message) end
end

local function command(message)
    local input = (message or ""):match("^%s*(.-)%s*$")
    local choice=input:lower():match("^market%s+(%a+)$")
    if choice=="faction" or choice=="neutral" or choice=="auto" then
        ns.DB().settings.saleMarket = choice
        say(ns.title.." · Sale market: "..ns.MarketLabel())
        if ns.RequestRefresh then ns.RequestRefresh() end
        return
    elseif input:lower()=="market" then say(ns.title.." · Sale market: "..ns.MarketLabel()..". Use /wyh price market faction, neutral or auto."); return end
    local link, price = input:match("^(.-|h%[[^%]]+%]|h|r)%s+(.+)$")
    if not link then link,price=input:match("^(.-|h%[[^%]]+%]|h)%s+(.+)$") end
    local id = link and tonumber(link:match("item:(%d+)"))
    if not id then id,price=input:match("^(%d+)%s+(.+)$"); id=tonumber(id) end
    local unit=money(price)
    if id and unit and ns.StoreMarketQuote(id,unit,"manual",link) then
        say(("Saved %d copper per item for #%d, %s."):format(unit,id,ns.MarketLabel()))
    else
        say("Use /wyh price <item ID or Shift-click link> <unit price>, e.g. /wyh price 6362 40s or /wyh price 6362 1g 2s 3c. /wyh price market selects your sale market.")
    end
end
ns.MarketCommand=command
local events=CreateFrame("Frame")
events:RegisterEvent("AUCTION_HOUSE_SHOW")
events:RegisterEvent("AUCTION_HOUSE_CLOSED")
events:RegisterEvent("PLAYER_LEAVING_WORLD")
events:SetScript("OnEvent",function(_,event)
    houseOpen=event=="AUCTION_HOUSE_SHOW"
    if ns.RequestRefresh then ns.RequestRefresh() end
end)
