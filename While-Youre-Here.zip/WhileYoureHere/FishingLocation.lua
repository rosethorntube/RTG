local _, ns = ...

local watersByMap = {}
for _, water in ipairs(ns.FishingWaters) do watersByMap[water.mapID] = water.continent end

-- Coarse travel preferences when two waters offer comparable catches. These
-- groups describe geography, not journey times or zone entry requirements.
local regions = {
    {1420,1421,1458,1424,1416,1417,1425,1422,1423,1437},
    {1434,1435,1431,1419,1429,1433,1436,1453,1426,1455,1432},
    {1411,1412,1413,1440,1442,1454,1456},
    {1443,1444,1445,1441,1446,1449,1451},
    {1447,1448,1450,1452,1439,1438,1457},
}
local regionFor = {}
for region, maps in ipairs(regions) do
    for _, mapID in ipairs(maps) do regionFor[mapID] = region end
end

local function location(state)
    local mapID = ns.OutdoorZoneForData and ns.OutdoorZoneForData(state, watersByMap) or state.mapID
    local region = regionFor[mapID]
    local continent = watersByMap[mapID]
    if not continent and region then continent = region <= 2 and "EK" or "Kalimdor" end
    if not continent and mapID then
        local parent = mapID
        for i = 1, 8 do
            if parent == 1414 then continent = "Kalimdor"; break end
            if parent == 1415 then continent = "EK"; break end
            local info = C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(parent)
            if not info or not info.parentMapID or info.parentMapID == 0 then break end
            parent = info.parentMapID
        end
    end
    return mapID, region, continent
end

local function bitesNow(id, hour)
    if type(hour) ~= "number" then return id ~= 13759 and id ~= 13760 end
    if id == 13759 then return hour < 12 or hour >= 18 end -- Nightfin
    if id == 13760 then return hour >= 6 end -- Sunscale
    return true
end
ns.FishBitesNow = bitesNow

local function recipeColour(rank, recipe)
    if rank >= recipe.green then return "green", 1 end
    if rank >= recipe.yellow then return "yellow", 2 end
    return "orange", 3
end

local function travelScore(spot, mapID, region, continent)
    if spot.mapID == mapID then return 15 end
    if region and region == regionFor[spot.mapID] then return 8 end
    if continent == spot.continent then return 4 end
    return 0
end

local function isBoatStop(state, route, spot)
    if not route.boat or state.mapID ~= spot.mapID or not spot.port then return false end
    return state.subzone == spot.port or state.zone == spot.port
end

-- Eligible fish at the same exact water. Static scores express an order of
-- preference, never assumed drop rates or numerical skill-up probabilities.
local function assessWater(state, spot, cooking, focus, goal, statuses)
    local useful, lead, leadScore = {}, nil, nil
    if not cooking or goal == "gold" then return useful end
    local training = cooking.rank < cooking.cap and cooking.rank < 300
    for _, id in ipairs(spot.fish) do
        local recipe = ns.fish[id]
        if recipe and cooking.rank >= recipe.skill and bitesNow(id, state.hour)
            and (not recipe.station or (ns.CookingStationReady and ns.CookingStationReady(recipe))) then
            local status = statuses[id] or ns.NextRecipeStatus(state, recipe.spell)
            statuses[id] = status
            local grey = ns.RecipeOutlevelled(cooking, recipe)
            local edible = (state.level or 0) >= (ns.FishingFoodLevel(id) or 1)
            local food = ns.FishingFoodType(id)
            local matches = edible and focus ~= nil and food == focus
            local forFood = goal == "food" and matches and (not grey or status == "known")
            local forTraining = goal == "cooking" and training and not grey
            if forFood or forTraining then
                local colour, difficulty = recipeColour(cooking.rank, recipe)
                if grey then colour, difficulty = "grey", 0 end
                local candidate = {id=id, recipe=recipe, status=status, colour=colour, matches=matches}
                if status == "known" and not grey then useful[#useful+1] = candidate end
                local preference = (status == "known" and 24 or status == "missing" and -4 or 0)
                if goal == "food" then
                    preference = preference + (tonumber(recipe.buff:match("%d+")) or 0)
                else
                    preference = preference + 8*difficulty + (matches and 5 or 0)
                    if focus == "healing" and edible and not food then preference = preference + 3 end
                end
                if not leadScore or preference > leadScore then
                    lead, leadScore = candidate, preference
                end
            end
        end
    end
    return useful, lead, leadScore
end

local function sampleRate(sample, useful)
    if not (sample and sample.comparable and sample.seconds and sample.seconds > 0 and sample.items) then return end
    if #useful == 0 then return end
    local bands = {orange=0, yellow=0, green=0}
    for _, fish in ipairs(useful) do
        local n = sample.items[fish.id] or 0
        bands[fish.colour] = bands[fish.colour] + math.floor(n / (fish.recipe.fishPerCraft or 1)) * 3600 / sample.seconds
    end
    return bands.orange + bands.yellow + bands.green, bands
end

local function dominates(a, b, goal)
    if goal == "gold" then return a.rate > b.rate end
    local x,y = a.bands,b.bands
    -- Test all order-preserving colour weights without guessing a percentage
    -- chance of a skill-up from an individual yellow or green craft.
    local xMid,yMid = x.orange+x.yellow,y.orange+y.yellow
    return x.orange >= y.orange and xMid >= yMid and a.rate >= b.rate
        and (x.orange > y.orange or xMid > yMid or a.rate > b.rate)
end

local function pickWater(state, cooking, effective, mapID, region, continent, lureGain, goal)
    local focus = ns.FishingFoodFocus(state)
    local statuses = {}
    local preferred, practice, localMinimum, boatWater
    local samples = {}
    local route = ns.GetRouteContext and ns.GetRouteContext(state) or {}
    local faction = ns.AdvisorFaction and ns.AdvisorFaction(state) or state.faction
    local level = state.level or 0
    for _, spot in ipairs(ns.FishingWaters) do
        local nearby = spot.mapID == mapID
        if nearby then localMinimum = math.min(localMinimum or spot.minimum, spot.minimum) end
        local needsLure = effective < spot.minimum
        local canUseLure = nearby and lureGain and effective + lureGain >= spot.minimum
        if (not spot.faction or spot.faction == faction)
            and (not needsLure or canUseLure) and (nearby or level >= spot.level) then
            local base = travelScore(spot, mapID, region, continent)
            local onRoute = route.destinationMapID == spot.mapID or route.camp and spot.routeKey == "camp-fishing"
            if onRoute then base = base + 5 end
            if effective >= spot.noEscape then base = base + 3 end
            if spot.pool then base = base - 1 end
            local p = {spot=spot, localZone=nearby, score=base, goal=goal}
            if not practice or base > practice.score then practice = p end
            local useful, lead, preference = assessWater(state, spot, cooking, focus, goal, statuses)
            local c = {spot=spot, localZone=nearby, useful=useful, score=base, goal=goal,onRoute=onRoute}
            if isBoatStop(state,route,spot) then boatWater = c end
            if lead then
                c.fishID,c.colour,c.status,c.matches = lead.id,lead.colour,lead.status,lead.matches
                -- A second known recipe is useful supporting evidence when no
                -- catch rates exist. It cannot, on its own, justify a long trip.
                local coverage = goal == "cooking" and math.min(6, 3*math.max(0,#useful-1)) or 0
                c.score = base + preference + coverage
                if not preferred or c.score > preferred.score then preferred = c end
            end
            if not needsLure and ns.FishingWaterSample and (goal == "gold" or (goal == "cooking" and #useful > 0)) then
                local sample = ns.FishingWaterSample(state,spot)
                local rate, bands
                if goal == "gold" then
                    if sample and sample.goldComparable then rate = sample.netCopperPerHour end
                else
                    rate, bands = sampleRate(sample,useful)
                end
                if rate then
                    c.sample, c.rate, c.bands = sample, rate, bands
                    samples[#samples+1] = c
                end
            end
        end
    end
    if boatWater then boatWater.boat=true; return boatWater, localMinimum end
    if goal == "gold" or (preferred and preferred.sample and #samples >= 2) then
        local best, localSample
        for _, c in ipairs(samples) do
            local stronger = false
            for _, other in ipairs(samples) do
                if dominates(other,c,goal) then stronger=true; break end
            end
            if not stronger and (not best or c.score > best.score) then best = c end
            if c.localZone and (not localSample or c.rate > localSample.rate) then localSample=c end
        end
        if best then
            best.sampleCount = #samples
            if not best.localZone and localSample and dominates(best,localSample,goal) then best.localSample=localSample end
            return best, localMinimum
        end
    end
    return preferred or practice, localMinimum
end

local function zoneName(mapID, state)
    local info = C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(mapID)
    return (info and info.name) or (ns.DungeonPickupZoneNames and ns.DungeonPickupZoneNames[mapID])
        or (mapID == state.mapID and state.zone)
end

local function vendorHint(state, recipe, id)
    if ns.RecipeItemHeld then
        local held = ns.RecipeItemHeld(state, recipe.recipeItem)
        if held == "bags" then return "Learn the recipe scroll in your bags." end
        if held == "bank" then return "Collect the recipe scroll from your bank." end
    end
    local auction = ns.RecipeShoppingHint and ns.RecipeShoppingHint(state, recipe.recipeItem)
    if ns.FeatureEnabled and not ns.FeatureEnabled("vendors") then
        return auction or "Learn the recipe to cook your catch."
    end
    local shop = ns.localFishVendors[state.mapID]
    if not (shop and shop.items[id] and (not shop.faction or shop.faction == state.faction)) then
        shop = recipe
        local northernHorde = state.faction == "Horde" and regionFor[state.mapID] == 1
        local undercity = ns.localFishVendors[1458]
        if northernHorde and undercity.items[id] then shop = undercity end
    end
    local faction = ns.AdvisorFaction and ns.AdvisorFaction(state) or state.faction
    if (shop.faction and shop.faction ~= faction) or
        (ns.RecipeShopAccessible and not ns.RecipeShopAccessible(state,shop)) then
        return auction or "Check your faction's recipe vendors or the auction house."
    end
    local vendor = ("%s, %s (%.0f, %.0f)."):format(shop.vendor, shop.zone, shop.x*100, shop.y*100)
    if auction and shop.mapID ~= state.mapID then
        return auction .. " Vendor: " .. vendor, ns.RecipeVendorTarget(shop)
    end
    return "Recipe: " .. vendor .. (auction and (" " .. auction) or ""), ns.RecipeVendorTarget(shop)
end

local function waterName(spot, zone)
    local text = spot.water
    if zone then
        local suffix = ", " .. zone
        if text:sub(-#suffix) == suffix then return text:sub(1, -#suffix-1) end
    end
    return text
end

local function fishName(id)
    return (ns.fish[id].name:gsub("^Raw ", ""):gsub("^Large Raw ", "Large "))
end

local function skillLine(effective, spot, lureGain, lureName)
    if effective >= spot.noEscape then
        return ("Effective Fishing %d. No escapes here at %d+."):format(effective,spot.noEscape)
    end
    if lureGain and lureGain > 0 and lureName then
        local boosted = effective + lureGain
        return ("Apply %s from your bags. Effective Fishing %d → %d. %s"):format(lureName,effective,boosted,
            boosted >= spot.noEscape and "No escapes here with the lure." or ("Aim for %d to avoid escapes."):format(spot.noEscape))
    end
    return ("Effective Fishing %d. Aim for +%d from skill, pole or lure to avoid escapes at %d."):format(
        effective,spot.noEscape-effective,spot.noEscape)
end

local function evidence(best)
    local lines = {}
    if best.boat then
        lines[#lines+1] = "You are at the departure dock. You can fish while waiting for the boat."
    elseif best.onRoute then
        lines[#lines+1] = "Your active route already goes through this zone."
    elseif best.localZone then
        lines[#lines+1] = "This water is in your current zone."
    end
    if best.sample and best.rate then
        local s = best.sample
        lines[#lines+1] = ("%d casts in %.0f minutes across %d visit%s."):format(s.casts,s.seconds/60,s.visits,s.visits == 1 and "" or "s")
        if best.goal == "cooking" then
            local bands = best.bands
            lines[#lines+1] = ("Fish caught per hour would supply %.0f orange, %.0f yellow and %.0f green crafts. Yellow and green crafts can miss a skill-up; allow for any other ingredients."):format(
                bands.orange,bands.yellow,bands.green)
        else
            if s.casts > 0 then
                local perCast = math.floor(best.rate*s.seconds/(3600*s.casts)+0.5)
                lines[#lines+1] = ("%.2fs per cast from repeat catches at current sale estimates."):format(perCast/100)
            end
            lines[#lines+1] = "One-off trophies are excluded from the rate."
            local here = best.localSample
            if here and here.rate > 0 and best.rate > here.rate then
                lines[#lines+1] = ("For each minute of travel, fish here for %.1f minutes to beat the sampled local water."):format(here.rate/(best.rate-here.rate))
            end
        end
        if best.sampleCount and best.sampleCount > 1 then
            lines[#lines+1] = ("Compared %d sampled waters."):format(best.sampleCount)
        end
    elseif best.goal == "cooking" then
        lines[#lines+1] = "Guide estimate from eligible fish, recipe colours and travel. Catch rates can change which water wins."
    elseif best.goal == "gold" then
        lines[#lines+1] = "A gold estimate needs fresh prices and repeat catches in this water on separate visits."
    else
        lines[#lines+1] = "Matches the food effect to your build and checks the level needed to eat it."
    end
    return table.concat(lines,"\n")
end

-- Speak to the active goal. Unattributed zone catches never prove an exact
-- river, coast or school is more productive.
function ns.FishingLocationAdvice(state,goal)
    local skills = state and state.skills
    if not skills then return end
    local fishing,cooking = skills.Fishing,skills.Cooking
    goal = goal or (ns.FishingGoal and ns.FishingGoal(state)) or "cooking"
    if goal ~= "gold" and goal ~= "food" then goal = "cooking" end
    if not fishing or not fishing.rank then
        return {title="Learn Fishing first",body="Visit a Fishing trainer to start catching fish.",goal=goal,key="fishing-location:train"}
    end
    if goal == "gold" and ns.FeatureEnabled and not ns.FeatureEnabled("prices") then
        return {title="Fishing prices are turned off",body="Enable auction prices in Settings to compare fishing income.",
            goal=goal,key="fishing-location:prices"}
    end
    if goal == "cooking" and cooking and cooking.rank >= cooking.cap then
        local title,body = "Raise your Cooking cap",("Cooking %d/%d. Train the next rank before fishing for more skill-ups."):format(cooking.rank,cooking.cap)
        if cooking.rank >= 300 then title,body="Cooking is at 300","Choose Food for my build or Gold for your next fishing stop." end
        return {title=title,body=body,key="fishing-location:cap:"..cooking.cap,goal=goal}
    end
    local effective = fishing.rank + (fishing.modifier or 0) + (fishing.temp or 0)
    local mapID,region,continent = location(state)
    local lureGain,lureName
    if ns.FishingLureGain then lureGain,lureName = ns.FishingLureGain(state) end
    local best,localMinimum = pickWater(state,cooking,effective,mapID,region,continent,lureGain,goal)
    if not best then
        local water = state.faction == "Alliance" and "Crystal Lake near Goldshire" or "Brightwater Lake east of Brill"
        return {title="Start in beginner water",body="Try "..water.." with a fishing pole.",goal=goal,key="fishing-location:starter"}
    end
    local spot,id = best.spot,best.fishID
    local zone = zoneName(spot.mapID,state)
    local water = waterName(spot,zone)
    if best.boat then best.title = "Fish while you wait for the boat"
    elseif best.localZone and effective < spot.minimum then best.title = "Use a lure to stay "..(zone and "in "..zone or "here")
    elseif best.localZone then best.title = zone and "Stay in "..zone or "Stay in this zone"
    else best.title = zone and "Fish in "..zone or "Where to fish next" end
    local lines = {}
    if goal == "gold" then
        lines[1] = "Fish "..water.."."
        if best.rate then
            lines[2] = ("%.2fg/hour estimated from repeat catches."):format(best.rate/10000)
        else
            lines[2] = "No comparable gold rate yet. Choose Log water... in the Fishing guide and select the water you're fishing."
        end
    elseif id then
        local recipe = ns.fish[id]
        local catches = {fishName(id)}
        local expiring
        if goal == "cooking" then
            for _,fish in ipairs(best.useful) do
                if fish.id ~= id then catches[#catches+1] = fishName(fish.id) end
                if fish.recipe.grey and fish.recipe.grey - cooking.rank <= 5
                    and (not expiring or fish.recipe.grey < expiring.recipe.grey) then expiring = fish end
            end
        end
        lines[1] = "Fish "..water.." for "..table.concat(catches,", ").."."
        local cue
        if best.status == "known" then cue = "Known recipe ("..best.colour..")."
        elseif best.status == "unknown" then cue = "Open Cooking to check the recipe."
        else
            local hint,target = vendorHint(state,recipe,id)
            cue,best.vendorTarget = hint,target
        end
        if goal == "food" or best.matches then cue = cue.." "..recipe.buff.." when eaten." end
        lines[#lines+1] = ("Cooking %d/%d. "):format(cooking.rank,cooking.cap)..cue
        if expiring and #catches > 1 then
            lines[#lines+1] = ("Cook %s first. It turns grey at %d."):format(fishName(expiring.id),expiring.recipe.grey)
        end
        if recipe.station then lines[#lines+1] = "Use an "..recipe.station.." to cook it." end
    else
        lines[1] = "Fish "..water.."."
        if not cooking then lines[2] = "Learn Cooking to cook your catch."
        elseif goal == "food" then
            local focus = ns.FishingFoodFocus(state)
            if focus == "healing" then lines[2] = "For healing power, look for a healing tea in the profession guide."
            elseif not focus then lines[2] = "Set a food preference or select talents to match a dish to your build."
            else lines[2] = "No eligible "..(focus == "attack" and "attack-power" or "spell-damage").." dish in the accessible waters." end
        else lines[2] = "Fishing practice. No eligible skill-up recipe in the accessible waters." end
    end
    lines[#lines+1] = skillLine(effective,spot,lureGain,lureName)
    if not best.localZone and localMinimum and effective < localMinimum then
        lines[#lines+1] = ("To fish in your current zone, reach %d with a pole or lure."):format(localMinimum)
    end
    best.body,best.why = table.concat(lines,"\n"),evidence(best)
    best.alert = best.localZone and (id ~= nil or best.boat) and not (IsInInstance and IsInInstance())
    best.key = ("fishing-location:%s:%s:%d"):format(goal,spot.water,id or 0)
    return best
end
